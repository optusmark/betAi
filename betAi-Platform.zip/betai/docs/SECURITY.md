# betAi Platform — Security Architecture

## Overview
Security is enforced primarily on the **backend**. The frontend (demo HTML)
is for UI/UX only and must never be trusted with secrets or authorization logic.

## 1. Password Security
- All passwords hashed with **bcrypt** (cost factor 12) — never stored in plaintext
- Hashing is one-way; even with full DB access, original passwords cannot be recovered
- Password requirements enforced: minimum 8 characters (configurable)
- Super-admin passwords are 24-character cryptographically random strings

## 2. Super-Admin Provisioning
- 2 super-admin accounts are created via a **seeder script** at deployment
- Credentials supplied through **environment variables** (`.env`), never in code
- The seeder hashes passwords and stores only the hash
- `.env.superadmins.SECRET` must NEVER be committed to version control
- After seeding, plaintext passwords can be removed from the server

## 3. Authentication
- **JWT** access tokens with short expiry (15 min) + refresh tokens (7 days)
- Tokens signed with a strong secret (`JWT_SECRET` from env, 256-bit)
- Admin status determined server-side by looking up the email in `admin_accounts`
- The frontend has NO "login as admin" toggle — admin detection is server-authoritative

## 4. Brute-Force Protection
- **IP rate limiting**: 5 auth attempts per 15 minutes (express-rate-limit)
- **Account lockout**: account locked for 30 min after 5 failed attempts
- Failed attempts tracked in DB (`failed_attempts`, `locked_until`)
- Successful logins reset the counter

## 5. Input Validation & Injection Prevention
- Global `ValidationPipe` with whitelist — strips unknown properties, rejects extras
- All DB queries use **parameterized statements** ($1, $2) — prevents SQL injection
- DTOs validate every incoming request shape
- Output encoding prevents stored XSS

## 6. HTTP Security Headers (Helmet)
- Content-Security-Policy (restricts script/style/connect/frame sources)
- HSTS (forces HTTPS, 1-year max-age, preload)
- X-Content-Type-Options: nosniff
- Referrer-Policy: strict-origin-when-cross-origin
- x-powered-by disabled

## 7. CORS
- Restricted to known frontend origin(s) only
- Credentials allowed only for trusted origins

## 8. Transport
- **HTTPS only** in production (TLS 1.2+)
- Secure, HttpOnly, SameSite cookies for refresh tokens

## 9. File Uploads (deposit proofs)
- Type whitelist: JPG, PNG, PDF only
- Size limit: 10 MB
- Files scanned and stored outside web root
- Served via signed, expiring URLs

## 10. Sensitive Data Handling
- API keys (API-Football, etc.) stored in env, never in frontend
- Binance WebSocket is public (no key) — safe for client
- Database credentials in env only
- Audit log records all admin actions (who, what, when, IP)

## 11. Operational
- Dependencies audited regularly (`npm audit`)
- Principle of least privilege for admin permissions
- Regular DB backups (encrypted at rest)
- Monitoring & alerting on anomalous activity

## Environment Variables Required
```
DATABASE_URL=postgres://...
JWT_SECRET=<256-bit random>
JWT_REFRESH_SECRET=<256-bit random>
FRONTEND_URL=https://betai.com
SUPERADMIN_1_EMAIL=...
SUPERADMIN_1_PASSWORD=...
SUPERADMIN_2_EMAIL=...
SUPERADMIN_2_PASSWORD=...
API_FOOTBALL_KEY=...
```

## What the frontend must NEVER contain
- Passwords or password hashes
- JWT secrets
- Database credentials
- Admin authorization logic (only display; server decides)
- API keys for paid services
