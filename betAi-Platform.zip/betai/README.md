# betAi — Smart Crypto Investment Platform

A full-stack crypto investment platform with daily-return packages, referral
system, real-time market ticker, sports data, and a complete admin panel.

## Stack
- **Backend:** NestJS (TypeScript), PostgreSQL, TypeORM, Socket.io
- **Frontend:** Next.js (TypeScript), TailwindCSS
- **Real-time:** Binance WebSocket (market ticker), Socket.io gateway
- **External:** API-Football (sports data)

## Features
- Investment packages: Silver ($500), Gold ($1,000), Platinum ($2,000) — 2%/day, 40-day cycles
- USDT TRC20 deposits with manual admin approval + proof upload
- Withdrawal conditions based on 5 active referrals
- Package upgrades (first 10 days, upward only)
- Referral program (auto-tracked)
- Real-time crypto price ticker (Binance WS)
- Sports events page (API-Football) with live scores & match detail
- Admin panel: deposits, withdrawals, wallets, packages, users, banner,
  sports config, test accounts, admin role management, audit log
- Flexible "About" page (admin-managed content blocks)
- Bilingual (EN / RU)
- Full responsive design (mobile / tablet / desktop)

## Project Structure
```
betai/
├── backend/          NestJS API
│   ├── src/
│   │   ├── auth/         JWT authentication
│   │   ├── packages/     Investment package logic
│   │   ├── deposits/     Manual deposit flow
│   │   ├── withdrawals/
│   │   ├── referrals/
│   │   ├── bonuses/      Daily bonus cron
│   │   ├── market/       Binance WebSocket ticker
│   │   ├── sports/       API-Football integration
│   │   ├── admin/
│   │   ├── common/security/   Security hardening
│   │   └── database/
│   │       ├── migrations/
│   │       └── seeds/    Super-admin seeder
│   └── .env.example
├── frontend/         Next.js app
├── database/migrations/
├── docs/
│   ├── SECURITY.md
│   ├── terms-of-service.md
│   └── binance-ticker-integration.md
└── docker-compose.yml
```

## Setup

### 1. Environment
```bash
cp backend/.env.example backend/.env
# Fill in real values (DB, JWT secrets, super-admin credentials, API keys)
```

Generate JWT secrets:
```bash
openssl rand -hex 32
```

### 2. Database
```bash
# Run migrations in order
psql $DATABASE_URL -f database/migrations/init.sql
psql $DATABASE_URL -f database/migrations/002_deposit_requests.sql
psql $DATABASE_URL -f database/migrations/003_packages_and_sports.sql
psql $DATABASE_URL -f database/migrations/004_admin_accounts.sql
```

### 3. Seed super-admins (once)
```bash
cd backend
npm run seed:superadmins
```

### 4. Run
```bash
# Backend
cd backend && npm install && npm run start:dev

# Frontend
cd frontend && npm install && npm run dev
```

Or with Docker:
```bash
docker-compose up
```

## Security
See [docs/SECURITY.md](docs/SECURITY.md). Key points:
- Passwords hashed with bcrypt (cost 12)
- JWT auth with refresh tokens
- Rate limiting + account lockout (brute-force protection)
- Parameterized queries (SQL-injection safe)
- Helmet security headers, CORS restrictions, HTTPS-only
- Secrets in environment variables only — never in code

## Demo
`betAi-Demo.html` is a standalone single-file UI demo (no backend required).
- User: `demo@betai.com` / `Demo@123456`
- Admin: `admin@betai.com` / `Admin@betai2025`

## License
Proprietary — all rights reserved.
