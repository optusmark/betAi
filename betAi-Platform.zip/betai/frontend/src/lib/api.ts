import axios from 'axios';

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000',
  withCredentials: true,
});

// Request interceptor: attach token
api.interceptors.request.use((config) => {
  if (typeof window !== 'undefined') {
    const token = localStorage.getItem('access_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
  }
  return config;
});

// Response interceptor: auto-refresh token
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      try {
        const refreshToken = localStorage.getItem('refresh_token');
        if (!refreshToken) {
          window.location.href = '/login';
          return Promise.reject(error);
        }

        const { data } = await axios.post(
          `${process.env.NEXT_PUBLIC_API_URL}/api/auth/refresh`,
          { refreshToken }
        );

        localStorage.setItem('access_token', data.accessToken);
        originalRequest.headers.Authorization = `Bearer ${data.accessToken}`;
        return api(originalRequest);
      } catch {
        localStorage.removeItem('access_token');
        localStorage.removeItem('refresh_token');
        window.location.href = '/login';
      }
    }

    return Promise.reject(error);
  }
);

export default api;

// Auth
export const authApi = {
  register: (data: any) => api.post('/api/auth/register', data),
  login: (data: any) => api.post('/api/auth/login', data),
  setup2FA: () => api.get('/api/auth/2fa/setup'),
  enable2FA: (code: string) => api.post('/api/auth/2fa/enable', { code }),
  disable2FA: (code: string) => api.post('/api/auth/2fa/disable', { code }),
};

// User
export const userApi = {
  getMe: () => api.get('/api/users/me'),
  updateProfile: (data: any) => api.patch('/api/users/me', data),
  changePassword: (data: any) => api.patch('/api/users/me/password', data),
};

// Wallet
export const walletApi = {
  getOverview: () => api.get('/api/wallet'),
  getAssets: () => api.get('/api/wallet/assets'),
};

// Deposits
export const depositsApi = {
  getAddress: (assetId: string) => api.get(`/api/deposits/address?assetId=${assetId}`),
  confirmDeposit: (data: any) => api.post('/api/deposits/confirm', data),
  getHistory: () => api.get('/api/deposits/history'),
};

// Withdrawals
export const withdrawalsApi = {
  request: (data: any) => api.post('/api/withdrawals/request', data),
  getHistory: () => api.get('/api/withdrawals/history'),
};

// KYC
export const kycApi = {
  getStatus: () => api.get('/api/kyc/status'),
  submit: (formData: FormData) => api.post('/api/kyc/submit', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  }),
};

// Referrals
export const referralsApi = {
  getInfo: () => api.get('/api/referrals'),
};

// Bonuses
export const bonusesApi = {
  getStatus: () => api.get('/api/bonuses/status'),
};

// Support
export const supportApi = {
  createTicket: (data: any) => api.post('/api/support/tickets', data),
  getTickets: () => api.get('/api/support/tickets'),
  getMessages: (id: string) => api.get(`/api/support/tickets/${id}`),
  reply: (id: string, message: string) => api.post(`/api/support/tickets/${id}/reply`, { message }),
  close: (id: string) => api.post(`/api/support/tickets/${id}/close`),
};

// Notifications
export const notificationsApi = {
  getAll: () => api.get('/api/notifications'),
  getUnreadCount: () => api.get('/api/notifications/unread-count'),
  markRead: (id: string) => api.patch(`/api/notifications/${id}/read`),
  markAllRead: () => api.patch('/api/notifications/read-all'),
};

// Admin
export const adminApi = {
  getDashboard: () => api.get('/api/admin/dashboard'),
  getUsers: (page = 1, limit = 20, search?: string) =>
    api.get(`/api/admin/users?page=${page}&limit=${limit}${search ? `&search=${search}` : ''}`),
  getUser: (id: string) => api.get(`/api/admin/users/${id}`),
  updateUserStatus: (id: string, status: string) => api.patch(`/api/admin/users/${id}/status`, { status }),
  getKyc: (status?: string) => api.get(`/api/admin/kyc${status ? `?status=${status}` : ''}`),
  approveKyc: (id: string) => api.post(`/api/admin/kyc/${id}/approve`),
  rejectKyc: (id: string, reason: string) => api.post(`/api/admin/kyc/${id}/reject`, { reason }),
  getDeposits: (page = 1) => api.get(`/api/admin/deposits?page=${page}`),
  getWithdrawals: (status?: string) => api.get(`/api/admin/withdrawals${status ? `?status=${status}` : ''}`),
  approveWithdrawal: (id: string, txHash: string) => api.post(`/api/admin/withdrawals/${id}/approve`, { txHash }),
  rejectWithdrawal: (id: string, reason: string) => api.post(`/api/admin/withdrawals/${id}/reject`, { reason }),
  getReferrals: () => api.get('/api/admin/referrals'),
  getBonuses: () => api.get('/api/admin/bonuses'),
  getTickets: (status?: string) => api.get(`/api/admin/tickets${status ? `?status=${status}` : ''}`),
  getTransactions: (page = 1) => api.get(`/api/admin/transactions?page=${page}`),
  getLogs: (page = 1) => api.get(`/api/admin/logs?page=${page}`),
  getAssets: () => api.get('/api/admin/assets'),
  createAsset: (data: any) => api.post('/api/admin/assets', data),
  updateAsset: (id: string, data: any) => api.patch(`/api/admin/assets/${id}`, data),
};
