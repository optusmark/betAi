'use client';
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { adminApi } from '@/lib/api';
import toast from 'react-hot-toast';
import { CheckCircle2, XCircle, Eye, Loader2 } from 'lucide-react';

export default function AdminKycPage() {
  const qc = useQueryClient();
  const [selectedKyc, setSelectedKyc] = useState<any>(null);
  const [rejectReason, setRejectReason] = useState('');

  const { data: kycList } = useQuery({
    queryKey: ['admin-kyc'],
    queryFn: () => adminApi.getKyc().then((r) => r.data),
  });

  const approveMutation = useMutation({
    mutationFn: (id: string) => adminApi.approveKyc(id).then((r) => r.data),
    onSuccess: () => {
      toast.success('KYC approved');
      qc.invalidateQueries({ queryKey: ['admin-kyc'] });
      setSelectedKyc(null);
    },
    onError: (err: any) => toast.error(err.response?.data?.message || 'Failed'),
  });

  const rejectMutation = useMutation({
    mutationFn: ({ id, reason }: any) => adminApi.rejectKyc(id, reason).then((r) => r.data),
    onSuccess: () => {
      toast.success('KYC rejected');
      qc.invalidateQueries({ queryKey: ['admin-kyc'] });
      setSelectedKyc(null);
    },
    onError: (err: any) => toast.error(err.response?.data?.message || 'Failed'),
  });

  return (
    <div className="space-y-5 animate-fade-in">
      <h1 className="text-2xl font-bold">KYC Review</h1>

      {/* Detail Modal */}
      {selectedKyc && (
        <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 overflow-y-auto">
          <div className="card w-full max-w-2xl my-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-lg">KYC Review</h3>
              <button onClick={() => setSelectedKyc(null)} className="text-dark-400 hover:text-white text-2xl leading-none">&times;</button>
            </div>

            <div className="grid sm:grid-cols-2 gap-4 mb-5">
              <div className="bg-dark-800 rounded-lg p-3">
                <p className="text-xs text-dark-500">User</p>
                <p className="font-medium">{selectedKyc.email || selectedKyc.phone}</p>
              </div>
              <div className="bg-dark-800 rounded-lg p-3">
                <p className="text-xs text-dark-500">Document Type</p>
                <p className="font-medium capitalize">{selectedKyc.document_type?.replace('_', ' ')}</p>
              </div>
            </div>

            {/* Document images */}
            <div className="grid sm:grid-cols-3 gap-3 mb-5">
              {selectedKyc.front_image_url && (
                <div>
                  <p className="text-xs text-dark-500 mb-1">Front</p>
                  <img src={selectedKyc.front_image_url} alt="Front" className="w-full rounded-lg border border-dark-700" />
                </div>
              )}
              {selectedKyc.back_image_url && (
                <div>
                  <p className="text-xs text-dark-500 mb-1">Back</p>
                  <img src={selectedKyc.back_image_url} alt="Back" className="w-full rounded-lg border border-dark-700" />
                </div>
              )}
              {selectedKyc.selfie_url && (
                <div>
                  <p className="text-xs text-dark-500 mb-1">Selfie</p>
                  <img src={selectedKyc.selfie_url} alt="Selfie" className="w-full rounded-lg border border-dark-700" />
                </div>
              )}
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-sm text-dark-400 mb-1.5">Rejection Reason (if rejecting)</label>
                <input
                  value={rejectReason}
                  onChange={(e) => setRejectReason(e.target.value)}
                  className="input-field"
                  placeholder="Optional reason..."
                />
              </div>
              <div className="flex gap-3">
                <button
                  onClick={() => approveMutation.mutate(selectedKyc.id)}
                  disabled={approveMutation.isPending}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium text-sm"
                >
                  {approveMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                  Approve
                </button>
                <button
                  onClick={() => rejectMutation.mutate({ id: selectedKyc.id, reason: rejectReason })}
                  disabled={rejectMutation.isPending}
                  className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-red-600 hover:bg-red-700 text-white rounded-lg font-medium text-sm"
                >
                  {rejectMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <XCircle className="w-4 h-4" />}
                  Reject
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="card p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-dark-800">
              <tr className="text-dark-400">
                {['User', 'Document Type', 'Status', 'Submitted', 'Actions'].map((h) => (
                  <th key={h} className="px-4 py-3 text-left font-medium text-xs">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-800">
              {kycList?.map((k: any) => (
                <tr key={k.id} className="hover:bg-dark-800/30">
                  <td className="px-4 py-3">{k.email || k.phone}</td>
                  <td className="px-4 py-3 capitalize">{k.document_type?.replace('_', ' ')}</td>
                  <td className="px-4 py-3">
                    <span className={k.status === 'pending' ? 'badge-warning' : 'badge-info'}>
                      {k.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-dark-500">{new Date(k.submitted_at).toLocaleDateString()}</td>
                  <td className="px-4 py-3">
                    <button onClick={() => { setSelectedKyc(k); setRejectReason(''); }} className="flex items-center gap-1.5 text-brand-400 hover:text-brand-300 text-xs">
                      <Eye className="w-4 h-4" /> Review
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!kycList?.length && (
            <div className="text-center py-10 text-dark-500">No pending KYC submissions</div>
          )}
        </div>
      </div>
    </div>
  );
}
