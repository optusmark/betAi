'use client';
import { useQuery } from '@tanstack/react-query';
import { adminApi } from '@/lib/api';
import { Users, Shield, ArrowDownLeft, ArrowUpRight, LifeBuoy, TrendingUp } from 'lucide-react';
import Link from 'next/link';

export default function AdminDashboard() {
  const { data: stats } = useQuery({
    queryKey: ['admin-dashboard'],
    queryFn: () => adminApi.getDashboard().then((r) => r.data),
    refetchInterval: 60_000,
  });

  const cards = [
    { title: 'Total Users', value: stats?.totalUsers ?? '—', icon: Users, href: '/admin/users', color: 'text-blue-400 bg-blue-500/10' },
    { title: 'Pending KYC', value: stats?.pendingKyc ?? '—', icon: Shield, href: '/admin/kyc', color: 'text-yellow-400 bg-yellow-500/10' },
    { title: 'Total Deposits', value: stats?.totalDeposits ? `$${Number(stats.totalDeposits).toLocaleString()}` : '—', icon: ArrowDownLeft, href: '/admin/deposits', color: 'text-green-400 bg-green-500/10' },
    { title: 'Pending Withdrawals', value: stats?.pendingWithdrawals ?? '—', icon: ArrowUpRight, href: '/admin/withdrawals', color: 'text-red-400 bg-red-500/10' },
    { title: 'Open Tickets', value: stats?.openTickets ?? '—', icon: LifeBuoy, href: '/admin/tickets', color: 'text-purple-400 bg-purple-500/10' },
  ];

  return (
    <div className="space-y-6 animate-fade-in">
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
        {cards.map((c) => (
          <Link key={c.title} href={c.href} className="card hover:border-dark-700 transition-colors group">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${c.color}`}>
              <c.icon className="w-5 h-5" />
            </div>
            <p className="text-2xl font-bold group-hover:text-brand-400 transition-colors">{c.value}</p>
            <p className="text-xs text-dark-500 mt-0.5">{c.title}</p>
          </Link>
        ))}
      </div>

      {/* Quick links */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {[
          { href: '/admin/withdrawals', label: 'Process Withdrawals', desc: 'Review & approve pending requests', color: 'border-red-500/30' },
          { href: '/admin/kyc', label: 'Review KYC', desc: 'Verify submitted documents', color: 'border-yellow-500/30' },
          { href: '/admin/tickets', label: 'Answer Tickets', desc: 'Respond to user support requests', color: 'border-blue-500/30' },
        ].map((item) => (
          <Link key={item.href} href={item.href} className={`card border ${item.color} hover:opacity-90 transition-opacity`}>
            <p className="font-semibold">{item.label}</p>
            <p className="text-sm text-dark-400 mt-1">{item.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
