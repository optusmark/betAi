'use client';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { adminApi } from '@/lib/api';
import Link from 'next/link';
import { Search, ChevronRight } from 'lucide-react';

export default function AdminUsersPage() {
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);

  const { data } = useQuery({
    queryKey: ['admin-users', page, search],
    queryFn: () => adminApi.getUsers(page, 20, search || undefined).then((r) => r.data),
    placeholderData: (prev) => prev,
  });

  const kycBadge = (status: string) => {
    const map: any = {
      approved: 'badge-success',
      pending: 'badge-warning',
      under_review: 'badge-info',
      rejected: 'badge-error',
      not_submitted: 'text-dark-500 text-xs',
    };
    return map[status] || 'badge-info';
  };

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Users</h1>
        <span className="text-dark-400 text-sm">{data?.total || 0} total</span>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-dark-500" />
        <input
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1); }}
          placeholder="Search by email or phone..."
          className="input-field pl-9"
        />
      </div>

      <div className="card p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-dark-800">
              <tr className="text-dark-400">
                {['Email/Phone', 'Status', 'KYC', 'Balance', 'Referrals', 'Joined', ''].map((h) => (
                  <th key={h} className="px-4 py-3 text-left font-medium text-xs">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-800">
              {data?.data?.map((u: any) => (
                <tr key={u.id} className="hover:bg-dark-800/50 transition-colors">
                  <td className="px-4 py-3 font-medium">{u.email || u.phone}</td>
                  <td className="px-4 py-3">
                    <span className={u.status === 'active' ? 'badge-success' : 'badge-error'}>
                      {u.status}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={kycBadge(u.kyc_status)}>
                      {u.kyc_status?.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-4 py-3 font-mono">{parseFloat(u.balance || 0).toFixed(2)} USDT</td>
                  <td className="px-4 py-3">{u.referral_count}</td>
                  <td className="px-4 py-3 text-dark-500">{new Date(u.created_at).toLocaleDateString()}</td>
                  <td className="px-4 py-3">
                    <Link href={`/admin/users/${u.id}`} className="text-brand-400 hover:text-brand-300">
                      <ChevronRight className="w-4 h-4" />
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      {data && data.total > 20 && (
        <div className="flex justify-center gap-2">
          <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="btn-secondary text-sm py-1.5 px-3">Prev</button>
          <span className="flex items-center text-sm text-dark-400">Page {page}</span>
          <button onClick={() => setPage(p => p + 1)} disabled={page * 20 >= data.total} className="btn-secondary text-sm py-1.5 px-3">Next</button>
        </div>
      )}
    </div>
  );
}
