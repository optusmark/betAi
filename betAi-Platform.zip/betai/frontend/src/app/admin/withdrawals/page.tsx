'use client';
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { adminApi } from '@/lib/api';
import toast from 'react-hot-toast';
import { CheckCircle2, XCircle, Clock, Loader2 } from 'lucide-react';

export default function AdminWithdrawalsPage() {
  const qc = useQueryClient();
  const [filter, setFilter] = useState('pending');
  const [txHash, setTxHash] = useState('');
  const [rejectReason, setRejectReason] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [action, setAction] = useState<'approve' | 'reject' | null>(null);

  const { data: withdrawals } = useQuery({
    queryKey: ['admin-withdrawals', filter],
    queryFn: () => adminApi.getWithdrawals(filter || undefined).then((r) => r.data),
  });

  const approveMutation = useMutation({
    mutationFn: ({ id, txHash }: any) => adminApi.approveWithdrawal(id, txHash).then((r) => r.data),
    onSuccess: () => {
      toast.success('Withdrawal approved!');
      qc.invalidateQueries({ queryKey: ['admin-withdrawals'] });
      setSelectedId(null); setAction(null); setTxHash('');
    },
    onError: (err: any) => toast.error(err.response?.data?.message || 'Failed'),
  });

  const rejectMutation = useMutation({
    mutationFn: ({ id, reason }: any) => adminApi.rejectWithdrawal(id, reason).then((r) => r.data),
    onSuccess: () => {
      toast.success('Withdrawal rejected');
      qc.invalidateQueries({ queryKey: ['admin-withdrawals'] });
      setSelectedId(null); setAction(null); setRejectReason('');
    },
    onError: (err: any) => toast.error(err.response?.data?.message || 'Failed'),
  });

  const statusBadge = (status: string) => {
    if (status === 'approved') return 'badge-success';
    if (status === 'rejected') return 'badge-error';
    if (status === 'in_review') return 'badge-info';
    return 'badge-warning';
  };

  return (
    <div className="space-y-5 animate-fade-in">
      <h1 className="text-2xl font-bold">Withdrawals</h1>

      {/* Filter */}
      <div className="flex gap-2 flex-wrap">
        {['pending', 'in_review', 'approved', 'rejected', ''].map((s) => (
          <button
            key={s}
            onClick={() => setFilter(s)}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${filter === s ? 'bg-brand-500 text-white' : 'bg-dark-800 text-dark-400 hover:text-white'}`}
          >
            {s || 'All'}
          </button>
        ))}
      </div>

      {/* Action Modal */}
      {action && selectedId && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
          <div className="card w-full max-w-md">
            <h3 className="font-semibold mb-4">
              {action === 'approve' ? 'Approve Withdrawal' : 'Reject Withdrawal'}
            </h3>
            {action === 'approve' ? (
              <div className="space-y-3">
                <label className="block text-sm text-dark-400">Transaction Hash</label>
                <input value={txHash} onChange={(e) => setTxHash(e.target.value)} className="input-field font-mono text-sm" placeholder="0x..." />
              </div>
            ) : (
              <div className="space-y-3">
                <label className="block text-sm text-dark-400">Rejection Reason</label>
                <textarea value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} className="input-field" rows={3} placeholder="Reason..." />
              </div>
            )}
            <div className="flex gap-3 mt-4">
              <button
                onClick={() => {
                  if (action === 'approve') approveMutation.mutate({ id: selectedId, txHash });
                  else rejectMutation.mutate({ id: selectedId, reason: rejectReason });
                }}
                disabled={approveMutation.isPending || rejectMutation.isPending}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg font-medium text-sm ${action === 'approve' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'} text-white`}
              >
                {(approveMutation.isPending || rejectMutation.isPending) && <Loader2 className="w-4 h-4 animate-spin" />}
                Confirm {action === 'approve' ? 'Approval' : 'Rejection'}
              </button>
              <button onClick={() => { setSelectedId(null); setAction(null); }} className="btn-secondary flex-1">Cancel</button>
            </div>
          </div>
        </div>
      )}

      <div className="card p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-dark-800">
              <tr className="text-dark-400">
                {['User', 'Amount', 'Address', 'Status', 'Date', 'Actions'].map((h) => (
                  <th key={h} className="px-4 py-3 text-left font-medium text-xs">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-800">
              {withdrawals?.map((w: any) => (
                <tr key={w.id} className="hover:bg-dark-800/30">
                  <td className="px-4 py-3">{w.email || w.phone}</td>
                  <td className="px-4 py-3 font-semibold">{parseFloat(w.amount).toFixed(2)} {w.symbol}</td>
                  <td className="px-4 py-3 font-mono text-xs text-dark-400 max-w-32 truncate">{w.to_address}</td>
                  <td className="px-4 py-3"><span className={statusBadge(w.status)}>{w.status.replace('_', ' ')}</span></td>
                  <td className="px-4 py-3 text-dark-500">{new Date(w.created_at).toLocaleDateString()}</td>
                  <td className="px-4 py-3">
                    {['pending', 'in_review'].includes(w.status) && (
                      <div className="flex gap-2">
                        <button onClick={() => { setSelectedId(w.id); setAction('approve'); }} className="p-1.5 rounded-lg bg-green-500/10 text-green-400 hover:bg-green-500/20">
                          <CheckCircle2 className="w-4 h-4" />
                        </button>
                        <button onClick={() => { setSelectedId(w.id); setAction('reject'); }} className="p-1.5 rounded-lg bg-red-500/10 text-red-400 hover:bg-red-500/20">
                          <XCircle className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!withdrawals?.length && (
            <div className="text-center py-10 text-dark-500">No withdrawals found</div>
          )}
        </div>
      </div>
    </div>
  );
}
