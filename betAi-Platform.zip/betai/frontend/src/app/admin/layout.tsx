'use client';
import { useEffect, useState } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import {
  LayoutDashboard, Users, Shield, ArrowDownLeft, ArrowUpRight,
  Network, Gift, LifeBuoy, Settings, LogOut, Menu, Coins,
  FileText, Activity
} from 'lucide-react';
import { useAuthStore } from '@/lib/store';

const adminNav = [
  { href: '/admin', icon: LayoutDashboard, label: 'Dashboard' },
  { href: '/admin/users', icon: Users, label: 'Users' },
  { href: '/admin/kyc', icon: Shield, label: 'KYC' },
  { href: '/admin/deposits', icon: ArrowDownLeft, label: 'Deposits' },
  { href: '/admin/withdrawals', icon: ArrowUpRight, label: 'Withdrawals' },
  { href: '/admin/referrals', icon: Network, label: 'Referrals' },
  { href: '/admin/bonuses', icon: Gift, label: 'Bonuses' },
  { href: '/admin/tickets', icon: LifeBuoy, label: 'Support' },
  { href: '/admin/transactions', icon: Activity, label: 'Transactions' },
  { href: '/admin/assets', icon: Coins, label: 'Assets' },
  { href: '/admin/logs', icon: FileText, label: 'Audit Logs' },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const { user, isAuthenticated, logout } = useAuthStore();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!isAuthenticated || !user?.isAdmin) {
      router.push('/login');
    }
  }, [isAuthenticated, user]);

  if (!isAuthenticated || !user?.isAdmin) return null;

  const Sidebar = () => (
    <div className="flex flex-col h-full">
      <div className="px-5 py-4 border-b border-dark-800 flex items-center gap-2">
        <span className="text-xl font-bold text-brand-500">betAi</span>
        <span className="text-xs bg-red-500/20 text-red-400 px-1.5 py-0.5 rounded font-medium">ADMIN</span>
      </div>
      <nav className="flex-1 px-3 py-3 space-y-0.5 overflow-y-auto">
        {adminNav.map((item) => {
          const active = pathname === item.href || (item.href !== '/admin' && pathname.startsWith(item.href));
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={() => setOpen(false)}
              className={`flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all ${active ? 'bg-brand-500/15 text-brand-400' : 'text-dark-400 hover:text-white hover:bg-dark-800'}`}
            >
              <item.icon className="w-4 h-4 flex-shrink-0" />
              {item.label}
            </Link>
          );
        })}
      </nav>
      <div className="px-3 py-3 border-t border-dark-800">
        <button
          onClick={() => { logout(); router.push('/login'); }}
          className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-dark-400 hover:text-red-400 hover:bg-red-500/10 transition-all w-full"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-dark-950 overflow-hidden">
      <aside className="hidden lg:flex flex-col w-56 bg-dark-900 border-r border-dark-800 flex-shrink-0">
        <Sidebar />
      </aside>
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/60" onClick={() => setOpen(false)} />
          <aside className="absolute left-0 top-0 h-full w-56 bg-dark-900 border-r border-dark-800">
            <Sidebar />
          </aside>
        </div>
      )}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="bg-dark-900 border-b border-dark-800 h-14 px-4 flex items-center gap-3">
          <button onClick={() => setOpen(true)} className="lg:hidden text-dark-400">
            <Menu className="w-5 h-5" />
          </button>
          <span className="text-sm text-dark-400">{user.email}</span>
        </header>
        <main className="flex-1 overflow-y-auto p-4 sm:p-6">{children}</main>
      </div>
    </div>
  );
}
