'use client';
import { useQuery } from '@tanstack/react-query';
import { walletApi, bonusesApi, referralsApi } from '@/lib/api';
import { useAuthStore } from '@/lib/store';
import Link from 'next/link';
import {
  Wallet, Users, Clock, TrendingUp, ArrowUpRight, ArrowDownRight,
  Shield, AlertCircle, CheckCircle2
} from 'lucide-react';

function StatCard({ title, value, subtitle, icon: Icon, color = 'brand' }: any) {
  const colorMap: any = {
    brand: 'text-brand-400 bg-brand-500/10',
    green: 'text-green-400 bg-green-500/10',
    blue: 'text-blue-400 bg-blue-500/10',
    yellow: 'text-yellow-400 bg-yellow-500/10',
  };

  return (
    <div className="card hover:border-dark-700 transition-colors">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-dark-400 text-sm">{title}</p>
          <p className="text-2xl font-bold mt-1">{value}</p>
          {subtitle && <p className="text-xs text-dark-500 mt-0.5">{subtitle}</p>}
        </div>
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${colorMap[color]}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const { user } = useAuthStore();

  const { data: wallet } = useQuery({
    queryKey: ['wallet'],
    queryFn: () => walletApi.getOverview().then((r) => r.data),
  });

  const { data: bonus } = useQuery({
    queryKey: ['bonus-status'],
    queryFn: () => bonusesApi.getStatus().then((r) => r.data),
  });

  const { data: referral } = useQuery({
    queryKey: ['referral'],
    queryFn: () => referralsApi.getInfo().then((r) => r.data),
  });

  const totalBalance = wallet?.totalBalance?.toFixed(2) || '0.00';
  const daysRemaining = wallet?.bonusPeriod
    ? Math.max(0, Math.floor(parseFloat(wallet.bonusPeriod.days_remaining)))
    : null;
  const qualifiedReferrals = parseInt(wallet?.bonusPeriod?.qualified_referrals || '0');
  const conditionMet = qualifiedReferrals >= 1;

  const txTypeColor = (type: string) => {
    if (type === 'deposit' || type === 'bonus') return 'text-green-400';
    if (type === 'withdrawal') return 'text-red-400';
    return 'text-dark-300';
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Welcome */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-dark-400 text-sm mt-0.5">Welcome back, {user?.email || user?.phone}</p>
        </div>
        <div className="flex gap-2">
          <Link href="/wallet/deposit" className="btn-primary text-sm py-2 px-4">Deposit</Link>
          <Link href="/wallet/withdraw" className="btn-secondary text-sm py-2 px-4">Withdraw</Link>
        </div>
      </div>

      {/* KYC Banner */}
      {user?.kycStatus !== 'approved' && (
        <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4 flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0" />
          <div className="flex-1">
            <p className="text-yellow-300 text-sm font-medium">KYC Required for Withdrawals</p>
            <p className="text-yellow-400/70 text-xs mt-0.5">Verify your identity to unlock withdrawal functionality.</p>
          </div>
          <Link href="/kyc" className="text-yellow-400 text-sm font-medium border border-yellow-500/30 rounded-lg px-3 py-1.5 hover:bg-yellow-500/10">
            Verify Now
          </Link>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Balance"
          value={`${totalBalance} USDT`}
          subtitle="Available + Bonus"
          icon={Wallet}
          color="brand"
        />
        <StatCard
          title="Bonus Balance"
          value={`${wallet?.balances?.reduce((s: number, b: any) => s + parseFloat(b.bonus_balance || 0), 0)?.toFixed(2) || '0.00'} USDT`}
          subtitle="Earned rewards"
          icon={TrendingUp}
          color="green"
        />
        <StatCard
          title="Referrals"
          value={referral?.stats?.total || 0}
          subtitle={`${referral?.stats?.qualified || 0} qualified`}
          icon={Users}
          color="blue"
        />
        <StatCard
          title="Days Remaining"
          value={daysRemaining !== null ? `${daysRemaining}d` : 'No period'}
          subtitle="Current bonus period"
          icon={Clock}
          color="yellow"
        />
      </div>

      {/* Bonus Period Status */}
      {wallet?.bonusPeriod && (
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Bonus Period #{wallet.bonusPeriod.period_number}</h3>
            <span className="badge-info">Active</span>
          </div>
          <div className="grid sm:grid-cols-3 gap-4">
            <div className="bg-dark-800 rounded-lg p-3">
              <p className="text-xs text-dark-500">Days Remaining</p>
              <p className="text-xl font-bold text-brand-400 mt-0.5">{daysRemaining}d</p>
            </div>
            <div className="bg-dark-800 rounded-lg p-3">
              <p className="text-xs text-dark-500">Referral Condition</p>
              <div className="flex items-center gap-1.5 mt-0.5">
                {conditionMet
                  ? <CheckCircle2 className="w-4 h-4 text-green-400" />
                  : <AlertCircle className="w-4 h-4 text-yellow-400" />}
                <span className={`text-sm font-medium ${conditionMet ? 'text-green-400' : 'text-yellow-400'}`}>
                  {conditionMet ? 'Met' : 'Pending'}
                </span>
              </div>
            </div>
            <div className="bg-dark-800 rounded-lg p-3">
              <p className="text-xs text-dark-500">Next Bonus (est.)</p>
              <p className="text-xl font-bold text-green-400 mt-0.5">
                +{(parseFloat(totalBalance) * 0.02).toFixed(2)} USDT
              </p>
            </div>
          </div>
          {!conditionMet && (
            <div className="mt-3 text-xs text-yellow-400/70 bg-yellow-500/5 border border-yellow-500/20 rounded-lg p-2.5">
              ⚠ Invite at least 1 friend who deposits before the period ends to unlock your 2% bonus.
            </div>
          )}
        </div>
      )}

      {/* Recent Transactions */}
      <div className="card">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold">Recent Transactions</h3>
          <Link href="/wallet/history" className="text-brand-400 text-sm hover:text-brand-300">View all</Link>
        </div>
        {!wallet?.transactions?.length ? (
          <div className="text-center py-8 text-dark-500">
            <Wallet className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">No transactions yet</p>
            <Link href="/wallet/deposit" className="text-brand-400 text-sm mt-2 inline-block">Make your first deposit →</Link>
          </div>
        ) : (
          <div className="divide-y divide-dark-800">
            {wallet.transactions.slice(0, 8).map((tx: any) => (
              <div key={tx.id} className="flex items-center justify-between py-3">
                <div className="flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${tx.type === 'deposit' ? 'bg-green-500/10' : tx.type === 'withdrawal' ? 'bg-red-500/10' : 'bg-brand-500/10'}`}>
                    {tx.type === 'deposit'
                      ? <ArrowDownRight className="w-4 h-4 text-green-400" />
                      : tx.type === 'withdrawal'
                      ? <ArrowUpRight className="w-4 h-4 text-red-400" />
                      : <TrendingUp className="w-4 h-4 text-brand-400" />}
                  </div>
                  <div>
                    <p className="text-sm font-medium capitalize">{tx.type.replace('_', ' ')}</p>
                    <p className="text-xs text-dark-500">{new Date(tx.created_at).toLocaleDateString()}</p>
                  </div>
                </div>
                <div className={`font-semibold text-sm ${txTypeColor(tx.type)}`}>
                  {tx.type === 'withdrawal' ? '-' : '+'}{parseFloat(tx.amount).toFixed(2)} {tx.symbol}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
