'use client';
import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { AlertCircle, Loader2, Clock } from 'lucide-react';
import { walletApi, withdrawalsApi } from '@/lib/api';
import { useAuthStore } from '@/lib/store';

export default function WithdrawPage() {
  const { user } = useAuthStore();
  const { register, handleSubmit, watch, reset } = useForm<any>();
  const selectedAssetId = watch('assetId');

  const { data: assets } = useQuery({
    queryKey: ['assets'],
    queryFn: () => walletApi.getAssets().then((r) => r.data),
  });

  const { data: wallet } = useQuery({
    queryKey: ['wallet'],
    queryFn: () => walletApi.getOverview().then((r) => r.data),
  });

  const mutation = useMutation({
    mutationFn: (data: any) => withdrawalsApi.request(data).then((r) => r.data),
    onSuccess: () => {
      toast.success('Withdrawal request submitted! Up to 2 business days.');
      reset();
    },
    onError: (err: any) => {
      toast.error(err.response?.data?.message || 'Withdrawal failed');
    },
  });

  const selectedBalance = wallet?.balances?.find((b: any) => b.asset_id === selectedAssetId);
  const kycApproved = user?.kycStatus === 'approved';

  return (
    <div className="max-w-xl mx-auto space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold">Withdraw</h1>
        <p className="text-dark-400 text-sm mt-1">Minimum withdrawal: 100 USDT</p>
      </div>

      {!kycApproved && (
        <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 flex gap-3">
          <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
          <div>
            <p className="text-red-300 font-medium text-sm">KYC Required</p>
            <p className="text-red-400/70 text-xs mt-0.5">You must complete KYC verification before withdrawing.</p>
          </div>
        </div>
      )}

      <div className="bg-dark-800/50 border border-dark-700 rounded-xl p-4 flex gap-3">
        <Clock className="w-5 h-5 text-blue-400 flex-shrink-0" />
        <div className="text-sm text-dark-300">
          Withdrawal requests are processed manually by our team within <strong>2 business days</strong>.
        </div>
      </div>

      <form
        onSubmit={handleSubmit((data) => mutation.mutate(data))}
        className="card space-y-5"
      >
        <div>
          <label className="block text-sm font-medium text-dark-300 mb-1.5">Asset & Network</label>
          <select {...register('assetId', { required: true })} className="input-field">
            <option value="">Select asset...</option>
            {assets?.map((a: any) => (
              <option key={a.id} value={a.id}>{a.symbol} — {a.network}</option>
            ))}
          </select>
        </div>

        {selectedBalance && (
          <div className="bg-dark-800 rounded-lg px-4 py-2.5 text-sm flex items-center justify-between">
            <span className="text-dark-400">Available balance</span>
            <span className="font-semibold text-brand-400">
              {parseFloat(selectedBalance.available_balance).toFixed(2)} {selectedBalance.symbol}
            </span>
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-dark-300 mb-1.5">Amount</label>
          <input
            {...register('amount', { required: true, min: 100, valueAsNumber: true })}
            type="number"
            step="any"
            placeholder="100"
            className="input-field"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-dark-300 mb-1.5">Destination Address</label>
          <input
            {...register('toAddress', { required: true })}
            type="text"
            placeholder="Your wallet address"
            className="input-field font-mono text-sm"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-dark-300 mb-1.5">Network</label>
          <input
            {...register('network', { required: true })}
            type="text"
            placeholder="e.g. TRC20"
            className="input-field"
          />
        </div>

        <button
          type="submit"
          disabled={mutation.isPending || !kycApproved}
          className="btn-primary w-full flex items-center justify-center gap-2"
        >
          {mutation.isPending && <Loader2 className="w-5 h-5 animate-spin" />}
          Submit Withdrawal Request
        </button>
      </form>
    </div>
  );
}
