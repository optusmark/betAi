'use client';
import { useQuery } from '@tanstack/react-query';
import { depositsApi, withdrawalsApi } from '@/lib/api';
import { ArrowDownLeft, ArrowUpRight } from 'lucide-react';
import { useState } from 'react';

export default function WalletHistoryPage() {
  const [tab, setTab] = useState<'deposits' | 'withdrawals'>('deposits');

  const { data: deposits } = useQuery({
    queryKey: ['deposit-history'],
    queryFn: () => depositsApi.getHistory().then((r) => r.data),
  });

  const { data: withdrawals } = useQuery({
    queryKey: ['withdrawal-history'],
    queryFn: () => withdrawalsApi.getHistory().then((r) => r.data),
  });

  const statusBadge = (status: string) => {
    if (status === 'confirmed' || status === 'approved') return 'badge-success';
    if (status === 'rejected') return 'badge-error';
    if (status === 'in_review') return 'badge-info';
    return 'badge-warning';
  };

  return (
    <div className="space-y-5 animate-fade-in">
      <h1 className="text-2xl font-bold">Transaction History</h1>

      <div className="flex bg-dark-800 rounded-lg p-1 w-fit">
        {(['deposits', 'withdrawals'] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-5 py-2 rounded-md text-sm font-medium transition-all capitalize ${tab === t ? 'bg-brand-500 text-white' : 'text-dark-400'}`}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="card p-0 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="border-b border-dark-800">
              <tr className="text-dark-400 text-xs">
                <th className="px-4 py-3 text-left">Type</th>
                <th className="px-4 py-3 text-left">Amount</th>
                <th className="px-4 py-3 text-left">Network</th>
                <th className="px-4 py-3 text-left">Status</th>
                <th className="px-4 py-3 text-left">Date</th>
                <th className="px-4 py-3 text-left">Tx Hash</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-dark-800">
              {(tab === 'deposits' ? deposits : withdrawals)?.map((tx: any) => (
                <tr key={tx.id} className="hover:bg-dark-800/30">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className={`w-7 h-7 rounded-full flex items-center justify-center ${tab === 'deposits' ? 'bg-green-500/10' : 'bg-red-500/10'}`}>
                        {tab === 'deposits'
                          ? <ArrowDownLeft className="w-4 h-4 text-green-400" />
                          : <ArrowUpRight className="w-4 h-4 text-red-400" />}
                      </div>
                      <span className="capitalize">{tab.slice(0, -1)}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 font-semibold">
                    <span className={tab === 'deposits' ? 'text-green-400' : 'text-red-400'}>
                      {tab === 'deposits' ? '+' : '-'}{parseFloat(tx.amount).toFixed(2)} {tx.symbol}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-dark-400">{tx.network}</td>
                  <td className="px-4 py-3"><span className={statusBadge(tx.status)}>{tx.status.replace('_', ' ')}</span></td>
                  <td className="px-4 py-3 text-dark-500">{new Date(tx.created_at).toLocaleDateString()}</td>
                  <td className="px-4 py-3 font-mono text-xs text-dark-500 max-w-24 truncate">
                    {tx.tx_hash || '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {!(tab === 'deposits' ? deposits : withdrawals)?.length && (
            <div className="text-center py-10 text-dark-500">No {tab} found</div>
          )}
        </div>
      </div>
    </div>
  );
}
