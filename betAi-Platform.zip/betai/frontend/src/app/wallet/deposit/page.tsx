'use client';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { QRCodeSVG } from 'qrcode.react';
import toast from 'react-hot-toast';
import { Copy, CheckCheck, Info } from 'lucide-react';
import { walletApi, depositsApi } from '@/lib/api';

export default function DepositPage() {
  const [selectedAssetId, setSelectedAssetId] = useState('');
  const [copied, setCopied] = useState(false);

  const { data: assets } = useQuery({
    queryKey: ['assets'],
    queryFn: () => walletApi.getAssets().then((r) => r.data),
  });

  const { data: addressData } = useQuery({
    queryKey: ['deposit-address', selectedAssetId],
    queryFn: () => depositsApi.getAddress(selectedAssetId).then((r) => r.data),
    enabled: !!selectedAssetId,
  });

  const handleCopy = () => {
    if (addressData?.address) {
      navigator.clipboard.writeText(addressData.address);
      setCopied(true);
      toast.success('Address copied!');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="max-w-xl mx-auto space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-bold">Deposit</h1>
        <p className="text-dark-400 text-sm mt-1">Minimum deposit: 100 USDT</p>
      </div>

      {/* Info banner */}
      <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4 flex gap-3">
        <Info className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
        <div className="text-sm text-blue-300/80">
          <p className="font-medium text-blue-300 mb-1">First Deposit Starts Your 40-Day Period</p>
          <p>After your first deposit, you have 40 days to invite at least one friend who also deposits. Complete this to unlock your 2% bonus.</p>
        </div>
      </div>

      {/* Asset selector */}
      <div className="card">
        <label className="block text-sm font-medium text-dark-300 mb-2">Select Asset & Network</label>
        <select
          value={selectedAssetId}
          onChange={(e) => setSelectedAssetId(e.target.value)}
          className="input-field"
        >
          <option value="">Choose cryptocurrency...</option>
          {assets?.map((a: any) => (
            <option key={a.id} value={a.id}>
              {a.symbol} — {a.network}
            </option>
          ))}
        </select>
      </div>

      {/* Deposit address */}
      {addressData && (
        <div className="card space-y-4 animate-fade-in">
          <div className="flex justify-center">
            <div className="bg-white p-4 rounded-xl">
              <QRCodeSVG value={addressData.address} size={160} />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-dark-400 mb-1.5">
              Deposit Address ({addressData.network})
            </label>
            <div className="flex gap-2">
              <div className="flex-1 bg-dark-800 rounded-lg px-4 py-3 font-mono text-sm text-dark-300 break-all border border-dark-700">
                {addressData.address}
              </div>
              <button
                onClick={handleCopy}
                className="btn-secondary px-4 flex-shrink-0"
                title="Copy address"
              >
                {copied ? <CheckCheck className="w-5 h-5 text-green-400" /> : <Copy className="w-5 h-5" />}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="bg-dark-800 rounded-lg p-3">
              <p className="text-dark-500 text-xs">Min. Deposit</p>
              <p className="font-semibold mt-0.5">{addressData.minDeposit} {addressData.symbol}</p>
            </div>
            <div className="bg-dark-800 rounded-lg p-3">
              <p className="text-dark-500 text-xs">Network</p>
              <p className="font-semibold mt-0.5">{addressData.network}</p>
            </div>
          </div>

          <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3 text-xs text-yellow-300/80">
            ⚠ Only send <strong>{addressData.symbol}</strong> on the <strong>{addressData.network}</strong> network to this address. Sending other assets will result in permanent loss.
          </div>
        </div>
      )}
    </div>
  );
}
