'use client';
import { useQuery } from '@tanstack/react-query';
import Link from 'next/link';
import { walletApi } from '@/lib/api';
import { ArrowDownLeft, ArrowUpRight, History, TrendingUp } from 'lucide-react';

export default function WalletPage() {
  const { data: wallet, isLoading } = useQuery({
    queryKey: ['wallet'],
    queryFn: () => walletApi.getOverview().then((r) => r.data),
  });

  return (
    <div className="space-y-6 animate-fade-in">
      <h1 className="text-2xl font-bold">Wallet</h1>

      {/* Total Balance */}
      <div className="card bg-gradient-to-br from-brand-500/10 to-transparent border-brand-500/20">
        <p className="text-dark-400 text-sm">Total Balance</p>
        <p className="text-4xl font-bold mt-1">
          {isLoading ? '...' : `${wallet?.totalBalance?.toFixed(2) || '0.00'}`}
          <span className="text-xl text-dark-400 ml-2">USDT</span>
        </p>
      </div>

      {/* Actions */}
      <div className="grid grid-cols-3 gap-4">
        <Link href="/wallet/deposit" className="card flex flex-col items-center gap-2 hover:border-brand-500/30 transition-colors text-center cursor-pointer">
          <div className="w-12 h-12 bg-green-500/10 rounded-xl flex items-center justify-center">
            <ArrowDownLeft className="w-6 h-6 text-green-400" />
          </div>
          <span className="text-sm font-medium">Deposit</span>
        </Link>
        <Link href="/wallet/withdraw" className="card flex flex-col items-center gap-2 hover:border-brand-500/30 transition-colors text-center cursor-pointer">
          <div className="w-12 h-12 bg-red-500/10 rounded-xl flex items-center justify-center">
            <ArrowUpRight className="w-6 h-6 text-red-400" />
          </div>
          <span className="text-sm font-medium">Withdraw</span>
        </Link>
        <Link href="/wallet/history" className="card flex flex-col items-center gap-2 hover:border-brand-500/30 transition-colors text-center cursor-pointer">
          <div className="w-12 h-12 bg-blue-500/10 rounded-xl flex items-center justify-center">
            <History className="w-6 h-6 text-blue-400" />
          </div>
          <span className="text-sm font-medium">History</span>
        </Link>
      </div>

      {/* Assets */}
      <div className="card">
        <h3 className="font-semibold mb-4">My Assets</h3>
        {!wallet?.balances?.length ? (
          <div className="text-center py-8 text-dark-500">
            <TrendingUp className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm mb-3">No assets yet</p>
            <Link href="/wallet/deposit" className="btn-primary text-sm">Make a Deposit</Link>
          </div>
        ) : (
          <div className="space-y-3">
            {wallet.balances.map((b: any) => (
              <div key={b.id} className="flex items-center justify-between bg-dark-800 rounded-xl p-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-dark-700 rounded-full flex items-center justify-center text-sm font-bold text-brand-400">
                    {b.symbol?.slice(0, 2)}
                  </div>
                  <div>
                    <p className="font-medium">{b.symbol}</p>
                    <p className="text-xs text-dark-500">{b.network}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-semibold">{parseFloat(b.available_balance).toFixed(2)}</p>
                  {parseFloat(b.bonus_balance) > 0 && (
                    <p className="text-xs text-green-400">+{parseFloat(b.bonus_balance).toFixed(2)} bonus</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
