'use client';
import Link from 'next/link';
import { Shield, TrendingUp, Users, Zap, ChevronRight, Lock } from 'lucide-react';

export default function HomePage() {
  const features = [
    { icon: Shield, title: 'Secure Platform', desc: 'Bank-grade security with 2FA and KYC verification.' },
    { icon: TrendingUp, title: '2% Bonus Every 40 Days', desc: 'Earn bonuses on your balance by growing your referral network.' },
    { icon: Users, title: 'Referral System', desc: 'Invite friends and unlock your earning potential.' },
    { icon: Zap, title: 'Fast Deposits', desc: 'Multi-chain support: TRC20, ERC20, BTC and more.' },
    { icon: Lock, title: 'KYC Verified', desc: 'Quick, free KYC verification for secure withdrawals.' },
  ];

  return (
    <div className="min-h-screen bg-dark-950">
      {/* Nav */}
      <nav className="border-b border-dark-800 bg-dark-950/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16">
          <span className="text-2xl font-bold text-brand-500 tracking-tight">betAi</span>
          <div className="flex items-center gap-4">
            <Link href="/login" className="text-dark-400 hover:text-white transition-colors text-sm font-medium">
              Sign In
            </Link>
            <Link href="/register" className="btn-primary text-sm py-2 px-4 rounded-lg">
              Get Started
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative py-24 px-4 text-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-brand-500/5 via-transparent to-blue-500/5" />
        <div className="relative max-w-4xl mx-auto">
          <div className="inline-flex items-center gap-2 bg-brand-500/10 border border-brand-500/20 rounded-full px-4 py-1.5 text-sm text-brand-400 mb-6">
            <span className="w-2 h-2 bg-brand-500 rounded-full animate-pulse" />
            Premium Crypto Investment Platform
          </div>
          <h1 className="text-5xl sm:text-6xl font-bold text-white leading-tight mb-6">
            Grow Your Crypto
            <span className="text-brand-500"> Assets</span>
            <br />with betAi
          </h1>
          <p className="text-xl text-dark-400 mb-10 max-w-2xl mx-auto">
            Earn 2% bonus every 40 days. Invite friends, complete referrals, and unlock compounding rewards.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/register" className="btn-primary flex items-center justify-center gap-2 text-lg">
              Start Earning <ChevronRight className="w-5 h-5" />
            </Link>
            <Link href="/login" className="btn-secondary flex items-center justify-center gap-2 text-lg">
              Sign In
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 border-y border-dark-800">
        <div className="max-w-5xl mx-auto px-4 grid grid-cols-2 sm:grid-cols-4 gap-8 text-center">
          {[
            { label: 'Minimum Deposit', value: '100 USDT' },
            { label: 'Bonus Rate', value: '2% / 40d' },
            { label: 'Supported Networks', value: 'TRC20 & more' },
            { label: 'Withdrawal Time', value: '≤ 2 days' },
          ].map((s) => (
            <div key={s.label}>
              <div className="text-2xl font-bold text-brand-400">{s.value}</div>
              <div className="text-sm text-dark-500 mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose betAi?</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((f) => (
              <div key={f.title} className="card hover:border-brand-500/30 transition-colors">
                <div className="w-12 h-12 bg-brand-500/10 rounded-xl flex items-center justify-center mb-4">
                  <f.icon className="w-6 h-6 text-brand-500" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{f.title}</h3>
                <p className="text-dark-400 text-sm leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Bonus Explanation */}
      <section className="py-16 px-4 bg-dark-900/50">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">How the Bonus Works</h2>
          <div className="grid sm:grid-cols-3 gap-6 mb-8">
            {[
              { step: '1', title: 'Deposit', desc: 'Deposit minimum 100 USDT to start your 40-day period.' },
              { step: '2', title: 'Invite', desc: 'Invite at least one friend who also deposits within 40 days.' },
              { step: '3', title: 'Earn', desc: 'Receive 2% of your current balance every 40 days, forever.' },
            ].map((s) => (
              <div key={s.step} className="card text-center">
                <div className="w-10 h-10 bg-brand-500 rounded-full flex items-center justify-center text-white font-bold text-lg mx-auto mb-3">
                  {s.step}
                </div>
                <h4 className="font-semibold mb-1">{s.title}</h4>
                <p className="text-dark-400 text-sm">{s.desc}</p>
              </div>
            ))}
          </div>
          <Link href="/register" className="btn-primary inline-flex items-center gap-2">
            Create Account <ChevronRight className="w-4 h-4" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-dark-800 py-8 text-center text-dark-500 text-sm">
        <p>© {new Date().getFullYear()} betAi Platform. All rights reserved.</p>
      </footer>
    </div>
  );
}
