'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { Eye, EyeOff, Loader2 } from 'lucide-react';
import { authApi, userApi } from '@/lib/api';
import { useAuthStore } from '@/lib/store';

interface LoginForm {
  identifier: string;
  password: string;
  twoFaCode?: string;
}

export default function LoginPage() {
  const router = useRouter();
  const setAuth = useAuthStore((s) => s.setAuth);
  const [showPass, setShowPass] = useState(false);
  const [requires2FA, setRequires2FA] = useState(false);
  const [loading, setLoading] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm<LoginForm>();

  const onSubmit = async (data: LoginForm) => {
    setLoading(true);
    try {
      const res = await authApi.login(data);
      const { accessToken, refreshToken, user } = res.data;

      setAuth(user, accessToken, refreshToken);
      toast.success('Welcome back!');

      if (user.isAdmin) {
        router.push('/admin');
      } else {
        router.push('/dashboard');
      }
    } catch (err: any) {
      const msg = err.response?.data?.message || 'Login failed';
      if (msg.includes('2FA')) {
        setRequires2FA(true);
        toast.error('Please enter your 2FA code');
      } else {
        toast.error(msg);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-dark-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <Link href="/" className="text-3xl font-bold text-brand-500">betAi</Link>
          <p className="text-dark-400 mt-2">Sign in to your account</p>
        </div>

        <div className="card animate-fade-in">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-dark-300 mb-1.5">
                Email or Phone
              </label>
              <input
                {...register('identifier', { required: 'Required' })}
                type="text"
                placeholder="you@example.com"
                className="input-field"
              />
              {errors.identifier && (
                <p className="text-red-400 text-xs mt-1">{errors.identifier.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-dark-300 mb-1.5">Password</label>
              <div className="relative">
                <input
                  {...register('password', { required: 'Required' })}
                  type={showPass ? 'text' : 'password'}
                  placeholder="••••••••"
                  className="input-field pr-12"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-dark-500 hover:text-dark-300"
                >
                  {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              {errors.password && (
                <p className="text-red-400 text-xs mt-1">{errors.password.message}</p>
              )}
            </div>

            {requires2FA && (
              <div>
                <label className="block text-sm font-medium text-dark-300 mb-1.5">2FA Code</label>
                <input
                  {...register('twoFaCode')}
                  type="text"
                  placeholder="6-digit code"
                  maxLength={6}
                  className="input-field text-center tracking-widest text-xl"
                />
              </div>
            )}

            <div className="flex items-center justify-between text-sm">
              <span />
              <Link href="/forgot-password" className="text-brand-400 hover:text-brand-300">
                Forgot password?
              </Link>
            </div>

            <button type="submit" disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2">
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : null}
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>

          <div className="mt-6 text-center text-sm text-dark-400">
            Don't have an account?{' '}
            <Link href="/register" className="text-brand-400 hover:text-brand-300 font-medium">
              Create one
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
