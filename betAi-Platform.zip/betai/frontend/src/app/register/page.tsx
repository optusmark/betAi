'use client';
import { useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { Eye, EyeOff, Loader2, CheckCircle2 } from 'lucide-react';
import { authApi } from '@/lib/api';

interface RegisterForm {
  email?: string;
  phone?: string;
  password: string;
  confirmPassword: string;
  referralCode?: string;
  acceptTerms: boolean;
}

export default function RegisterPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const refCode = searchParams.get('ref') || '';

  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [usePhone, setUsePhone] = useState(false);

  const { register, handleSubmit, watch, formState: { errors } } = useForm<RegisterForm>({
    defaultValues: { referralCode: refCode, acceptTerms: false },
  });

  const password = watch('password');

  const onSubmit = async (data: RegisterForm) => {
    if (!data.email && !data.phone) {
      toast.error('Provide email or phone');
      return;
    }
    if (data.password !== data.confirmPassword) {
      toast.error('Passwords do not match');
      return;
    }
    if (!data.acceptTerms) {
      toast.error('Please accept the terms');
      return;
    }

    setLoading(true);
    try {
      await authApi.register({
        email: usePhone ? undefined : data.email,
        phone: usePhone ? data.phone : undefined,
        password: data.password,
        referralCode: data.referralCode || undefined,
        acceptTerms: data.acceptTerms,
      });
      setSuccess(true);
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="min-h-screen bg-dark-950 flex items-center justify-center p-4">
        <div className="card text-center max-w-md w-full animate-fade-in">
          <CheckCircle2 className="w-16 h-16 text-green-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Account Created!</h2>
          <p className="text-dark-400 mb-6">Please check your email to verify your account.</p>
          <Link href="/login" className="btn-primary">Sign In</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link href="/" className="text-3xl font-bold text-brand-500">betAi</Link>
          <p className="text-dark-400 mt-2">Create your account</p>
        </div>

        <div className="card animate-fade-in">
          {/* Toggle email/phone */}
          <div className="flex bg-dark-800 rounded-lg p-1 mb-5">
            <button
              type="button"
              onClick={() => setUsePhone(false)}
              className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${!usePhone ? 'bg-brand-500 text-white' : 'text-dark-400'}`}
            >
              Email
            </button>
            <button
              type="button"
              onClick={() => setUsePhone(true)}
              className={`flex-1 py-2 text-sm font-medium rounded-md transition-all ${usePhone ? 'bg-brand-500 text-white' : 'text-dark-400'}`}
            >
              Phone
            </button>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            {!usePhone ? (
              <div>
                <label className="block text-sm font-medium text-dark-300 mb-1.5">Email</label>
                <input
                  {...register('email', { required: !usePhone })}
                  type="email"
                  placeholder="you@example.com"
                  className="input-field"
                />
              </div>
            ) : (
              <div>
                <label className="block text-sm font-medium text-dark-300 mb-1.5">Phone</label>
                <input
                  {...register('phone', { required: usePhone })}
                  type="tel"
                  placeholder="+1 234 567 8900"
                  className="input-field"
                />
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-dark-300 mb-1.5">Password</label>
              <div className="relative">
                <input
                  {...register('password', { required: true, minLength: 8 })}
                  type={showPass ? 'text' : 'password'}
                  placeholder="Min. 8 characters"
                  className="input-field pr-12"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-dark-500 hover:text-dark-300"
                >
                  {showPass ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              {errors.password?.type === 'minLength' && (
                <p className="text-red-400 text-xs mt-1">Minimum 8 characters</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-dark-300 mb-1.5">Confirm Password</label>
              <input
                {...register('confirmPassword', {
                  validate: (v) => v === password || 'Passwords do not match',
                })}
                type="password"
                placeholder="Repeat password"
                className="input-field"
              />
              {errors.confirmPassword && (
                <p className="text-red-400 text-xs mt-1">{errors.confirmPassword.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-dark-300 mb-1.5">
                Referral Code <span className="text-dark-500">(optional)</span>
              </label>
              <input
                {...register('referralCode')}
                type="text"
                placeholder="e.g. betAiABC123"
                className="input-field"
              />
            </div>

            <label className="flex items-start gap-3 cursor-pointer">
              <input
                {...register('acceptTerms')}
                type="checkbox"
                className="mt-0.5 accent-brand-500"
              />
              <span className="text-sm text-dark-400">
                I agree to the{' '}
                <Link href="/terms" className="text-brand-400 hover:underline">Terms of Service</Link>
                {' '}and{' '}
                <Link href="/privacy" className="text-brand-400 hover:underline">Privacy Policy</Link>
              </span>
            </label>

            <button type="submit" disabled={loading} className="btn-primary w-full flex items-center justify-center gap-2">
              {loading && <Loader2 className="w-5 h-5 animate-spin" />}
              {loading ? 'Creating account...' : 'Create Account'}
            </button>
          </form>

          <div className="mt-5 text-center text-sm text-dark-400">
            Already have an account?{' '}
            <Link href="/login" className="text-brand-400 hover:text-brand-300 font-medium">Sign in</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
