'use client';
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supportApi } from '@/lib/api';
import toast from 'react-hot-toast';
import { Send, Loader2, Plus, X } from 'lucide-react';

export default function SupportPage() {
  const qc = useQueryClient();
  const [activeTicket, setActiveTicket] = useState<any>(null);
  const [reply, setReply] = useState('');
  const [showNew, setShowNew] = useState(false);
  const [newTicket, setNewTicket] = useState({ subject: '', message: '' });

  const { data: tickets } = useQuery({
    queryKey: ['tickets'],
    queryFn: () => supportApi.getTickets().then((r) => r.data),
  });

  const { data: conversation, refetch: refetchConvo } = useQuery({
    queryKey: ['ticket-convo', activeTicket?.id],
    queryFn: () => supportApi.getMessages(activeTicket.id).then((r) => r.data),
    enabled: !!activeTicket?.id,
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => supportApi.createTicket(data).then((r) => r.data),
    onSuccess: () => {
      toast.success('Ticket created');
      qc.invalidateQueries({ queryKey: ['tickets'] });
      setShowNew(false);
      setNewTicket({ subject: '', message: '' });
    },
    onError: (err: any) => toast.error(err.response?.data?.message || 'Failed'),
  });

  const replyMutation = useMutation({
    mutationFn: ({ id, message }: any) => supportApi.reply(id, message).then((r) => r.data),
    onSuccess: () => {
      setReply('');
      refetchConvo();
    },
    onError: (err: any) => toast.error(err.response?.data?.message || 'Failed'),
  });

  const statusBadge = (status: string) => {
    const map: any = { open: 'badge-success', in_progress: 'badge-info', resolved: 'badge-warning', closed: 'text-dark-500 text-xs' };
    return map[status] || 'badge-info';
  };

  return (
    <div className="space-y-5 animate-fade-in">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Support</h1>
        <button onClick={() => setShowNew(true)} className="btn-primary text-sm py-2 px-4 flex items-center gap-2">
          <Plus className="w-4 h-4" /> New Ticket
        </button>
      </div>

      {/* New ticket form */}
      {showNew && (
        <div className="card space-y-4 animate-fade-in">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">New Ticket</h3>
            <button onClick={() => setShowNew(false)} className="text-dark-400 hover:text-white"><X className="w-5 h-5" /></button>
          </div>
          <input
            value={newTicket.subject}
            onChange={(e) => setNewTicket(p => ({ ...p, subject: e.target.value }))}
            placeholder="Subject"
            className="input-field"
          />
          <textarea
            value={newTicket.message}
            onChange={(e) => setNewTicket(p => ({ ...p, message: e.target.value }))}
            placeholder="Describe your issue..."
            rows={4}
            className="input-field"
          />
          <button
            onClick={() => createMutation.mutate(newTicket)}
            disabled={createMutation.isPending || !newTicket.subject || !newTicket.message}
            className="btn-primary flex items-center justify-center gap-2"
          >
            {createMutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
            Submit Ticket
          </button>
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-5">
        {/* Ticket list */}
        <div className="lg:col-span-1 space-y-2">
          {!tickets?.length ? (
            <div className="card text-center py-8 text-dark-500">
              <p className="text-sm">No tickets yet</p>
            </div>
          ) : tickets.map((t: any) => (
            <button
              key={t.id}
              onClick={() => setActiveTicket(t)}
              className={`w-full text-left card transition-colors ${activeTicket?.id === t.id ? 'border-brand-500/40 bg-brand-500/5' : 'hover:border-dark-700'}`}
            >
              <div className="flex items-start justify-between gap-2 mb-1">
                <p className="text-sm font-medium truncate">{t.subject}</p>
                <span className={statusBadge(t.status)}>{t.status.replace('_', ' ')}</span>
              </div>
              <p className="text-xs text-dark-500 truncate">{t.last_message}</p>
              <p className="text-xs text-dark-600 mt-1">{t.ticket_number} · {new Date(t.created_at).toLocaleDateString()}</p>
            </button>
          ))}
        </div>

        {/* Conversation */}
        <div className="lg:col-span-2">
          {!activeTicket ? (
            <div className="card h-64 flex items-center justify-center text-dark-500 text-sm">
              Select a ticket to view conversation
            </div>
          ) : (
            <div className="card flex flex-col h-[500px]">
              <div className="border-b border-dark-800 pb-3 mb-3">
                <p className="font-semibold">{activeTicket.subject}</p>
                <p className="text-xs text-dark-500">{activeTicket.ticket_number}</p>
              </div>
              <div className="flex-1 overflow-y-auto space-y-3 mb-3">
                {conversation?.messages?.map((m: any) => (
                  <div key={m.id} className={`flex ${m.is_admin_reply ? 'justify-start' : 'justify-end'}`}>
                    <div className={`max-w-xs lg:max-w-sm px-4 py-2.5 rounded-xl text-sm ${m.is_admin_reply ? 'bg-dark-800' : 'bg-brand-500/20 border border-brand-500/30'}`}>
                      {m.is_admin_reply && (
                        <p className="text-xs text-brand-400 font-medium mb-1">Support Team</p>
                      )}
                      <p>{m.message}</p>
                      <p className="text-xs text-dark-500 mt-1">{new Date(m.created_at).toLocaleTimeString()}</p>
                    </div>
                  </div>
                ))}
              </div>
              {activeTicket.status !== 'closed' && (
                <div className="flex gap-2 border-t border-dark-800 pt-3">
                  <input
                    value={reply}
                    onChange={(e) => setReply(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && replyMutation.mutate({ id: activeTicket.id, message: reply })}
                    placeholder="Type a message..."
                    className="input-field flex-1"
                  />
                  <button
                    onClick={() => replyMutation.mutate({ id: activeTicket.id, message: reply })}
                    disabled={replyMutation.isPending || !reply.trim()}
                    className="btn-primary px-4"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
