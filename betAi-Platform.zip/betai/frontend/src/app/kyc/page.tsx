'use client';
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { kycApi } from '@/lib/api';
import toast from 'react-hot-toast';
import { Shield, CheckCircle2, Clock, XCircle, Upload, Loader2 } from 'lucide-react';

const statusConfig: any = {
  not_submitted: { label: 'Not Submitted', icon: Shield, color: 'text-dark-400', bg: 'bg-dark-800' },
  pending: { label: 'Pending Review', icon: Clock, color: 'text-yellow-400', bg: 'bg-yellow-500/10' },
  under_review: { label: 'Under Review', icon: Clock, color: 'text-blue-400', bg: 'bg-blue-500/10' },
  approved: { label: 'Approved', icon: CheckCircle2, color: 'text-green-400', bg: 'bg-green-500/10' },
  rejected: { label: 'Rejected', icon: XCircle, color: 'text-red-400', bg: 'bg-red-500/10' },
};

export default function KycPage() {
  const qc = useQueryClient();
  const [docType, setDocType] = useState('passport');
  const [files, setFiles] = useState<any>({ front: null, back: null, selfie: null });

  const { data: kyc } = useQuery({
    queryKey: ['kyc-status'],
    queryFn: () => kycApi.getStatus().then((r) => r.data),
  });

  const status = kyc?.status || 'not_submitted';
  const cfg = statusConfig[status] || statusConfig.not_submitted;

  const mutation = useMutation({
    mutationFn: (fd: FormData) => kycApi.submit(fd).then((r) => r.data),
    onSuccess: () => {
      toast.success('KYC submitted successfully!');
      qc.invalidateQueries({ queryKey: ['kyc-status'] });
    },
    onError: (err: any) => toast.error(err.response?.data?.message || 'Submission failed'),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!files.front) { toast.error('Front image required'); return; }

    const fd = new FormData();
    fd.append('documentType', docType);
    fd.append('front', files.front);
    if (files.back) fd.append('back', files.back);
    if (files.selfie) fd.append('selfie', files.selfie);
    mutation.mutate(fd);
  };

  const FileInput = ({ label, field }: { label: string; field: string }) => (
    <div>
      <label className="block text-sm font-medium text-dark-300 mb-1.5">{label}</label>
      <label className={`flex flex-col items-center justify-center border-2 border-dashed rounded-xl p-6 cursor-pointer transition-colors ${files[field] ? 'border-brand-500/50 bg-brand-500/5' : 'border-dark-700 hover:border-dark-600'}`}>
        <Upload className="w-6 h-6 text-dark-500 mb-2" />
        <span className="text-sm text-dark-400">
          {files[field] ? files[field].name : 'Click to upload'}
        </span>
        <input
          type="file"
          className="hidden"
          accept="image/*,.pdf"
          onChange={(e) => setFiles((prev: any) => ({ ...prev, [field]: e.target.files?.[0] }))}
        />
      </label>
    </div>
  );

  return (
    <div className="max-w-xl mx-auto space-y-6 animate-fade-in">
      <h1 className="text-2xl font-bold">KYC Verification</h1>

      {/* Status Card */}
      <div className={`card ${cfg.bg} border-0`}>
        <div className="flex items-center gap-3">
          <cfg.icon className={`w-8 h-8 ${cfg.color}`} />
          <div>
            <p className="font-semibold">Status: <span className={cfg.color}>{cfg.label}</span></p>
            {status === 'approved' && (
              <p className="text-sm text-green-400/70 mt-0.5">Withdrawals are now unlocked.</p>
            )}
            {status === 'rejected' && kyc?.rejection_reason && (
              <p className="text-sm text-red-400/70 mt-0.5">Reason: {kyc.rejection_reason}</p>
            )}
          </div>
        </div>
      </div>

      {/* Info */}
      <div className="card text-sm text-dark-400 space-y-2">
        <p className="font-medium text-white">About KYC</p>
        <ul className="space-y-1 list-disc list-inside">
          <li>KYC verification is <strong className="text-white">free</strong></li>
          <li>No deposit required to submit KYC</li>
          <li>Without KYC: deposits allowed, withdrawals blocked</li>
          <li>Review takes 1-3 business days</li>
        </ul>
      </div>

      {/* Submit Form */}
      {['not_submitted', 'rejected'].includes(status) && (
        <form onSubmit={handleSubmit} className="card space-y-5">
          <h3 className="font-semibold">Submit Documents</h3>

          <div>
            <label className="block text-sm font-medium text-dark-300 mb-1.5">Document Type</label>
            <select
              value={docType}
              onChange={(e) => setDocType(e.target.value)}
              className="input-field"
            >
              <option value="passport">Passport</option>
              <option value="id_card">National ID Card</option>
              <option value="drivers_license">Driver's License</option>
            </select>
          </div>

          <FileInput label="Front Side *" field="front" />
          <FileInput label="Back Side" field="back" />
          <FileInput label="Selfie with Document" field="selfie" />

          <button
            type="submit"
            disabled={mutation.isPending}
            className="btn-primary w-full flex items-center justify-center gap-2"
          >
            {mutation.isPending && <Loader2 className="w-5 h-5 animate-spin" />}
            Submit for Review
          </button>
        </form>
      )}
    </div>
  );
}
