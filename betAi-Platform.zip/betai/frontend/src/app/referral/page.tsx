'use client';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { referralsApi, bonusesApi } from '@/lib/api';
import toast from 'react-hot-toast';
import { Copy, CheckCheck, Users, TrendingUp, Clock, CheckCircle2, AlertCircle } from 'lucide-react';

export default function ReferralPage() {
  const [copied, setCopied] = useState(false);

  const { data: referral } = useQuery({
    queryKey: ['referral'],
    queryFn: () => referralsApi.getInfo().then((r) => r.data),
  });

  const { data: bonus } = useQuery({
    queryKey: ['bonus-status'],
    queryFn: () => bonusesApi.getStatus().then((r) => r.data),
  });

  const handleCopy = () => {
    if (referral?.referralLink) {
      navigator.clipboard.writeText(referral.referralLink);
      setCopied(true);
      toast.success('Link copied!');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const daysRemaining = referral?.currentPeriod
    ? Math.max(0, Math.floor(parseFloat(referral.currentPeriod.days_remaining)))
    : null;

  return (
    <div className="space-y-6 animate-fade-in max-w-2xl">
      <h1 className="text-2xl font-bold">Referral Program</h1>

      {/* Referral Link */}
      <div className="card space-y-4">
        <div>
          <p className="text-sm text-dark-400 mb-1">Your Referral Code</p>
          <p className="text-2xl font-bold text-brand-400 font-mono">{referral?.referralCode || '—'}</p>
        </div>
        <div>
          <p className="text-sm text-dark-400 mb-1.5">Referral Link</p>
          <div className="flex gap-2">
            <input
              readOnly
              value={referral?.referralLink || ''}
              className="input-field text-sm font-mono"
            />
            <button onClick={handleCopy} className="btn-secondary px-4 flex-shrink-0">
              {copied ? <CheckCheck className="w-5 h-5 text-green-400" /> : <Copy className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="card text-center">
          <Users className="w-6 h-6 text-brand-400 mx-auto mb-1" />
          <p className="text-xl font-bold">{referral?.stats?.total || 0}</p>
          <p className="text-xs text-dark-500">Total Invited</p>
        </div>
        <div className="card text-center">
          <CheckCircle2 className="w-6 h-6 text-green-400 mx-auto mb-1" />
          <p className="text-xl font-bold">{referral?.stats?.qualified || 0}</p>
          <p className="text-xs text-dark-500">Qualified</p>
        </div>
        <div className="card text-center">
          <Clock className="w-6 h-6 text-yellow-400 mx-auto mb-1" />
          <p className="text-xl font-bold">{daysRemaining !== null ? `${daysRemaining}d` : '—'}</p>
          <p className="text-xs text-dark-500">Days Left</p>
        </div>
      </div>

      {/* Condition status */}
      {referral?.currentPeriod && (
        <div className={`card border ${referral.stats?.qualified >= 1 ? 'border-green-500/30 bg-green-500/5' : 'border-yellow-500/30 bg-yellow-500/5'}`}>
          <div className="flex items-center gap-3">
            {referral.stats?.qualified >= 1
              ? <CheckCircle2 className="w-6 h-6 text-green-400" />
              : <AlertCircle className="w-6 h-6 text-yellow-400" />}
            <div>
              <p className="font-medium">
                {referral.stats?.qualified >= 1
                  ? 'Condition Met — Bonus Unlocked!'
                  : 'Condition Pending'}
              </p>
              <p className="text-sm text-dark-400 mt-0.5">
                {referral.stats?.qualified >= 1
                  ? 'Your 2% bonus will be credited when the period ends.'
                  : `Invite at least 1 friend who deposits within ${daysRemaining} days.`}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Referral list */}
      <div className="card">
        <h3 className="font-semibold mb-4">Invited Users ({referral?.referrals?.length || 0})</h3>
        {!referral?.referrals?.length ? (
          <div className="text-center py-6 text-dark-500">
            <Users className="w-8 h-8 mx-auto mb-2 opacity-40" />
            <p className="text-sm">No referrals yet. Share your link!</p>
          </div>
        ) : (
          <div className="space-y-2">
            {referral.referrals.map((r: any) => (
              <div key={r.id} className="flex items-center justify-between bg-dark-800 rounded-lg px-4 py-3">
                <div>
                  <p className="text-sm font-medium">{r.referred_email || r.referred_phone || 'Unknown'}</p>
                  <p className="text-xs text-dark-500">{new Date(r.registered_at).toLocaleDateString()}</p>
                </div>
                <div className="text-right">
                  {r.is_qualified
                    ? <span className="badge-success">Qualified</span>
                    : <span className="badge-warning">Pending deposit</span>}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Bonus history */}
      {bonus?.history?.length > 0 && (
        <div className="card">
          <h3 className="font-semibold mb-4">Bonus History</h3>
          <div className="space-y-2">
            {bonus.history.map((h: any) => (
              <div key={h.id} className="flex items-center justify-between bg-dark-800 rounded-lg px-4 py-3">
                <div>
                  <p className="text-sm">{h.description || 'Bonus credited'}</p>
                  <p className="text-xs text-dark-500">{new Date(h.paid_at).toLocaleDateString()}</p>
                </div>
                <p className="text-green-400 font-semibold">+{parseFloat(h.amount).toFixed(2)} USDT</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
