'use client';
import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { authApi, userApi } from '@/lib/api';
import { useAuthStore } from '@/lib/store';
import { Loader2, Shield, KeyRound, User, QrCode } from 'lucide-react';

export default function SettingsPage() {
  const { user, updateUser } = useAuthStore();
  const qc = useQueryClient();
  const [show2FASetup, setShow2FASetup] = useState(false);
  const [twoFAData, setTwoFAData] = useState<any>(null);
  const [verifyCode, setVerifyCode] = useState('');

  const { register: reg1, handleSubmit: hs1 } = useForm({ defaultValues: { firstName: user?.firstName || '', lastName: user?.lastName || '' } });
  const { register: reg2, handleSubmit: hs2 } = useForm<any>();

  const profileMutation = useMutation({
    mutationFn: (data: any) => userApi.updateProfile(data).then((r) => r.data),
    onSuccess: (_, vars) => {
      updateUser(vars);
      toast.success('Profile updated');
    },
    onError: () => toast.error('Failed to update profile'),
  });

  const passwordMutation = useMutation({
    mutationFn: (data: any) => userApi.changePassword(data).then((r) => r.data),
    onSuccess: () => toast.success('Password changed successfully'),
    onError: (err: any) => toast.error(err.response?.data?.message || 'Failed'),
  });

  const setup2FAMutation = useMutation({
    mutationFn: () => authApi.setup2FA().then((r) => r.data),
    onSuccess: (data) => {
      setTwoFAData(data);
      setShow2FASetup(true);
    },
  });

  const enable2FAMutation = useMutation({
    mutationFn: (code: string) => authApi.enable2FA(code).then((r) => r.data),
    onSuccess: () => {
      updateUser({ twoFaEnabled: true });
      toast.success('2FA enabled!');
      setShow2FASetup(false);
    },
    onError: (err: any) => toast.error(err.response?.data?.message || 'Invalid code'),
  });

  const disable2FAMutation = useMutation({
    mutationFn: (code: string) => authApi.disable2FA(code).then((r) => r.data),
    onSuccess: () => {
      updateUser({ twoFaEnabled: false });
      toast.success('2FA disabled');
    },
    onError: (err: any) => toast.error(err.response?.data?.message || 'Invalid code'),
  });

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-fade-in">
      <h1 className="text-2xl font-bold">Settings</h1>

      {/* Profile */}
      <div className="card space-y-4">
        <div className="flex items-center gap-2 mb-1">
          <User className="w-5 h-5 text-brand-400" />
          <h3 className="font-semibold">Profile</h3>
        </div>
        <form onSubmit={hs1((d) => profileMutation.mutate(d))} className="space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm text-dark-400 mb-1.5">First Name</label>
              <input {...reg1('firstName')} className="input-field" />
            </div>
            <div>
              <label className="block text-sm text-dark-400 mb-1.5">Last Name</label>
              <input {...reg1('lastName')} className="input-field" />
            </div>
          </div>
          <div>
            <label className="block text-sm text-dark-400 mb-1.5">{user?.email ? 'Email' : 'Phone'}</label>
            <input value={user?.email || user?.phone || ''} disabled className="input-field opacity-50" />
          </div>
          <button type="submit" disabled={profileMutation.isPending} className="btn-primary flex items-center gap-2">
            {profileMutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
            Save Profile
          </button>
        </form>
      </div>

      {/* Password */}
      <div className="card space-y-4">
        <div className="flex items-center gap-2 mb-1">
          <KeyRound className="w-5 h-5 text-brand-400" />
          <h3 className="font-semibold">Change Password</h3>
        </div>
        <form onSubmit={hs2((d) => passwordMutation.mutate(d))} className="space-y-4">
          <div>
            <label className="block text-sm text-dark-400 mb-1.5">Current Password</label>
            <input {...reg2('currentPassword', { required: true })} type="password" className="input-field" />
          </div>
          <div>
            <label className="block text-sm text-dark-400 mb-1.5">New Password</label>
            <input {...reg2('newPassword', { required: true, minLength: 8 })} type="password" className="input-field" />
          </div>
          <button type="submit" disabled={passwordMutation.isPending} className="btn-primary flex items-center gap-2">
            {passwordMutation.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
            Change Password
          </button>
        </form>
      </div>

      {/* 2FA */}
      <div className="card space-y-4">
        <div className="flex items-center gap-2 mb-1">
          <Shield className="w-5 h-5 text-brand-400" />
          <h3 className="font-semibold">Two-Factor Authentication</h3>
        </div>
        <div className="flex items-center justify-between bg-dark-800 rounded-lg px-4 py-3">
          <div>
            <p className="text-sm font-medium">2FA Status</p>
            <p className="text-xs text-dark-500 mt-0.5">
              {user?.twoFaEnabled ? 'Enabled — your account is extra secure' : 'Disabled — enable for extra security'}
            </p>
          </div>
          <span className={user?.twoFaEnabled ? 'badge-success' : 'badge-error'}>
            {user?.twoFaEnabled ? 'Enabled' : 'Disabled'}
          </span>
        </div>

        {!user?.twoFaEnabled && !show2FASetup && (
          <button onClick={() => setup2FAMutation.mutate()} disabled={setup2FAMutation.isPending} className="btn-outline flex items-center gap-2">
            {setup2FAMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <QrCode className="w-4 h-4" />}
            Setup 2FA
          </button>
        )}

        {show2FASetup && twoFAData && (
          <div className="space-y-4 animate-fade-in">
            <p className="text-sm text-dark-400">Scan this QR code with your authenticator app:</p>
            <div className="flex justify-center">
              <img src={twoFAData.qrCode} alt="QR Code" className="rounded-lg" />
            </div>
            <div>
              <p className="text-xs text-dark-500 mb-1">Or enter manually: <span className="font-mono text-dark-300">{twoFAData.secret}</span></p>
            </div>
            <div>
              <label className="block text-sm text-dark-400 mb-1.5">Enter 6-digit code to verify</label>
              <div className="flex gap-2">
                <input
                  value={verifyCode}
                  onChange={(e) => setVerifyCode(e.target.value)}
                  maxLength={6}
                  className="input-field text-center tracking-widest font-mono text-xl flex-1"
                  placeholder="000000"
                />
                <button
                  onClick={() => enable2FAMutation.mutate(verifyCode)}
                  disabled={enable2FAMutation.isPending || verifyCode.length !== 6}
                  className="btn-primary"
                >
                  {enable2FAMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Verify'}
                </button>
              </div>
            </div>
          </div>
        )}

        {user?.twoFaEnabled && (
          <div className="space-y-3">
            <label className="block text-sm text-dark-400">Disable 2FA (enter code to confirm)</label>
            <div className="flex gap-2">
              <input
                value={verifyCode}
                onChange={(e) => setVerifyCode(e.target.value)}
                maxLength={6}
                className="input-field text-center tracking-widest font-mono text-xl flex-1"
                placeholder="000000"
              />
              <button
                onClick={() => disable2FAMutation.mutate(verifyCode)}
                disabled={disable2FAMutation.isPending || verifyCode.length !== 6}
                className="btn-secondary"
              >
                Disable
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
