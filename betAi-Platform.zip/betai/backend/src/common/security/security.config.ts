import { INestApplication, ValidationPipe } from '@nestjs/common';
import helmet from 'helmet';
import * as compression from 'compression';
import rateLimit from 'express-rate-limit';

/**
 * Centralized security hardening for the betAi platform.
 * Applied in main.ts via applySecurity(app).
 */
export function applySecurity(app: INestApplication): void {
  // ── 1. Helmet — secure HTTP headers ──
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", 'data:', 'https:'],
        connectSrc: ["'self'", 'https://api.api-sports.io', 'wss://stream.binance.com'],
        frameSrc: ["'self'", 'https://www.youtube.com', 'https://player.vimeo.com'],
        objectSrc: ["'none'"],
        upgradeInsecureRequests: [],
      },
    },
    hsts: { maxAge: 31536000, includeSubDomains: true, preload: true },
    referrerPolicy: { policy: 'strict-origin-when-cross-origin' },
  }));

  // ── 2. Compression ──
  app.use(compression());

  // ── 3. Global rate limiting (all routes) ──
  app.use(rateLimit({
    windowMs: 15 * 60 * 1000,   // 15 minutes
    max: 300,                    // 300 requests per window per IP
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: 'Too many requests, please try again later.' },
  }));

  // ── 4. Strict global input validation ──
  app.useGlobalPipes(new ValidationPipe({
    whitelist: true,             // strip unknown properties
    forbidNonWhitelisted: true,  // reject requests with extra props
    transform: true,             // auto-transform payloads to DTO types
    transformOptions: { enableImplicitConversion: true },
    forbidUnknownValues: true,
  }));

  // ── 5. CORS — restrict to known frontend origin ──
  app.enableCors({
    origin: (process.env.FRONTEND_URL || 'https://betai.com').split(','),
    methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE', 'OPTIONS'],
    credentials: true,
    maxAge: 86400,
  });

  // ── 6. Disable x-powered-by ──
  app.getHttpAdapter().getInstance().disable('x-powered-by');
}
