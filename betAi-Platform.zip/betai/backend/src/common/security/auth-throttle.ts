import rateLimit from 'express-rate-limit';

/**
 * Strict rate limiting on authentication endpoints to prevent
 * brute-force password attacks.
 * Apply to: POST /auth/login, POST /auth/register, POST /auth/forgot
 */
export const authThrottle = rateLimit({
  windowMs: 15 * 60 * 1000,    // 15 minutes
  max: 5,                       // only 5 attempts per 15 min per IP
  skipSuccessfulRequests: true, // only count failed attempts
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: 'Too many login attempts. Please wait 15 minutes before trying again.',
  },
});

/**
 * Per-account lockout (in addition to IP throttle).
 * Track failed attempts in Redis; lock account after N failures.
 */
export const ACCOUNT_LOCKOUT = {
  maxFailedAttempts: 5,
  lockoutDurationMs: 30 * 60 * 1000,  // 30 minutes
};
