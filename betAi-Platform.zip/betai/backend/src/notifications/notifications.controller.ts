import { Controller, Get, Patch, Param, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { NotificationsService } from './notifications.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('Notifications')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('notifications')
export class NotificationsController {
  constructor(private readonly notificationsService: NotificationsService) {}

  @Get()
  async list(@Request() req) {
    return this.notificationsService.getNotifications(req.user.id);
  }

  @Get('unread-count')
  async unreadCount(@Request() req) {
    const count = await this.notificationsService.getUnreadCount(req.user.id);
    return { count };
  }

  @Patch(':id/read')
  async markRead(@Request() req, @Param('id') id: string) {
    await this.notificationsService.markAsRead(req.user.id, id);
    return { message: 'Marked as read' };
  }

  @Patch('read-all')
  async markAllRead(@Request() req) {
    await this.notificationsService.markAllAsRead(req.user.id);
    return { message: 'All marked as read' };
  }
}
