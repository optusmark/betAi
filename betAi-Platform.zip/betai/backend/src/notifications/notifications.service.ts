import { Injectable } from '@nestjs/common';
import { DataSource } from 'typeorm';

@Injectable()
export class NotificationsService {
  constructor(private readonly dataSource: DataSource) {}

  async getNotifications(userId: string): Promise<any[]> {
    return this.dataSource.query(
      `SELECT * FROM notifications WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50`,
      [userId]
    );
  }

  async markAsRead(userId: string, notificationId: string): Promise<void> {
    await this.dataSource.query(
      `UPDATE notifications SET is_read = TRUE, read_at = NOW() WHERE id = $1 AND user_id = $2`,
      [notificationId, userId]
    );
  }

  async markAllAsRead(userId: string): Promise<void> {
    await this.dataSource.query(
      `UPDATE notifications SET is_read = TRUE, read_at = NOW() WHERE user_id = $1 AND is_read = FALSE`,
      [userId]
    );
  }

  async getUnreadCount(userId: string): Promise<number> {
    const [{ count }] = await this.dataSource.query(
      `SELECT COUNT(*) FROM notifications WHERE user_id = $1 AND is_read = FALSE`,
      [userId]
    );
    return parseInt(count);
  }
}
