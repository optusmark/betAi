import {
  Injectable, ExecutionContext, UnauthorizedException,
} from '@nestjs/common';
import { AuthGuard } from '@nestjs/passport';

@Injectable()
export class JwtAuthGuard extends AuthGuard('jwt') {
  handleRequest(err: any, user: any) {
    if (err || !user) throw err || new UnauthorizedException('Authentication required');
    if (user.status === 'banned') throw new UnauthorizedException('Account suspended');
    return user;
  }
}

@Injectable()
export class AdminGuard extends AuthGuard('jwt') {
  async canActivate(context: ExecutionContext): Promise<boolean> {
    // First run JWT validation
    const valid = await super.canActivate(context);
    if (!valid) return false;

    const { user } = context.switchToHttp().getRequest();
    if (!user?.isAdmin) throw new UnauthorizedException('Admin access required');
    return true;
  }

  handleRequest(err: any, user: any) {
    if (err || !user) throw err || new UnauthorizedException();
    return user;
  }
}
