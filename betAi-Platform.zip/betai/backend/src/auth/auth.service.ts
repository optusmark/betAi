import {
  Injectable, UnauthorizedException, BadRequestException,
  ConflictException, NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import * as bcrypt from 'bcrypt';
import * as crypto from 'crypto';
import { authenticator } from 'otplib';
import * as qrcode from 'qrcode';
import { User } from '../users/user.entity';
import { RegisterDto } from './dto/register.dto';

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(User)
    private readonly userRepository: Repository<User>,
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
  ) {}

  // ── Referral code generator ─────────────────────────────
  private generateReferralCode(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let code = 'betAi';
    for (let i = 0; i < 7; i++) {
      code += chars[Math.floor(Math.random() * chars.length)];
    }
    return code;
  }

  // ── Register ────────────────────────────────────────────
  async register(dto: RegisterDto): Promise<{ message: string }> {
    if (!dto.email && !dto.phone) {
      throw new BadRequestException('Email or phone required');
    }
    if (dto.email) {
      const exists = await this.userRepository.findOne({ where: { email: dto.email } });
      if (exists) throw new ConflictException('Email already in use');
    }
    if (dto.phone) {
      const exists = await this.userRepository.findOne({ where: { phone: dto.phone } });
      if (exists) throw new ConflictException('Phone already in use');
    }

    // Handle referral — only link is used, no code input from user
    let referrerId: string | null = null;
    if (dto.referralCode) {
      const referrer = await this.userRepository.findOne({
        where: { referralCode: dto.referralCode },
      });
      if (referrer) referrerId = referrer.id;
    }

    // Unique referral code
    let referralCode: string;
    let unique = false;
    let attempts = 0;
    while (!unique && attempts < 10) {
      referralCode = this.generateReferralCode();
      const ex = await this.userRepository.findOne({ where: { referralCode } });
      if (!ex) unique = true;
      attempts++;
    }
    if (!unique) throw new BadRequestException('Could not generate referral code, try again');

    const passwordHash = await bcrypt.hash(dto.password, 12);

    const user = this.userRepository.create({
      email:        dto.email  || null,
      phone:        dto.phone  || null,
      passwordHash,
      referralCode,
      referrerId,
    });

    const savedUser = await this.userRepository.save(user);

    // If registered via referral link → create referral record
    if (referrerId) {
      // Use raw query to avoid TypeORM entity for referrals table
      const dataSource = this.userRepository.manager.connection;
      await dataSource.query(
        `INSERT INTO referrals (referrer_id, referred_id, registered_at)
         VALUES ($1, $2, NOW())
         ON CONFLICT DO NOTHING`,
        [referrerId, savedUser.id]
      );
    }

    return { message: 'Registration successful.' };
  }

  // ── Validate credentials ────────────────────────────────
  async validateUser(identifier: string, password: string): Promise<User | null> {
    const user = await this.userRepository.findOne({
      where: [{ email: identifier }, { phone: identifier }],
    });
    if (!user || user.deletedAt) return null;
    if (user.status === 'banned') return null;
    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) return null;
    return user;
  }

  // ── Login ───────────────────────────────────────────────
  async login(
    user: User, twoFaCode?: string, ip?: string
  ): Promise<{ accessToken: string; refreshToken: string; user: Partial<User> }> {

    if (user.twoFaEnabled) {
      if (!twoFaCode) throw new UnauthorizedException('2FA code required');
      const valid = authenticator.verify({ token: twoFaCode, secret: user.twoFaSecret });
      if (!valid) throw new UnauthorizedException('Invalid 2FA code');
    }

    const payload = { sub: user.id, email: user.email, isAdmin: user.isAdmin };

    const accessToken = this.jwtService.sign(payload, {
      expiresIn: '15m',
      secret: this.configService.get('JWT_SECRET'),
    });

    // Refresh token: store hash in DB for revocation support
    const rawRefreshToken = this.jwtService.sign(payload, {
      expiresIn: '7d',
      secret: this.configService.get('JWT_REFRESH_SECRET'),
    });

    const tokenHash = crypto
      .createHash('sha256')
      .update(rawRefreshToken)
      .digest('hex');

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7);

    await this.userRepository.manager.connection.query(
      `INSERT INTO refresh_tokens (user_id, token_hash, expires_at, ip_address)
       VALUES ($1, $2, $3, $4)`,
      [user.id, tokenHash, expiresAt, ip || null]
    );

    await this.userRepository.update(user.id, { lastLoginAt: new Date(), lastLoginIp: ip });

    const { passwordHash, twoFaSecret, ...safeUser } = user;
    return { accessToken, refreshToken: rawRefreshToken, user: safeUser };
  }

  // ── Logout: revoke refresh token ────────────────────────
  async logout(refreshToken: string): Promise<{ message: string }> {
    const tokenHash = crypto
      .createHash('sha256')
      .update(refreshToken)
      .digest('hex');

    await this.userRepository.manager.connection.query(
      `UPDATE refresh_tokens SET revoked_at = NOW()
       WHERE token_hash = $1 AND revoked_at IS NULL`,
      [tokenHash]
    );
    return { message: 'Logged out' };
  }

  // ── Refresh access token ────────────────────────────────
  async refreshAccessToken(rawToken: string): Promise<{ accessToken: string }> {
    let payload: any;
    try {
      payload = this.jwtService.verify(rawToken, {
        secret: this.configService.get('JWT_REFRESH_SECRET'),
      });
    } catch {
      throw new UnauthorizedException('Invalid or expired refresh token');
    }

    // Check token is not revoked in DB
    const tokenHash = crypto.createHash('sha256').update(rawToken).digest('hex');
    const [row] = await this.userRepository.manager.connection.query(
      `SELECT id, revoked_at, expires_at FROM refresh_tokens
       WHERE token_hash = $1`,
      [tokenHash]
    );

    if (!row) throw new UnauthorizedException('Token not found');
    if (row.revoked_at) throw new UnauthorizedException('Token has been revoked');
    if (new Date(row.expires_at) < new Date()) throw new UnauthorizedException('Token expired');

    // Check user still exists and is active
    const user = await this.userRepository.findOne({ where: { id: payload.sub } });
    if (!user || user.status === 'banned' || user.deletedAt) {
      throw new UnauthorizedException('Account not available');
    }

    const newAccessToken = this.jwtService.sign(
      { sub: user.id, email: user.email, isAdmin: user.isAdmin },
      { expiresIn: '15m', secret: this.configService.get('JWT_SECRET') }
    );

    return { accessToken: newAccessToken };
  }

  // ── 2FA setup ───────────────────────────────────────────
  async setup2FA(userId: string): Promise<{ secret: string; qrCode: string }> {
    const user = await this.userRepository.findOne({ where: { id: userId } });
    if (!user) throw new NotFoundException('User not found');

    const secret = authenticator.generateSecret();
    const identifier = user.email || user.phone;
    const otpauth = authenticator.keyuri(identifier, 'betAi', secret);
    const qrCode = await qrcode.toDataURL(otpauth);

    await this.userRepository.update(userId, { twoFaSecret: secret });
    return { secret, qrCode };
  }

  async enable2FA(userId: string, code: string): Promise<{ message: string }> {
    const user = await this.userRepository.findOne({ where: { id: userId } });
    if (!user?.twoFaSecret) throw new BadRequestException('2FA not initialized');
    const valid = authenticator.verify({ token: code, secret: user.twoFaSecret });
    if (!valid) throw new BadRequestException('Invalid code');
    await this.userRepository.update(userId, { twoFaEnabled: true });
    return { message: '2FA enabled' };
  }

  async disable2FA(userId: string, code: string): Promise<{ message: string }> {
    const user = await this.userRepository.findOne({ where: { id: userId } });
    if (!user) throw new NotFoundException('User not found');
    const valid = authenticator.verify({ token: code, secret: user.twoFaSecret });
    if (!valid) throw new BadRequestException('Invalid code');
    await this.userRepository.update(userId, { twoFaEnabled: false, twoFaSecret: null });
    return { message: '2FA disabled' };
  }
}
