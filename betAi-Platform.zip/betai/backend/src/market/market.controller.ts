import { Controller, Get, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { MarketService } from './market.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('Market')
@ApiBearerAuth()
@Controller('market')
export class MarketController {
  constructor(private readonly svc: MarketService) {}

  // Ticker data for the scrolling bar — authenticated users only
  @Get('tickers')
  @UseGuards(JwtAuthGuard)
  getTickers() {
    return {
      tickers:   this.svc.getTickers(),
      connected: this.svc.isConnected(),
      updatedAt: Date.now(),
    };
  }

  // Connection status (public — for health check)
  @Get('status')
  getStatus() {
    return this.svc.getStatus();
  }
}
