import { Injectable, Logger, OnModuleInit, OnModuleDestroy } from '@nestjs/common';
import WebSocket from 'ws';

const SYMBOLS = [
  'btcusdt','ethusdt','bnbusdt','solusdt','xrpusdt',
  'adausdt','dogeusdt','avaxusdt','maticusdt','dotusdt',
];

export interface TickerData {
  symbol:        string;
  displaySymbol: string;
  price:         number;
  change24h:     number;
  high24h:       number;
  low24h:        number;
  volume24h:     number;
  updatedAt:     number;
}

@Injectable()
export class MarketService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(MarketService.name);
  private ws: WebSocket | null = null;
  private prices: Map<string, TickerData> = new Map();
  private reconnectTimer: NodeJS.Timeout | null = null;
  private isDestroying = false;

  onModuleInit()  { this.connect(); }
  onModuleDestroy() {
    this.isDestroying = true;
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.ws?.terminate();
  }

  private connect(): void {
    const streams = SYMBOLS.map(s => `${s}@ticker`).join('/');
    const url = `wss://stream.binance.com:9443/stream?streams=${streams}`;

    this.logger.log(`Connecting Binance WS: ${SYMBOLS.length} symbols`);
    this.ws = new WebSocket(url);

    this.ws.on('open',  () => this.logger.log('Binance WS connected ✓'));
    this.ws.on('error', (err) => this.logger.error('Binance WS error:', err.message));
    this.ws.on('close', () => {
      this.logger.warn('Binance WS closed — reconnect in 5s');
      if (!this.isDestroying)
        this.reconnectTimer = setTimeout(() => this.connect(), 5000);
    });
    this.ws.on('message', (raw: Buffer) => {
      try {
        const { data } = JSON.parse(raw.toString());
        if (!data?.s) return;
        this.prices.set(data.s.toLowerCase(), {
          symbol:        data.s,
          displaySymbol: data.s.replace('USDT',''),
          price:         parseFloat(data.c),
          change24h:     parseFloat(data.P),
          high24h:       parseFloat(data.h),
          low24h:        parseFloat(data.l),
          volume24h:     parseFloat(data.v),
          updatedAt:     Date.now(),
        });
      } catch {}
    });
  }

  getTickers(): TickerData[] {
    return SYMBOLS
      .map(s => this.prices.get(s))
      .filter(Boolean) as TickerData[];
  }

  getPrice(symbol: string): TickerData | null {
    return this.prices.get(symbol.toLowerCase() + 'usdt') ?? null;
  }

  isConnected(): boolean {
    return this.ws?.readyState === WebSocket.OPEN;
  }

  getStatus() {
    return {
      connected:    this.isConnected(),
      symbolsCount: this.prices.size,
      symbols:      SYMBOLS,
    };
  }
}
