import { Module } from '@nestjs/common';
import { MarketService } from './market.service';
import { MarketController } from './market.controller';
import { MarketGateway } from './market.gateway';

@Module({
  providers:   [MarketService, MarketGateway],
  controllers: [MarketController],
  exports:     [MarketService],
})
export class MarketModule {}
