import {
  WebSocketGateway, WebSocketServer,
  SubscribeMessage, OnGatewayConnection, OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { UseGuards, Logger } from '@nestjs/common';
import { MarketService } from './market.service';
import { Interval } from '@nestjs/schedule';

// Push real-time prices to frontend via Socket.io
// Frontend connects once — receives updates every 2 seconds
@WebSocketGateway({
  cors: { origin: process.env.FRONTEND_URL || 'http://localhost:3000' },
  namespace: '/market',
})
export class MarketGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() server: Server;
  private readonly logger = new Logger(MarketGateway.name);
  private clients = new Set<string>();

  constructor(private readonly marketSvc: MarketService) {}

  handleConnection(client: Socket) {
    this.clients.add(client.id);
    this.logger.log(`Market client connected: ${client.id} (${this.clients.size} total)`);
    // Send current prices immediately on connect
    client.emit('tickers', this.marketSvc.getTickers());
  }

  handleDisconnect(client: Socket) {
    this.clients.delete(client.id);
  }

  // Broadcast to all connected clients every 2 seconds
  @Interval(2000)
  broadcastTickers() {
    if (this.clients.size === 0) return;
    const tickers = this.marketSvc.getTickers();
    if (tickers.length > 0) {
      this.server.emit('tickers', tickers);
    }
  }
}
