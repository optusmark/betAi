import { Injectable, Logger } from '@nestjs/common';
import { DataSource } from 'typeorm';
import axios from 'axios';

const API_BASE = 'https://v3.football.api-sports.io';
const API_KEY  = '568c7020aa780ff0a3df3b3614078d0f';

// Priority league IDs
const PRIORITY_LEAGUES = [
  { id: 1,   name: 'World Cup',         priority: 1 },
  { id: 2,   name: 'UEFA Champions League', priority: 2 },
  { id: 39,  name: 'Premier League',    priority: 3 },
  { id: 140, name: 'La Liga',           priority: 4 },
  { id: 135, name: 'Serie A',           priority: 5 },
  { id: 78,  name: 'Bundesliga',        priority: 6 },
  { id: 61,  name: 'Ligue 1',           priority: 7 },
  { id: 3,   name: 'UEFA Europa League',priority: 8 },
];

@Injectable()
export class SportsService {
  private readonly logger = new Logger(SportsService.name);
  private memCache: Map<string, { data: any; expires: number }> = new Map();

  constructor(private readonly dataSource: DataSource) {}

  private async fetchAPI(endpoint: string, params: Record<string, string> = {}): Promise<any> {
    try {
      const res = await axios.get(`${API_BASE}${endpoint}`, {
        headers: { 'x-apisports-key': API_KEY },
        params,
        timeout: 8000,
      });
      return res.data;
    } catch (err) {
      this.logger.error(`API error ${endpoint}:`, err.message);
      return null;
    }
  }

  private getCacheKey(key: string): any | null {
    const entry = this.memCache.get(key);
    if (entry && entry.expires > Date.now()) return entry.data;
    return null;
  }

  private setCache(key: string, data: any, ttlSeconds: number): void {
    this.memCache.set(key, { data, expires: Date.now() + ttlSeconds * 1000 });
    // Also persist to DB cache
    this.dataSource.query(
      `INSERT INTO sports_cache(cache_key,data,expires_at)
       VALUES($1,$2,NOW()+INTERVAL '$3 seconds')
       ON CONFLICT(cache_key) DO UPDATE SET data=$2,expires_at=NOW()+INTERVAL '$3 seconds',created_at=NOW()`,
      [key, JSON.stringify(data), ttlSeconds]
    ).catch(() => {});
  }

  // ── Get top events for today ───────────────────────────────
  async getTopEvents(maxEvents = 5): Promise<any[]> {
    const cacheKey = `top_events_${new Date().toISOString().split('T')[0]}`;
    const cached = this.getCacheKey(cacheKey);
    if (cached) return cached;

    const today = new Date().toISOString().split('T')[0];

    // Try live first
    const liveData = await this.fetchAPI('/fixtures', { live: 'all' });
    let fixtures = liveData?.response || [];

    // If no live, get today's fixtures
    if (fixtures.length === 0) {
      const todayData = await this.fetchAPI('/fixtures', { date: today });
      fixtures = todayData?.response || [];
    }

    // Score and sort by priority
    const scored = fixtures
      .map((f: any) => {
        const leagueId = f.league?.id;
        const priority = PRIORITY_LEAGUES.find(l => l.id === leagueId);
        return { ...f, _priority: priority?.priority || 99 };
      })
      .sort((a: any, b: any) => a._priority - b._priority)
      .slice(0, maxEvents);

    const ttl = fixtures.some((f: any) => f.fixture?.status?.short === '1H' || f.fixture?.status?.short === '2H') ? 30 : 300;
    this.setCache(cacheKey, scored, ttl);
    return scored;
  }

  // ── Get live events ────────────────────────────────────────
  async getLiveEvents(): Promise<any[]> {
    const cacheKey = 'live_events';
    const cached = this.getCacheKey(cacheKey);
    if (cached) return cached;

    const data = await this.fetchAPI('/fixtures', { live: 'all' });
    const fixtures = data?.response || [];
    this.setCache(cacheKey, fixtures, 30);
    return fixtures;
  }

  // ── Get match detail with stats and events ─────────────────
  async getMatchDetail(fixtureId: string): Promise<any> {
    const cacheKey = `match_${fixtureId}`;
    const cached = this.getCacheKey(cacheKey);
    if (cached) return cached;

    const [fixtureData, statsData, eventsData, lineupsData] = await Promise.all([
      this.fetchAPI('/fixtures', { id: fixtureId }),
      this.fetchAPI('/fixtures/statistics', { fixture: fixtureId }),
      this.fetchAPI('/fixtures/events', { fixture: fixtureId }),
      this.fetchAPI('/fixtures/lineups', { fixture: fixtureId }),
    ]);

    const result = {
      fixture: fixtureData?.response?.[0] || null,
      statistics: statsData?.response || [],
      events: eventsData?.response || [],
      lineups: lineupsData?.response || [],
    };

    // Cache live matches for 30s, finished for 1hr
    const status = result.fixture?.fixture?.status?.short;
    const isLive = ['1H','2H','ET','P'].includes(status);
    this.setCache(cacheKey, result, isLive ? 30 : 3600);

    return result;
  }

  // ── Admin: get/update sports config ───────────────────────
  async getConfig(): Promise<any> {
    const [cfg] = await this.dataSource.query(`SELECT * FROM sports_config LIMIT 1`);
    return cfg;
  }

  async updateConfig(adminId: string, data: {
    isEnabled?: boolean; maxEvents?: number; sports?: string[]; pinnedEvents?: string[];
  }): Promise<any> {
    const [cfg] = await this.dataSource.query(
      `UPDATE sports_config SET
         is_enabled   = COALESCE($1, is_enabled),
         max_events   = COALESCE($2, max_events),
         sports       = COALESCE($3, sports),
         pinned_events= COALESCE($4, pinned_events),
         updated_at   = NOW()
       RETURNING *`,
      [data.isEnabled ?? null, data.maxEvents ?? null,
       data.sports ? JSON.stringify(data.sports) : null,
       data.pinnedEvents ? JSON.stringify(data.pinnedEvents) : null]
    );
    return cfg;
  }

  // ── Clean expired cache ────────────────────────────────────
  async cleanCache(): Promise<void> {
    await this.dataSource.query(`DELETE FROM sports_cache WHERE expires_at < NOW()`);
    for (const [key, val] of this.memCache.entries()) {
      if (val.expires < Date.now()) this.memCache.delete(key);
    }
  }
}
