import { Controller, Get, Patch, Param, Body, Query, Request, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { SportsService } from './sports.service';
import { JwtAuthGuard, AdminGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('Sports')
@ApiBearerAuth()
@Controller('sports')
export class SportsController {
  constructor(private readonly svc: SportsService) {}

  @Get('events') @UseGuards(JwtAuthGuard)
  getTopEvents(@Query('max') max?: number) {
    return this.svc.getTopEvents(max ? parseInt(String(max)) : 5);
  }

  @Get('live') @UseGuards(JwtAuthGuard)
  getLive() { return this.svc.getLiveEvents(); }

  @Get('match/:id') @UseGuards(JwtAuthGuard)
  getMatchDetail(@Param('id') id: string) {
    return this.svc.getMatchDetail(id);
  }

  @Get('config') @UseGuards(AdminGuard)
  getConfig() { return this.svc.getConfig(); }

  @Patch('config') @UseGuards(AdminGuard)
  updateConfig(@Request() req, @Body() body: {
    isEnabled?: boolean; maxEvents?: number; sports?: string[]; pinnedEvents?: string[];
  }) { return this.svc.updateConfig(req.user.id, body); }
}
