import { Injectable } from '@nestjs/common';
import { DataSource } from 'typeorm';

@Injectable()
export class ReferralsService {
  constructor(private readonly dataSource: DataSource) {}

  async getReferralInfo(userId: string): Promise<any> {
    const [user] = await this.dataSource.query(
      `SELECT referral_code, referral_condition_met, active_referrals_count
       FROM users WHERE id = $1`,
      [userId]
    );

    // All referrals for this user
    const referrals = await this.dataSource.query(
      `SELECT
         r.id, r.is_qualified, r.registered_at,
         r.first_deposit_at, r.first_deposit_amount,
         u.email AS referred_email, u.phone AS referred_phone,
         u.created_at AS user_created_at
       FROM referrals r
       JOIN users u ON r.referred_id = u.id
       WHERE r.referrer_id = $1
       ORDER BY r.registered_at DESC`,
      [userId]
    );

    const [stats] = await this.dataSource.query(
      `SELECT
         COUNT(*)                                    AS total_referrals,
         COUNT(*) FILTER (WHERE is_qualified = TRUE) AS active_referrals,
         COALESCE(
           SUM(first_deposit_amount) FILTER (WHERE is_qualified = TRUE),
           0
         )                                           AS total_referred_deposits
       FROM referrals WHERE referrer_id = $1`,
      [userId]
    );

    // Active bonus period
    const [bonusPeriod] = await this.dataSource.query(
      `SELECT *,
         GREATEST(0, EXTRACT(DAYS FROM (end_date - NOW()))) AS days_remaining
       FROM bonus_periods
       WHERE user_id = $1 AND status = 'active'
       ORDER BY period_number DESC LIMIT 1`,
      [userId]
    );

    const appUrl = process.env.FRONTEND_URL || 'http://localhost:3000';

    return {
      referralLink: `${appUrl}/register?ref=${user?.referral_code}`,
      // Note: referral CODE is NOT shown to user per product spec
      // Only the full link is provided
      referrals,
      stats: {
        total:    parseInt(stats.total_referrals),
        active:   parseInt(stats.active_referrals),
        needed:   Math.max(0, 5 - parseInt(stats.active_referrals)),
        totalReferredDeposits: parseFloat(stats.total_referred_deposits),
      },
      conditionMet: user?.referral_condition_met || parseInt(stats.active_referrals) >= 5,
      currentPeriod: bonusPeriod || null,
    };
  }
}
