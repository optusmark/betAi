import {
  Controller, Get, Post, Patch, Body,
  Param, ParseUUIDPipe, Request, UseGuards, HttpCode, HttpStatus,
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { WalletAdminService } from './wallet-admin.service';
import { AdminGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('Admin — Wallets')
@ApiBearerAuth()
@UseGuards(AdminGuard)
@Controller('admin/wallets')
export class WalletAdminController {
  constructor(private readonly walletAdminService: WalletAdminService) {}

  // List all platform wallets (with pending deposit count per wallet)
  @Get()
  async getAll() {
    return this.walletAdminService.getAll();
  }

  // All crypto assets — shows which have a wallet configured
  @Get('assets')
  async getAvailableAssets() {
    return this.walletAdminService.getAvailableAssets();
  }

  // Single wallet detail
  @Get(':id')
  async getOne(@Param('id', ParseUUIDPipe) id: string) {
    return this.walletAdminService.getOne(id);
  }

  // Wallet address change history
  @Get(':id/history')
  async getHistory(@Param('id', ParseUUIDPipe) id: string) {
    return this.walletAdminService.getWalletHistory(id);
  }

  // Create new wallet for an asset
  @Post()
  @HttpCode(HttpStatus.CREATED)
  async create(
    @Request() req,
    @Body() body: { assetId: string; address: string; label?: string },
  ) {
    return this.walletAdminService.create(req.user.id, body);
  }

  // Update wallet address / label / active status
  @Patch(':id')
  async update(
    @Param('id', ParseUUIDPipe) id: string,
    @Request() req,
    @Body() body: { address?: string; label?: string; isActive?: boolean },
  ) {
    return this.walletAdminService.update(req.user.id, id, body);
  }

  // Toggle active/inactive
  @Patch(':id/toggle')
  @HttpCode(HttpStatus.OK)
  async toggle(
    @Param('id', ParseUUIDPipe) id: string,
    @Request() req,
  ) {
    return this.walletAdminService.toggle(req.user.id, id);
  }
}
