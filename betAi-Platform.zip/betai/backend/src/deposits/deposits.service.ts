import {
  Injectable, BadRequestException, ForbiddenException,
  NotFoundException, Logger,
} from '@nestjs/common';
import { DataSource } from 'typeorm';
import { BonusesService } from '../bonuses/bonuses.service';
import * as path from 'path';
import * as fs from 'fs';

const ALLOWED_MIME_TYPES = [
  'image/jpeg', 'image/jpg', 'image/png', 'application/pdf',
];
const MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024; // 10 MB

@Injectable()
export class DepositsService {
  private readonly logger = new Logger(DepositsService.name);

  constructor(
    private readonly dataSource: DataSource,
    private readonly bonusesService: BonusesService,
  ) {}

  // ─────────────────────────────────────────────────────────
  // Get platform wallet address for an asset
  // ─────────────────────────────────────────────────────────
  async getDepositInfo(assetId: string): Promise<any> {
    const [wallet] = await this.dataSource.query(
      `SELECT pw.address, pw.network, pw.label,
              ca.symbol, ca.name, ca.min_deposit, ca.decimals
       FROM platform_wallets pw
       JOIN crypto_assets ca ON pw.asset_id = ca.id
       WHERE pw.asset_id = $1 AND pw.is_active = TRUE`,
      [assetId]
    );
    if (!wallet) throw new NotFoundException('Wallet not found for this asset');

    return {
      address:    wallet.address,
      network:    wallet.network,
      label:      wallet.label,
      symbol:     wallet.symbol,
      minDeposit: parseFloat(wallet.min_deposit),
      warning:    `Only send ${wallet.symbol} on ${wallet.network} network. After sending, submit a deposit confirmation request and upload your payment proof.`,
    };
  }

  async getAllDepositWallets(): Promise<any[]> {
    return this.dataSource.query(
      `SELECT pw.*, ca.symbol, ca.name, ca.min_deposit
       FROM platform_wallets pw
       JOIN crypto_assets ca ON pw.asset_id = ca.id
       WHERE pw.is_active = TRUE
       ORDER BY ca.symbol, pw.network`
    );
  }

  // ─────────────────────────────────────────────────────────
  // USER: Submit deposit confirmation request
  // ─────────────────────────────────────────────────────────
  async submitDepositRequest(
    userId: string,
    data: {
      assetId:  string;
      amount:   number;
    },
    file: Express.Multer.File,
  ): Promise<any> {

    // ── Validate file ────────────────────────────────────────
    if (!file) {
      throw new BadRequestException('Payment proof is required (JPG, JPEG, PNG, PDF)');
    }
    if (!ALLOWED_MIME_TYPES.includes(file.mimetype)) {
      // Delete uploaded file if wrong type
      this.deleteFile(file.path);
      throw new BadRequestException('Only JPG, JPEG, PNG and PDF files are allowed');
    }
    if (file.size > MAX_FILE_SIZE_BYTES) {
      this.deleteFile(file.path);
      throw new BadRequestException('File size must not exceed 10 MB');
    }

    // ── Validate amount ─────────────────────────────────────
    if (!data.amount || data.amount <= 0) {
      this.deleteFile(file.path);
      throw new BadRequestException('Deposit amount must be greater than 0');
    }

    // ── Get asset & check min deposit ──────────────────────
    const [asset] = await this.dataSource.query(
      `SELECT ca.*, pw.address, pw.network as wallet_network
       FROM crypto_assets ca
       JOIN platform_wallets pw ON pw.asset_id = ca.id
       WHERE ca.id = $1 AND ca.is_active = TRUE AND pw.is_active = TRUE`,
      [data.assetId]
    );
    if (!asset) {
      this.deleteFile(file.path);
      throw new BadRequestException('Asset not available for deposit');
    }
    if (data.amount < parseFloat(asset.min_deposit)) {
      this.deleteFile(file.path);
      throw new BadRequestException(
        `Minimum deposit is ${asset.min_deposit} ${asset.symbol}`
      );
    }

    // ── Check user exists ────────────────────────────────────
    const [user] = await this.dataSource.query(
      `SELECT id FROM users WHERE id = $1 AND deleted_at IS NULL AND status != 'banned'`,
      [userId]
    );
    if (!user) {
      this.deleteFile(file.path);
      throw new ForbiddenException('User not found');
    }

    // ── Build proof URL ──────────────────────────────────────
    const proofUrl = `/uploads/deposits/${file.filename}`;

    // ── Insert deposit request ───────────────────────────────
    const [request] = await this.dataSource.query(
      `INSERT INTO deposit_requests
         (user_id, asset_id, network, amount,
          proof_filename, proof_original, proof_mimetype, proof_size, proof_url,
          status, submitted_at)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'pending_review', NOW())
       RETURNING *`,
      [
        userId,
        data.assetId,
        asset.wallet_network,
        data.amount,
        file.filename,
        file.originalname,
        file.mimetype,
        file.size,
        proofUrl,
      ]
    );

    // Notify admins
    await this.notifyAdmins(userId, request.id, data.amount, asset.symbol);

    this.logger.log(`Deposit request ${request.request_number} submitted by user ${userId}`);

    return {
      requestNumber: request.request_number,
      status:        'pending_review',
      amount:        data.amount,
      symbol:        asset.symbol,
      network:       asset.wallet_network,
      submittedAt:   request.submitted_at,
      message:       'Your deposit request has been submitted and is pending review. Typically processed within 24 hours.',
    };
  }

  // ─────────────────────────────────────────────────────────
  // USER: Get my deposit requests (history)
  // ─────────────────────────────────────────────────────────
  async getUserDepositHistory(userId: string): Promise<any[]> {
    return this.dataSource.query(
      `SELECT dr.id, dr.request_number, dr.amount, dr.network,
              dr.status, dr.submitted_at, dr.reviewed_at,
              dr.rejection_reason, dr.proof_url,
              ca.symbol, ca.name
       FROM deposit_requests dr
       JOIN crypto_assets ca ON dr.asset_id = ca.id
       WHERE dr.user_id = $1
       ORDER BY dr.submitted_at DESC`,
      [userId]
    );
  }

  // ─────────────────────────────────────────────────────────
  // ADMIN: Get all deposit requests with filters
  // ─────────────────────────────────────────────────────────
  async adminGetRequests(filters: {
    status?:   string;
    userId?:   string;
    search?:   string;  // username / email
    dateFrom?: string;
    dateTo?:   string;
    sortBy?:   'newest' | 'oldest' | 'highest' | 'lowest';
    page?:     number;
    limit?:    number;
  }): Promise<any> {
    const {
      status, userId, search,
      dateFrom, dateTo,
      sortBy = 'newest',
      page = 1,
      limit = 20,
    } = filters;

    const conditions: string[] = [];
    const params: any[] = [];
    let p = 1;

    if (status) {
      conditions.push(`dr.status = $${p++}`);
      params.push(status);
    }
    if (userId) {
      conditions.push(`dr.user_id = $${p++}`);
      params.push(userId);
    }
    if (search) {
      conditions.push(`(u.email ILIKE $${p} OR u.phone ILIKE $${p})`);
      params.push(`%${search}%`);
      p++;
    }
    if (dateFrom) {
      conditions.push(`dr.submitted_at >= $${p++}`);
      params.push(dateFrom);
    }
    if (dateTo) {
      conditions.push(`dr.submitted_at <= $${p++}`);
      params.push(dateTo);
    }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const orderMap: Record<string, string> = {
      newest:  'dr.submitted_at DESC',
      oldest:  'dr.submitted_at ASC',
      highest: 'dr.amount DESC',
      lowest:  'dr.amount ASC',
    };
    const orderBy = orderMap[sortBy] || orderMap.newest;
    const offset = (page - 1) * limit;

    const data = await this.dataSource.query(
      `SELECT
         dr.id, dr.request_number, dr.amount, dr.network, dr.status,
         dr.submitted_at, dr.reviewed_at, dr.rejection_reason,
         dr.proof_filename, dr.proof_url, dr.proof_original, dr.proof_mimetype,
         dr.proof_size,
         u.id AS user_id, u.email, u.phone,
         u.created_at AS user_registered_at,
         ca.symbol, ca.name,
         rev.email AS reviewed_by_email
       FROM deposit_requests dr
       JOIN users u ON dr.user_id = u.id
       JOIN crypto_assets ca ON dr.asset_id = ca.id
       LEFT JOIN users rev ON dr.reviewed_by = rev.id
       ${where}
       ORDER BY ${orderBy}
       LIMIT $${p} OFFSET $${p + 1}`,
      [...params, limit, offset]
    );

    const [{ count }] = await this.dataSource.query(
      `SELECT COUNT(*) FROM deposit_requests dr
       JOIN users u ON dr.user_id = u.id
       ${where}`,
      params
    );

    return { data, total: parseInt(count), page, limit };
  }

  // ─────────────────────────────────────────────────────────
  // ADMIN: Get single request detail (with full user info)
  // ─────────────────────────────────────────────────────────
  async adminGetRequestDetail(requestId: string): Promise<any> {
    const [req] = await this.dataSource.query(
      `SELECT
         dr.*,
         u.id AS user_id, u.email, u.phone,
         u.first_name, u.last_name, u.created_at AS user_registered_at,
         u.active_referrals_count, u.referral_condition_met,
         b.deposit_base, b.bonus_balance, b.available_balance,
         b.total_deposited, b.total_withdrawn,
         ca.symbol, ca.name, ca.network AS asset_network,
         rev.email AS reviewed_by_email
       FROM deposit_requests dr
       JOIN users u ON dr.user_id = u.id
       LEFT JOIN balances b ON b.user_id = u.id
       JOIN crypto_assets ca ON dr.asset_id = ca.id
       LEFT JOIN users rev ON dr.reviewed_by = rev.id
       WHERE dr.id = $1`,
      [requestId]
    );
    if (!req) throw new NotFoundException('Deposit request not found');
    return req;
  }

  // ─────────────────────────────────────────────────────────
  // ADMIN: Approve deposit request
  // ─────────────────────────────────────────────────────────
  async adminApproveRequest(
    adminId: string,
    requestId: string,
    ipAddress?: string,
  ): Promise<any> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // Lock the request row
      const [req] = await queryRunner.query(
        `SELECT dr.*, u.email, ca.symbol
         FROM deposit_requests dr
         JOIN users u ON dr.user_id = u.id
         JOIN crypto_assets ca ON dr.asset_id = ca.id
         WHERE dr.id = $1 FOR UPDATE`,
        [requestId]
      );
      if (!req) throw new NotFoundException('Request not found');
      if (req.status !== 'pending_review') {
        throw new BadRequestException(`Request is already ${req.status}`);
      }

      const amount = parseFloat(req.amount);

      // 1. Update request status
      await queryRunner.query(
        `UPDATE deposit_requests
         SET status = 'approved', reviewed_by = $1, reviewed_at = NOW(),
             approved_at = NOW(), updated_at = NOW()
         WHERE id = $2`,
        [adminId, requestId]
      );

      // 2. Credit user balance (deposit_base + available_balance)
      await queryRunner.query(
        `INSERT INTO balances (user_id, asset_id, deposit_base, available_balance, total_deposited)
         VALUES ($1, $2, $3, $3, $3)
         ON CONFLICT (user_id, asset_id) DO UPDATE
           SET deposit_base      = balances.deposit_base      + $3,
               available_balance = balances.available_balance + $3,
               total_deposited   = balances.total_deposited   + $3,
               updated_at        = NOW()`,
        [req.user_id, req.asset_id, amount]
      );

      // 3. Get updated deposit_base for bonus calculation
      const [{ deposit_base: newBase }] = await queryRunner.query(
        `SELECT deposit_base FROM balances WHERE user_id = $1 AND asset_id = $2`,
        [req.user_id, req.asset_id]
      );

      // 4. Record in transactions ledger
      await queryRunner.query(
        `INSERT INTO transactions (user_id, asset_id, type, amount, reference_id, description)
         VALUES ($1, $2, 'deposit', $3, $4, $5)`,
        [req.user_id, req.asset_id, amount, requestId,
         `Deposit approved: ${req.request_number}`]
      );

      // 5. Mark first deposit flag on user
      const [{ cnt }] = await queryRunner.query(
        `SELECT COUNT(*) AS cnt FROM deposit_requests
         WHERE user_id = $1 AND status = 'approved' AND id != $2`,
        [req.user_id, requestId]
      );
      const isFirstDeposit = parseInt(cnt) === 0;

      if (isFirstDeposit) {
        await queryRunner.query(
          `UPDATE users SET updated_at = NOW() WHERE id = $1`, [req.user_id]
        );
      }

      // 6. Audit log
      const [admin] = await queryRunner.query(
        `SELECT email FROM users WHERE id = $1`, [adminId]
      );
      await queryRunner.query(
        `INSERT INTO audit_log (admin_id, admin_email, action, target_type, target_id, user_id, details, ip_address)
         VALUES ($1, $2, 'approve_deposit', 'deposit_request', $3, $4, $5, $6)`,
        [adminId, admin?.email, requestId, req.user_id,
         JSON.stringify({ amount, symbol: req.symbol, requestNumber: req.request_number }),
         ipAddress || null]
      );

      // 7. Notify user
      await queryRunner.query(
        `INSERT INTO notifications (user_id, type, title, message)
         VALUES ($1, 'success', 'Deposit Approved', $2)`,
        [req.user_id,
         `Your deposit of ${amount} ${req.symbol} has been approved and credited to your account.`]
      );

      await queryRunner.commitTransaction();

      // 8. Start/update bonus cycle (outside transaction)
      if (isFirstDeposit) {
        await this.bonusesService.startBonusPeriod(req.user_id, parseFloat(newBase));
      } else {
        await this.bonusesService.updateDepositBase(req.user_id, parseFloat(newBase));
      }

      this.logger.log(`Admin ${adminId} approved deposit ${req.request_number} for user ${req.user_id}`);

      return {
        message:       'Deposit approved successfully',
        requestNumber: req.request_number,
        amount,
        symbol:        req.symbol,
        newDepositBase: parseFloat(newBase),
      };
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  }

  // ─────────────────────────────────────────────────────────
  // ADMIN: Reject deposit request
  // ─────────────────────────────────────────────────────────
  async adminRejectRequest(
    adminId: string,
    requestId: string,
    reason?: string,
    ipAddress?: string,
  ): Promise<any> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const [req] = await queryRunner.query(
        `SELECT dr.*, u.email, ca.symbol
         FROM deposit_requests dr
         JOIN users u ON dr.user_id = u.id
         JOIN crypto_assets ca ON dr.asset_id = ca.id
         WHERE dr.id = $1 FOR UPDATE`,
        [requestId]
      );
      if (!req) throw new NotFoundException('Request not found');
      if (req.status !== 'pending_review') {
        throw new BadRequestException(`Request is already ${req.status}`);
      }

      await queryRunner.query(
        `UPDATE deposit_requests
         SET status = 'rejected', reviewed_by = $1, reviewed_at = NOW(),
             rejection_reason = $2, updated_at = NOW()
         WHERE id = $3`,
        [adminId, reason || null, requestId]
      );

      const [admin] = await queryRunner.query(
        `SELECT email FROM users WHERE id = $1`, [adminId]
      );
      await queryRunner.query(
        `INSERT INTO audit_log (admin_id, admin_email, action, target_type, target_id, user_id, details, ip_address)
         VALUES ($1, $2, 'reject_deposit', 'deposit_request', $3, $4, $5, $6)`,
        [adminId, admin?.email, requestId, req.user_id,
         JSON.stringify({ reason, requestNumber: req.request_number, amount: req.amount }),
         ipAddress || null]
      );

      await queryRunner.query(
        `INSERT INTO notifications (user_id, type, title, message)
         VALUES ($1, 'error', 'Deposit Rejected', $2)`,
        [req.user_id,
         `Your deposit request ${req.request_number} was rejected.${reason ? ' Reason: ' + reason : ''} Please contact support if you have questions.`]
      );

      await queryRunner.commitTransaction();

      this.logger.log(`Admin ${adminId} rejected deposit ${req.request_number}`);
      return { message: 'Deposit request rejected', requestNumber: req.request_number };
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  }

  // ─────────────────────────────────────────────────────────
  // ADMIN: Dashboard stats
  // ─────────────────────────────────────────────────────────
  async adminGetStats(): Promise<any> {
    const today = new Date().toISOString().split('T')[0];
    const [[pending], [approvedToday], [rejectedToday], [totalApproved]] =
      await Promise.all([
        this.dataSource.query(
          `SELECT COUNT(*) AS count FROM deposit_requests WHERE status='pending_review'`
        ),
        this.dataSource.query(
          `SELECT COUNT(*) AS count, COALESCE(SUM(amount),0) AS volume
           FROM deposit_requests
           WHERE status='approved' AND DATE(reviewed_at)=$1`, [today]
        ),
        this.dataSource.query(
          `SELECT COUNT(*) AS count FROM deposit_requests
           WHERE status='rejected' AND DATE(reviewed_at)=$1`, [today]
        ),
        this.dataSource.query(
          `SELECT COUNT(*) AS count, COALESCE(SUM(amount),0) AS volume
           FROM deposit_requests WHERE status='approved'`
        ),
      ]);

    return {
      pendingCount:       parseInt(pending.count),
      approvedTodayCount: parseInt(approvedToday.count),
      approvedTodayVolume:parseFloat(approvedToday.volume),
      rejectedTodayCount: parseInt(rejectedToday.count),
      totalApprovedCount: parseInt(totalApproved.count),
      totalApprovedVolume:parseFloat(totalApproved.volume),
    };
  }

  // ─────────────────────────────────────────────────────────
  // ADMIN: Get audit log
  // ─────────────────────────────────────────────────────────
  async getAuditLog(page = 1, limit = 50): Promise<any> {
    const offset = (page - 1) * limit;
    const data = await this.dataSource.query(
      `SELECT al.*, u.email AS affected_user_email
       FROM audit_log al
       LEFT JOIN users u ON al.user_id = u.id
       WHERE al.target_type IN ('deposit_request')
       ORDER BY al.created_at DESC
       LIMIT $1 OFFSET $2`,
      [limit, offset]
    );
    const [{ count }] = await this.dataSource.query(
      `SELECT COUNT(*) FROM audit_log WHERE target_type IN ('deposit_request')`
    );
    return { data, total: parseInt(count) };
  }

  // ─────────────────────────────────────────────────────────
  // ADMIN: Update platform wallet address
  // ─────────────────────────────────────────────────────────
  async updateWallet(adminId: string, assetId: string, address: string): Promise<any> {
    await this.dataSource.query(
      `UPDATE platform_wallets SET address = $1, updated_at = NOW() WHERE asset_id = $2`,
      [address, assetId]
    );
    const [admin] = await this.dataSource.query(
      `SELECT email FROM users WHERE id = $1`, [adminId]
    );
    await this.dataSource.query(
      `INSERT INTO audit_log (admin_id, admin_email, action, target_type, target_id, details)
       VALUES ($1, $2, 'update_wallet_address', 'platform_wallet', $3, $4)`,
      [adminId, admin?.email, assetId, JSON.stringify({ address })]
    );
    return { message: 'Wallet address updated' };
  }

  // ─────────────────────────────────────────────────────────
  // Helpers
  // ─────────────────────────────────────────────────────────
  private deleteFile(filePath: string): void {
    try { if (fs.existsSync(filePath)) fs.unlinkSync(filePath); } catch {}
  }

  private async notifyAdmins(userId: string, requestId: string, amount: number, symbol: string): Promise<void> {
    try {
      const admins = await this.dataSource.query(
        `SELECT id FROM users WHERE is_admin = TRUE AND status = 'active'`
      );
      for (const admin of admins) {
        await this.dataSource.query(
          `INSERT INTO notifications (user_id, type, title, message, metadata)
           VALUES ($1, 'info', 'New Deposit Request', $2, $3)`,
          [admin.id,
           `New deposit request: ${amount} ${symbol} pending review`,
           JSON.stringify({ requestId, userId, amount, symbol })]
        );
      }
    } catch (err) {
      this.logger.error('Failed to notify admins:', err.message);
    }
  }
}
