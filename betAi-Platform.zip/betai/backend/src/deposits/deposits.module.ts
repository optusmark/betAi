import { Module } from '@nestjs/common';
import { MulterModule } from '@nestjs/platform-express';
import { DepositsController } from './deposits.controller';
import { DepositsService } from './deposits.service';
import { WalletAdminController } from './wallet-admin.controller';
import { WalletAdminService } from './wallet-admin.service';
import { BonusesModule } from '../bonuses/bonuses.module';

@Module({
  imports: [
    BonusesModule,
    MulterModule.register({
      limits: { fileSize: 10 * 1024 * 1024 }, // 10 MB
    }),
  ],
  controllers: [DepositsController, WalletAdminController],
  providers: [DepositsService, WalletAdminService],
  exports: [DepositsService, WalletAdminService],
})
export class DepositsModule {}
