import {
  Injectable, BadRequestException,
  NotFoundException, Logger,
} from '@nestjs/common';
import { DataSource } from 'typeorm';

// Basic wallet address format validators
const ADDRESS_PATTERNS: Record<string, RegExp> = {
  TRC20:  /^T[A-Za-z1-9]{33}$/,
  ERC20:  /^0x[0-9a-fA-F]{40}$/,
  BTC:    /^(1|3|bc1)[A-Za-z0-9]{25,62}$/,
  BEP20:  /^0x[0-9a-fA-F]{40}$/,
  SOL:    /^[A-Za-z0-9]{32,44}$/,
};

@Injectable()
export class WalletAdminService {
  private readonly logger = new Logger(WalletAdminService.name);

  constructor(private readonly dataSource: DataSource) {}

  // ─────────────────────────────────────────────────────────
  // Get all platform wallets
  // ─────────────────────────────────────────────────────────
  async getAll(): Promise<any[]> {
    return this.dataSource.query(
      `SELECT pw.*, ca.symbol, ca.name, ca.min_deposit,
              (SELECT COUNT(*) FROM deposit_requests dr
               WHERE dr.asset_id = pw.asset_id AND dr.status = 'pending_review') AS pending_count
       FROM platform_wallets pw
       JOIN crypto_assets ca ON pw.asset_id = ca.id
       ORDER BY ca.symbol, pw.network`
    );
  }

  // ─────────────────────────────────────────────────────────
  // Get single wallet
  // ─────────────────────────────────────────────────────────
  async getOne(walletId: string): Promise<any> {
    const [wallet] = await this.dataSource.query(
      `SELECT pw.*, ca.symbol, ca.name, ca.min_deposit
       FROM platform_wallets pw
       JOIN crypto_assets ca ON pw.asset_id = ca.id
       WHERE pw.id = $1`,
      [walletId]
    );
    if (!wallet) throw new NotFoundException('Wallet not found');
    return wallet;
  }

  // ─────────────────────────────────────────────────────────
  // Create wallet for an asset
  // ─────────────────────────────────────────────────────────
  async create(adminId: string, data: {
    assetId:  string;
    address:  string;
    label?:   string;
  }): Promise<any> {
    // Validate asset exists
    const [asset] = await this.dataSource.query(
      `SELECT id, symbol, network FROM crypto_assets WHERE id = $1 AND is_active = TRUE`,
      [data.assetId]
    );
    if (!asset) throw new BadRequestException('Asset not found or inactive');

    // Validate address format
    this.validateAddress(data.address, asset.network);

    // Check no duplicate
    const [existing] = await this.dataSource.query(
      `SELECT id FROM platform_wallets WHERE asset_id = $1`,
      [data.assetId]
    );
    if (existing) {
      throw new BadRequestException(
        `Wallet for this asset already exists. Use update instead.`
      );
    }

    const [wallet] = await this.dataSource.query(
      `INSERT INTO platform_wallets (asset_id, address, network, label, is_active)
       VALUES ($1, $2, $3, $4, TRUE)
       RETURNING *`,
      [data.assetId, data.address.trim(), asset.network, data.label || `${asset.symbol} ${asset.network} Wallet`]
    );

    await this.auditLog(adminId, 'create_wallet', wallet.id, {
      assetId: data.assetId,
      symbol: asset.symbol,
      network: asset.network,
      address: data.address,
    });

    this.logger.log(`Admin ${adminId} created wallet for ${asset.symbol}/${asset.network}`);
    return wallet;
  }

  // ─────────────────────────────────────────────────────────
  // Update wallet address
  // ─────────────────────────────────────────────────────────
  async update(adminId: string, walletId: string, data: {
    address?:  string;
    label?:    string;
    isActive?: boolean;
  }): Promise<any> {
    const [wallet] = await this.dataSource.query(
      `SELECT pw.*, ca.symbol, ca.network
       FROM platform_wallets pw
       JOIN crypto_assets ca ON pw.asset_id = ca.id
       WHERE pw.id = $1`,
      [walletId]
    );
    if (!wallet) throw new NotFoundException('Wallet not found');

    // Validate new address if provided
    if (data.address) {
      this.validateAddress(data.address, wallet.network);
    }

    const oldAddress = wallet.address;

    const [updated] = await this.dataSource.query(
      `UPDATE platform_wallets
       SET address   = COALESCE($1, address),
           label     = COALESCE($2, label),
           is_active = COALESCE($3, is_active),
           updated_at = NOW()
       WHERE id = $4
       RETURNING *`,
      [data.address?.trim() || null, data.label || null, data.isActive ?? null, walletId]
    );

    await this.auditLog(adminId, 'update_wallet', walletId, {
      symbol:     wallet.symbol,
      network:    wallet.network,
      oldAddress: oldAddress,
      newAddress: data.address || oldAddress,
      label:      data.label,
      isActive:   data.isActive,
    });

    this.logger.log(
      `Admin ${adminId} updated wallet ${walletId} (${wallet.symbol}/${wallet.network})`
    );
    return updated;
  }

  // ─────────────────────────────────────────────────────────
  // Toggle wallet active/inactive
  // ─────────────────────────────────────────────────────────
  async toggle(adminId: string, walletId: string): Promise<any> {
    const [wallet] = await this.dataSource.query(
      `UPDATE platform_wallets SET is_active = NOT is_active, updated_at = NOW()
       WHERE id = $1 RETURNING *, (SELECT symbol FROM crypto_assets WHERE id = asset_id) AS symbol`,
      [walletId]
    );
    if (!wallet) throw new NotFoundException('Wallet not found');

    await this.auditLog(adminId, wallet.is_active ? 'activate_wallet' : 'deactivate_wallet', walletId, {
      symbol: wallet.symbol, isActive: wallet.is_active
    });

    return { isActive: wallet.is_active, message: `Wallet ${wallet.is_active ? 'activated' : 'deactivated'}` };
  }

  // ─────────────────────────────────────────────────────────
  // Get wallet change history from audit log
  // ─────────────────────────────────────────────────────────
  async getWalletHistory(walletId: string): Promise<any[]> {
    return this.dataSource.query(
      `SELECT al.*, u.email AS admin_email
       FROM audit_log al
       JOIN users u ON al.admin_id = u.id
       WHERE al.target_id = $1
         AND al.action IN ('create_wallet','update_wallet','activate_wallet','deactivate_wallet')
       ORDER BY al.created_at DESC`,
      [walletId]
    );
  }

  // ─────────────────────────────────────────────────────────
  // Get all available crypto assets (to create wallet for)
  // ─────────────────────────────────────────────────────────
  async getAvailableAssets(): Promise<any[]> {
    return this.dataSource.query(
      `SELECT ca.id, ca.symbol, ca.name, ca.network, ca.min_deposit,
              pw.id AS wallet_id, pw.address AS current_address, pw.is_active AS wallet_active
       FROM crypto_assets ca
       LEFT JOIN platform_wallets pw ON pw.asset_id = ca.id
       WHERE ca.is_active = TRUE
       ORDER BY ca.symbol, ca.network`
    );
  }

  // ─────────────────────────────────────────────────────────
  // Validate address format
  // ─────────────────────────────────────────────────────────
  private validateAddress(address: string, network: string): void {
    if (!address || address.trim().length < 10) {
      throw new BadRequestException('Address is too short');
    }
    if (address.trim().length > 255) {
      throw new BadRequestException('Address is too long');
    }

    const pattern = ADDRESS_PATTERNS[network.toUpperCase()];
    if (pattern && !pattern.test(address.trim())) {
      throw new BadRequestException(
        `Invalid ${network} address format. Please verify the address.`
      );
    }
    // If no pattern for network — allow but warn (logged)
  }

  // ─────────────────────────────────────────────────────────
  // Write to audit log
  // ─────────────────────────────────────────────────────────
  private async auditLog(
    adminId: string,
    action: string,
    targetId: string,
    details: Record<string, any>,
  ): Promise<void> {
    try {
      const [admin] = await this.dataSource.query(
        `SELECT email FROM users WHERE id = $1`, [adminId]
      );
      await this.dataSource.query(
        `INSERT INTO audit_log (admin_id, admin_email, action, target_type, target_id, details)
         VALUES ($1, $2, $3, 'platform_wallet', $4, $5)`,
        [adminId, admin?.email, action, targetId, JSON.stringify(details)]
      );
    } catch (err) {
      this.logger.error('Audit log error:', err.message);
    }
  }
}
