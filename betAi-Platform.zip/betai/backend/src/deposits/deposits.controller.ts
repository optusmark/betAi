import {
  Controller, Post, Get, Patch, Body, Param,
  Query, Request, UseGuards, UseInterceptors,
  UploadedFile, ParseUUIDPipe, Ip, HttpCode, HttpStatus,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { diskStorage } from 'multer';
import { extname } from 'path';
import { v4 as uuid } from 'uuid';
import { ApiTags, ApiBearerAuth, ApiConsumes } from '@nestjs/swagger';
import { Throttle } from '@nestjs/throttler';
import { DepositsService } from './deposits.service';
import { JwtAuthGuard, AdminGuard } from '../auth/guards/jwt-auth.guard';

// Multer storage config — save to /uploads/deposits/
const depositStorage = diskStorage({
  destination: './uploads/deposits',
  filename: (_req, file, cb) => {
    const uniqueName = `${uuid()}${extname(file.originalname).toLowerCase()}`;
    cb(null, uniqueName);
  },
});

@ApiTags('Deposits')
@ApiBearerAuth()
@Controller('deposits')
export class DepositsController {
  constructor(private readonly depositsService: DepositsService) {}

  // ── USER ENDPOINTS ──────────────────────────────────────

  // Get deposit wallet info for a specific asset
  @Get('wallet/:assetId')
  @UseGuards(JwtAuthGuard)
  async getDepositInfo(@Param('assetId', ParseUUIDPipe) assetId: string) {
    return this.depositsService.getDepositInfo(assetId);
  }

  // Get all available deposit wallets
  @Get('wallets')
  @UseGuards(JwtAuthGuard)
  async getAllWallets() {
    return this.depositsService.getAllDepositWallets();
  }

  // Submit deposit confirmation request (with proof upload)
  @Post('request')
  @UseGuards(JwtAuthGuard)
  @HttpCode(HttpStatus.CREATED)
  @Throttle({ default: { limit: 5, ttl: 60_000 } })  // 5 requests per minute
  @UseInterceptors(FileInterceptor('proof', { storage: depositStorage }))
  @ApiConsumes('multipart/form-data')
  async submitRequest(
    @Request() req,
    @Body() body: { assetId: string; amount: string },
    @UploadedFile() file: Express.Multer.File,
  ) {
    return this.depositsService.submitDepositRequest(
      req.user.id,
      { assetId: body.assetId, amount: parseFloat(body.amount) },
      file,
    );
  }

  // Get my deposit history
  @Get('my')
  @UseGuards(JwtAuthGuard)
  async getMyHistory(@Request() req) {
    return this.depositsService.getUserDepositHistory(req.user.id);
  }

  // ── ADMIN ENDPOINTS ─────────────────────────────────────

  // All deposit requests with filters
  @Get('admin/requests')
  @UseGuards(AdminGuard)
  async adminGetRequests(
    @Query('status')   status?: string,
    @Query('userId')   userId?: string,
    @Query('search')   search?: string,
    @Query('dateFrom') dateFrom?: string,
    @Query('dateTo')   dateTo?: string,
    @Query('sortBy')   sortBy?: 'newest' | 'oldest' | 'highest' | 'lowest',
    @Query('page')     page?: number,
    @Query('limit')    limit?: number,
  ) {
    return this.depositsService.adminGetRequests({
      status, userId, search, dateFrom, dateTo, sortBy,
      page: page ? parseInt(String(page)) : 1,
      limit: limit ? parseInt(String(limit)) : 20,
    });
  }

  // Admin dashboard stats
  @Get('admin/stats')
  @UseGuards(AdminGuard)
  async adminStats() {
    return this.depositsService.adminGetStats();
  }

  // Single request detail
  @Get('admin/requests/:id')
  @UseGuards(AdminGuard)
  async adminGetDetail(@Param('id', ParseUUIDPipe) id: string) {
    return this.depositsService.adminGetRequestDetail(id);
  }

  // Approve
  @Patch('admin/requests/:id/approve')
  @UseGuards(AdminGuard)
  @HttpCode(HttpStatus.OK)
  async adminApprove(
    @Param('id', ParseUUIDPipe) id: string,
    @Request() req,
    @Ip() ip: string,
  ) {
    return this.depositsService.adminApproveRequest(req.user.id, id, ip);
  }

  // Reject
  @Patch('admin/requests/:id/reject')
  @UseGuards(AdminGuard)
  @HttpCode(HttpStatus.OK)
  async adminReject(
    @Param('id', ParseUUIDPipe) id: string,
    @Request() req,
    @Body('reason') reason: string,
    @Ip() ip: string,
  ) {
    return this.depositsService.adminRejectRequest(req.user.id, id, reason, ip);
  }

  // Audit log
  @Get('admin/audit-log')
  @UseGuards(AdminGuard)
  async getAuditLog(
    @Query('page') page?: number,
    @Query('limit') limit?: number,
  ) {
    return this.depositsService.getAuditLog(
      page ? parseInt(String(page)) : 1,
      limit ? parseInt(String(limit)) : 50,
    );
  }

  // Update platform wallet address
  @Patch('admin/wallets/:assetId')
  @UseGuards(AdminGuard)
  async updateWallet(
    @Param('assetId', ParseUUIDPipe) assetId: string,
    @Body('address') address: string,
    @Request() req,
  ) {
    return this.depositsService.updateWallet(req.user.id, assetId, address);
  }
}

// NOTE: Add this import at top of file:
// import { Response } from 'express';
// import { Res } from '@nestjs/common';

// Serve proof file — admin only, auth-gated
// GET /api/deposits/admin/proof/:filename
// (Implementation note: add @Res() res: Response param and use res.sendFile())
// Example:
// @Get('admin/proof/:filename')
// @UseGuards(AdminGuard)
// async serveProof(
//   @Param('filename') filename: string,
//   @Res() res: Response,
// ) {
//   const filePath = path.join(process.cwd(), 'uploads', 'deposits', filename);
//   if (!fs.existsSync(filePath)) throw new NotFoundException('File not found');
//   return res.sendFile(filePath);
// }
