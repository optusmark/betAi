import { Injectable, BadRequestException, NotFoundException } from '@nestjs/common';
import { DataSource } from 'typeorm';

@Injectable()
export class KycService {
  constructor(private readonly dataSource: DataSource) {}

  async submitKyc(userId: string, data: {
    documentType: string;
    frontImageUrl: string;
    backImageUrl?: string;
    selfieUrl?: string;
  }): Promise<any> {
    // Check existing KYC
    const existing = await this.dataSource.query(
      `SELECT id, status FROM kyc_documents WHERE user_id = $1 ORDER BY created_at DESC LIMIT 1`,
      [userId]
    );

    if (existing[0] && ['pending', 'under_review', 'approved'].includes(existing[0].status)) {
      throw new BadRequestException('KYC already submitted or approved');
    }

    const kyc = await this.dataSource.query(
      `INSERT INTO kyc_documents (user_id, document_type, front_image_url, back_image_url, selfie_url, status)
       VALUES ($1, $2, $3, $4, $5, 'pending')
       RETURNING *`,
      [userId, data.documentType, data.frontImageUrl, data.backImageUrl, data.selfieUrl]
    );

    await this.dataSource.query(
      `UPDATE users SET kyc_status = 'pending', updated_at = NOW() WHERE id = $1`, [userId]
    );

    await this.dataSource.query(
      `INSERT INTO notifications (user_id, type, title, message)
       VALUES ($1, 'info', 'KYC Submitted', 'Your KYC documents have been submitted and are under review.')`,
      [userId]
    );

    return kyc[0];
  }

  async getKycStatus(userId: string): Promise<any> {
    const kyc = await this.dataSource.query(
      `SELECT * FROM kyc_documents WHERE user_id = $1 ORDER BY created_at DESC LIMIT 1`,
      [userId]
    );
    return kyc[0] || { status: 'not_submitted' };
  }

  async adminReviewKyc(adminId: string, kycId: string, action: 'approve' | 'reject', reason?: string): Promise<any> {
    const kyc = await this.dataSource.query(
      `SELECT * FROM kyc_documents WHERE id = $1`, [kycId]
    );
    if (!kyc[0]) throw new NotFoundException('KYC document not found');

    const newStatus = action === 'approve' ? 'approved' : 'rejected';
    const userKycStatus = action === 'approve' ? 'approved' : 'rejected';

    await this.dataSource.query(
      `UPDATE kyc_documents SET status = $1, rejection_reason = $2,
       reviewed_by = $3, reviewed_at = NOW(), updated_at = NOW() WHERE id = $4`,
      [newStatus, reason || null, adminId, kycId]
    );

    await this.dataSource.query(
      `UPDATE users SET kyc_status = $1, updated_at = NOW() WHERE id = $2`,
      [userKycStatus, kyc[0].user_id]
    );

    const message = action === 'approve'
      ? 'Your KYC has been approved! You can now make withdrawals.'
      : `Your KYC was rejected. Reason: ${reason}. Please resubmit.`;

    await this.dataSource.query(
      `INSERT INTO notifications (user_id, type, title, message)
       VALUES ($1, $2, $3, $4)`,
      [kyc[0].user_id, action === 'approve' ? 'success' : 'error',
       action === 'approve' ? 'KYC Approved' : 'KYC Rejected', message]
    );

    await this.dataSource.query(
      `INSERT INTO admin_logs (admin_id, action, target_type, target_id, details)
       VALUES ($1, $2, 'kyc', $3, $4)`,
      [adminId, `kyc_${action}`, kycId, JSON.stringify({ reason })]
    );

    return { message: `KYC ${action}d successfully` };
  }

  async adminGetPendingKyc(): Promise<any[]> {
    return this.dataSource.query(
      `SELECT kd.*, u.email, u.phone, u.first_name, u.last_name
       FROM kyc_documents kd
       JOIN users u ON kd.user_id = u.id
       WHERE kd.status IN ('pending', 'under_review')
       ORDER BY kd.submitted_at ASC`
    );
  }
}
