import {
  Controller, Get, Post, Body, UseGuards, Request,
  UseInterceptors, UploadedFiles
} from '@nestjs/common';
import { FileFieldsInterceptor } from '@nestjs/platform-express';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { diskStorage } from 'multer';
import { extname } from 'path';
import { KycService } from './kyc.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

const storage = diskStorage({
  destination: './uploads/kyc',
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
    cb(null, `${uniqueSuffix}${extname(file.originalname)}`);
  },
});

@ApiTags('KYC')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('kyc')
export class KycController {
  constructor(private readonly kycService: KycService) {}

  @Get('status')
  async getStatus(@Request() req) {
    return this.kycService.getKycStatus(req.user.id);
  }

  @Post('submit')
  @UseInterceptors(FileFieldsInterceptor([
    { name: 'front', maxCount: 1 },
    { name: 'back', maxCount: 1 },
    { name: 'selfie', maxCount: 1 },
  ], { storage }))
  async submit(
    @Request() req,
    @UploadedFiles() files: any,
    @Body('documentType') documentType: string,
  ) {
    const baseUrl = process.env.BACKEND_URL || 'http://localhost:4000';
    return this.kycService.submitKyc(req.user.id, {
      documentType,
      frontImageUrl: files.front?.[0] ? `${baseUrl}/uploads/kyc/${files.front[0].filename}` : null,
      backImageUrl: files.back?.[0] ? `${baseUrl}/uploads/kyc/${files.back[0].filename}` : null,
      selfieUrl: files.selfie?.[0] ? `${baseUrl}/uploads/kyc/${files.selfie[0].filename}` : null,
    });
  }
}
