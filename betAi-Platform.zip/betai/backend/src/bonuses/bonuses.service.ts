import { Injectable, Logger } from '@nestjs/common';
import { DataSource } from 'typeorm';
import { Cron } from '@nestjs/schedule';

@Injectable()
export class BonusesService {
  private readonly logger = new Logger(BonusesService.name);

  constructor(private readonly dataSource: DataSource) {}

  // ─────────────────────────────────────────────────────────
  // Called when user makes their FIRST deposit
  // Starts the 40-day cycle
  // ─────────────────────────────────────────────────────────
  async startBonusPeriod(userId: string, depositBase: number): Promise<void> {
    // Guard: don't create if active period already exists
    const existing = await this.dataSource.query(
      `SELECT id FROM bonus_periods WHERE user_id = $1 AND status = 'active' LIMIT 1`,
      [userId]
    );
    if (existing.length > 0) {
      this.logger.warn(`Active period already exists for user ${userId}, skipping`);
      return;
    }

    const startDate = new Date();
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + 40);

    // Check if user already has referral_condition_met = true (from previous cycle)
    const [user] = await this.dataSource.query(
      `SELECT referral_condition_met FROM users WHERE id = $1`,
      [userId]
    );

    await this.dataSource.query(
      `INSERT INTO bonus_periods
         (user_id, period_number, start_date, end_date, status,
          referral_condition_met, deposit_base_at_start, last_daily_bonus_date)
       VALUES (
         $1,
         COALESCE((SELECT MAX(period_number) + 1 FROM bonus_periods WHERE user_id = $1), 1),
         $2, $3, 'active',
         $4,
         $5,
         NULL
       )`,
      [userId, startDate, endDate, user?.referral_condition_met ?? false, depositBase]
    );

    this.logger.log(`Bonus period started for user ${userId}, base: ${depositBase}`);
  }

  // ─────────────────────────────────────────────────────────
  // Called on every new deposit (not just first)
  // Updates deposit_base on active period so 2% recalculates
  // ─────────────────────────────────────────────────────────
  async updateDepositBase(userId: string, newDepositBase: number): Promise<void> {
    await this.dataSource.query(
      `UPDATE bonus_periods
       SET deposit_base_at_start = $1, updated_at = NOW()
       WHERE user_id = $2 AND status = 'active'`,
      [newDepositBase, userId]
    );
  }

  // ─────────────────────────────────────────────────────────
  // DAILY CRON — runs at 00:01 every day
  // Pays 2% of deposit_base to each user with active cycle
  //
  // Bug fixes applied:
  // 1. Checks last_daily_bonus_date to prevent double-pay on restart
  // 2. Uses deposit_base (NOT available_balance) for calculation
  // 3. Checks referral_condition_met before paying
  // 4. Updates last_daily_bonus_date atomically inside transaction
  // ─────────────────────────────────────────────────────────
  @Cron('1 0 * * *') // 00:01 every day
  async payDailyBonuses(): Promise<void> {
    this.logger.log('=== Daily bonus cron started ===');

    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD

    // Select active periods that:
    // a) haven't been paid today (last_daily_bonus_date != today)
    // b) are not expired yet
    // c) user has deposit_base > 0
    const activePeriods = await this.dataSource.query(
      `SELECT
         bp.id, bp.user_id, bp.deposit_base_at_start,
         bp.referral_condition_met, bp.end_date,
         bp.period_number, bp.total_bonus_paid,
         u.referral_condition_met AS user_referral_met
       FROM bonus_periods bp
       JOIN users u ON bp.user_id = u.id
       WHERE bp.status = 'active'
         AND bp.deposit_base_at_start > 0
         AND (bp.last_daily_bonus_date IS NULL OR bp.last_daily_bonus_date < $1::DATE)
         AND u.status = 'active'
         AND u.deleted_at IS NULL`,
      [today]
    );

    this.logger.log(`Found ${activePeriods.length} periods to process`);

    let paid = 0, skipped = 0;

    for (const period of activePeriods) {
      try {
        await this.processDailyBonus(period, today);
        paid++;
      } catch (err) {
        this.logger.error(`Failed daily bonus for period ${period.id}: ${err.message}`);
        skipped++;
      }
    }

    // After daily bonuses, check for expired periods
    await this.processExpiredPeriods();

    this.logger.log(`=== Daily cron done: paid=${paid}, skipped=${skipped} ===`);
  }

  // ─────────────────────────────────────────────────────────
  // Pay one daily 2% bonus to one user
  // ─────────────────────────────────────────────────────────
  private async processDailyBonus(period: any, today: string): Promise<void> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // LOCK the bonus_period row to prevent race condition on concurrent execution
      const [locked] = await queryRunner.query(
        `SELECT id, last_daily_bonus_date, deposit_base_at_start, referral_condition_met
         FROM bonus_periods
         WHERE id = $1 AND status = 'active'
         FOR UPDATE SKIP LOCKED`,
        [period.id]
      );

      // If another process grabbed it or it was already paid today → skip
      if (!locked) return;
      if (locked.last_daily_bonus_date && locked.last_daily_bonus_date >= today) return;

      // Double-check no duplicate in bonus_history (idempotency guard)
      const duplicate = await queryRunner.query(
        `SELECT id FROM bonus_history WHERE user_id = $1 AND bonus_date = $2`,
        [period.user_id, today]
      );
      if (duplicate.length > 0) {
        // Already paid today via another path, just update the date marker
        await queryRunner.query(
          `UPDATE bonus_periods SET last_daily_bonus_date = $1 WHERE id = $2`,
          [today, period.id]
        );
        await queryRunner.commitTransaction();
        return;
      }

      // Calculate bonus from deposit_base ONLY (not available_balance, not bonus_balance)
      const depositBase = parseFloat(locked.deposit_base_at_start);
      const bonusAmount = parseFloat((depositBase * 0.02).toFixed(8));

      if (bonusAmount <= 0) {
        await queryRunner.commitTransaction();
        return;
      }

      // Get primary asset (USDT TRC20)
      const [asset] = await queryRunner.query(
        `SELECT id FROM crypto_assets WHERE symbol = 'USDT' AND network = 'TRC20' AND is_active = TRUE LIMIT 1`
      );
      if (!asset) {
        this.logger.error('No USDT TRC20 asset found');
        await queryRunner.rollbackTransaction();
        return;
      }

      // Credit bonus_balance (separate from available_balance which holds deposit funds)
      await queryRunner.query(
        `INSERT INTO balances (user_id, asset_id, bonus_balance, total_bonus_paid)
         VALUES ($1, $2, $3, $3)
         ON CONFLICT (user_id, asset_id) DO UPDATE
           SET bonus_balance   = balances.bonus_balance + $3,
               total_bonus_paid = balances.total_bonus_paid + $3,
               updated_at      = NOW()`,
        [period.user_id, asset.id, bonusAmount]
      );

      // Record in bonus_history with UNIQUE(user_id, bonus_date) constraint as safety net
      await queryRunner.query(
        `INSERT INTO bonus_history
           (user_id, period_id, amount, deposit_base, percentage, bonus_date, description)
         VALUES ($1, $2, $3, $4, 0.02, $5, $6)
         ON CONFLICT (user_id, bonus_date) DO NOTHING`,
        [
          period.user_id, period.id, bonusAmount,
          depositBase, today,
          `Daily 2% bonus on deposit base $${depositBase.toFixed(2)}`
        ]
      );

      // Record transaction
      await queryRunner.query(
        `INSERT INTO transactions (user_id, asset_id, type, amount, description)
         VALUES ($1, $2, 'bonus', $3, $4)`,
        [period.user_id, asset.id, bonusAmount, `Daily bonus ${today}`]
      );

      // Update period: mark today as paid, accumulate total
      await queryRunner.query(
        `UPDATE bonus_periods
         SET last_daily_bonus_date = $1,
             total_bonus_paid      = total_bonus_paid + $2,
             updated_at            = NOW()
         WHERE id = $3`,
        [today, bonusAmount, period.id]
      );

      // Notify user
      await queryRunner.query(
        `INSERT INTO notifications (user_id, type, title, message)
         VALUES ($1, 'success', 'Daily Bonus Credited', $2)`,
        [period.user_id, `+${bonusAmount.toFixed(2)} USDT daily bonus credited to your account.`]
      );

      await queryRunner.commitTransaction();
      this.logger.log(`Daily bonus ${bonusAmount} USDT → user ${period.user_id}`);
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  }

  // ─────────────────────────────────────────────────────────
  // Check periods that have reached end_date
  // If 5 RPs met → mark completed, start new period
  // If not met → mark failed, user can only withdraw deposit
  // ─────────────────────────────────────────────────────────
  private async processExpiredPeriods(): Promise<void> {
    const expired = await this.dataSource.query(
      `SELECT bp.*, u.referral_condition_met AS user_referral_met, u.active_referrals_count
       FROM bonus_periods bp
       JOIN users u ON bp.user_id = u.id
       WHERE bp.status = 'active'
         AND bp.end_date <= NOW()
         AND u.deleted_at IS NULL`
    );

    for (const period of expired) {
      const queryRunner = this.dataSource.createQueryRunner();
      await queryRunner.connect();
      await queryRunner.startTransaction();
      try {
        // referral_condition_met is true forever once user has 5 active RPs
        const conditionMet = period.user_referral_met || period.active_referrals_count >= 5;

        if (conditionMet) {
          // Mark completed
          await queryRunner.query(
            `UPDATE bonus_periods SET status = 'completed', paid_at = NOW(), updated_at = NOW()
             WHERE id = $1`, [period.id]
          );

          // Get current deposit_base for next period
          const [balance] = await queryRunner.query(
            `SELECT deposit_base FROM balances WHERE user_id = $1 LIMIT 1`, [period.user_id]
          );
          const newBase = parseFloat(balance?.deposit_base || '0');

          // Start next 40-day period immediately
          const nextStart = new Date();
          const nextEnd = new Date();
          nextEnd.setDate(nextEnd.getDate() + 40);

          await queryRunner.query(
            `INSERT INTO bonus_periods
               (user_id, period_number, start_date, end_date, status,
                referral_condition_met, deposit_base_at_start)
             VALUES ($1, $2, $3, $4, 'active', TRUE, $5)`,
            [period.user_id, period.period_number + 1, nextStart, nextEnd, newBase]
          );

          await queryRunner.query(
            `INSERT INTO notifications (user_id, type, title, message)
             VALUES ($1, 'success', 'New Bonus Cycle Started', $2)`,
            [period.user_id, `Period #${period.period_number} completed. New 40-day cycle started.`]
          );
        } else {
          // Mark failed — user can only withdraw their deposit
          await queryRunner.query(
            `UPDATE bonus_periods SET status = 'failed', updated_at = NOW() WHERE id = $1`,
            [period.id]
          );
          await queryRunner.query(
            `INSERT INTO notifications (user_id, type, title, message)
             VALUES ($1, 'warning', 'Bonus Period Expired', $2)`,
            [period.user_id,
             'Your 40-day period ended without 5 active referrals. You may withdraw your deposit only. Make a new deposit to start a new cycle.']
          );
        }
        await queryRunner.commitTransaction();
      } catch (err) {
        await queryRunner.rollbackTransaction();
        this.logger.error(`Failed processing expired period ${period.id}: ${err.message}`);
      } finally {
        await queryRunner.release();
      }
    }
  }

  // ─────────────────────────────────────────────────────────
  // Called after withdrawal: reset cycle
  // ─────────────────────────────────────────────────────────
  async resetCycleAfterWithdrawal(userId: string): Promise<void> {
    // Cancel any active period
    await this.dataSource.query(
      `UPDATE bonus_periods SET status = 'failed', updated_at = NOW()
       WHERE user_id = $1 AND status = 'active'`,
      [userId]
    );
    this.logger.log(`Cycle reset after withdrawal for user ${userId}`);
  }

  // ─────────────────────────────────────────────────────────
  // API: get user's current bonus status
  // ─────────────────────────────────────────────────────────
  async getUserBonusStatus(userId: string): Promise<any> {
    const [period] = await this.dataSource.query(
      `SELECT bp.*,
         EXTRACT(DAYS FROM (bp.end_date - NOW()))        AS days_remaining,
         EXTRACT(DAYS FROM (NOW() - bp.start_date))      AS days_elapsed,
         u.active_referrals_count,
         u.referral_condition_met
       FROM bonus_periods bp
       JOIN users u ON bp.user_id = u.id
       WHERE bp.user_id = $1 AND bp.status = 'active'
       ORDER BY bp.period_number DESC
       LIMIT 1`,
      [userId]
    );

    const history = await this.dataSource.query(
      `SELECT * FROM bonus_history
       WHERE user_id = $1
       ORDER BY bonus_date DESC
       LIMIT 30`,
      [userId]
    );

    const [balance] = await this.dataSource.query(
      `SELECT deposit_base, available_balance, bonus_balance, locked_balance
       FROM balances WHERE user_id = $1 LIMIT 1`,
      [userId]
    );

    return {
      currentPeriod: period || null,
      history,
      balance: balance || { deposit_base: 0, available_balance: 0, bonus_balance: 0 },
      dailyBonusPreview: balance
        ? parseFloat((parseFloat(balance.deposit_base) * 0.02).toFixed(8))
        : 0,
    };
  }
}
