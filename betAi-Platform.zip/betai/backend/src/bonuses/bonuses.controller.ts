import { Controller, Get, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { BonusesService } from './bonuses.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('Bonuses')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('bonuses')
export class BonusesController {
  constructor(private readonly bonusesService: BonusesService) {}

  @Get('status')
  async getStatus(@Request() req) {
    return this.bonusesService.getUserBonusStatus(req.user.id);
  }
}
