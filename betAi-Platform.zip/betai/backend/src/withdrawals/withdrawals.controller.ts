import { Controller, Post, Get, Body, Query, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { WithdrawalsService } from './withdrawals.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('Withdrawals')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('withdrawals')
export class WithdrawalsController {
  constructor(private readonly withdrawalsService: WithdrawalsService) {}

  @Get('preview')
  async preview(@Request() req, @Query('assetId') assetId: string) {
    return this.withdrawalsService.getWithdrawalPreview(req.user.id, assetId);
  }

  @Post('request')
  async request(@Request() req, @Body() body: any) {
    return this.withdrawalsService.requestWithdrawal(req.user.id, body);
  }

  @Get('history')
  async history(@Request() req) {
    return this.withdrawalsService.getWithdrawalHistory(req.user.id);
  }
}
