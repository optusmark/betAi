import {
  Injectable, BadRequestException, ForbiddenException
} from '@nestjs/common';
import { DataSource } from 'typeorm';
import { BonusesService } from '../bonuses/bonuses.service';

@Injectable()
export class WithdrawalsService {
  constructor(
    private readonly dataSource: DataSource,
    private readonly bonusesService: BonusesService,
  ) {}

  async requestWithdrawal(userId: string, data: {
    assetId: string;
    amount: number;
    toAddress: string;
    network: string;
  }): Promise<any> {

    // ── Check activation (replaces KYC) ─────────────────────
    const [user] = await this.dataSource.query(
      `SELECT activation_status, referral_condition_met, active_referrals_count
       FROM users WHERE id = $1 AND deleted_at IS NULL`,
      [userId]
    );
    if (!user) throw new ForbiddenException('User not found');

    // User must have made at least one deposit to withdraw
    const [balance] = await this.dataSource.query(
      `SELECT deposit_base, available_balance, locked_balance, bonus_balance
       FROM balances WHERE user_id = $1 AND asset_id = $2`,
      [userId, data.assetId]
    );
    if (!balance || parseFloat(balance.deposit_base) <= 0) {
      throw new ForbiddenException('No deposit found. Make a deposit first.');
    }

    // ── Asset checks ─────────────────────────────────────────
    const [asset] = await this.dataSource.query(
      `SELECT * FROM crypto_assets WHERE id = $1 AND is_active = TRUE`,
      [data.assetId]
    );
    if (!asset) throw new BadRequestException('Asset not found');

    if (data.amount < parseFloat(asset.min_withdrawal)) {
      throw new BadRequestException(
        `Minimum withdrawal is ${asset.min_withdrawal} ${asset.symbol}`
      );
    }

    // ── Determine what user can withdraw ─────────────────────
    const depositBase   = parseFloat(balance.deposit_base);
    const bonusBalance  = parseFloat(balance.bonus_balance);
    const lockedBalance = parseFloat(balance.locked_balance);
    const availableBalance = parseFloat(balance.available_balance);

    // referral_condition_met is TRUE forever once user had 5 active RPs
    const canWithdrawFull = user.referral_condition_met
      || user.active_referrals_count >= 5;

    // What is actually withdrawable (not locked):
    const withdrawableDeposit = Math.max(0, depositBase - lockedBalance);
    const withdrawableBonus   = canWithdrawFull ? bonusBalance : 0;
    const maxWithdrawable     = withdrawableDeposit + withdrawableBonus;

    if (data.amount > maxWithdrawable) {
      if (!canWithdrawFull && bonusBalance > 0) {
        throw new BadRequestException(
          `You can only withdraw your deposit (${withdrawableDeposit.toFixed(2)} ${asset.symbol}). ` +
          `Activate 5 referrals to unlock bonus withdrawal.`
        );
      }
      throw new BadRequestException(
        `Insufficient balance. Maximum withdrawable: ${maxWithdrawable.toFixed(2)} ${asset.symbol}`
      );
    }

    // ── Transaction ──────────────────────────────────────────
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      // Determine withdrawal type
      const withdrawalType = canWithdrawFull ? 'full' : 'deposit_only';

      // Lock the amount
      // If deposit_only: lock from available_balance (which = deposit funds)
      // If full: lock from available_balance + bonus_balance
      let depositLocked = 0;
      let bonusLocked   = 0;

      if (canWithdrawFull) {
        // Take from bonus first, then deposit
        bonusLocked   = Math.min(data.amount, bonusBalance);
        depositLocked = data.amount - bonusLocked;
      } else {
        depositLocked = data.amount;
      }

      // Lock in balances
      await queryRunner.query(
        `UPDATE balances
         SET available_balance = available_balance - $1,
             bonus_balance     = GREATEST(0, bonus_balance - $2),
             locked_balance    = locked_balance + $3,
             updated_at        = NOW()
         WHERE user_id = $4 AND asset_id = $5`,
        [depositLocked, bonusLocked, data.amount, userId, data.assetId]
      );

      // Create withdrawal record with snapshots
      const [withdrawal] = await queryRunner.query(
        `INSERT INTO withdrawals
           (user_id, asset_id, amount, net_amount, to_address, network, status,
            withdrawal_type, deposit_base_snapshot, bonus_snapshot,
            referral_condition_snapshot)
         VALUES ($1, $2, $3, $3, $4, $5, 'pending', $6, $7, $8, $9)
         RETURNING *`,
        [
          userId, data.assetId, data.amount, data.toAddress, data.network,
          withdrawalType, depositBase, bonusBalance, canWithdrawFull,
        ]
      );

      await queryRunner.query(
        `INSERT INTO notifications (user_id, type, title, message)
         VALUES ($1, 'info', 'Withdrawal Request Submitted', $2)`,
        [userId, `Your withdrawal of ${data.amount} ${asset.symbol} is being reviewed. Up to 2 business days.`]
      );

      await queryRunner.commitTransaction();

      return {
        ...withdrawal,
        withdrawalType,
        maxWithdrawable,
        canWithdrawFull,
      };
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  }

  async getWithdrawalHistory(userId: string): Promise<any[]> {
    return this.dataSource.query(
      `SELECT w.*, ca.symbol, ca.network
       FROM withdrawals w
       JOIN crypto_assets ca ON w.asset_id = ca.id
       WHERE w.user_id = $1
       ORDER BY w.created_at DESC`,
      [userId]
    );
  }

  // Returns what a user can currently withdraw (for UI preview)
  async getWithdrawalPreview(userId: string, assetId: string): Promise<any> {
    const [user] = await this.dataSource.query(
      `SELECT referral_condition_met, active_referrals_count FROM users WHERE id = $1`,
      [userId]
    );
    const [balance] = await this.dataSource.query(
      `SELECT deposit_base, available_balance, bonus_balance, locked_balance
       FROM balances WHERE user_id = $1 AND asset_id = $2`,
      [userId, assetId]
    );
    if (!balance) return { depositBase: 0, bonusBalance: 0, maxWithdrawable: 0 };

    const canWithdrawFull = user?.referral_condition_met || user?.active_referrals_count >= 5;
    const depositBase  = parseFloat(balance.deposit_base);
    const bonusBalance = parseFloat(balance.bonus_balance);
    const locked       = parseFloat(balance.locked_balance);

    return {
      depositBase,
      bonusBalance,
      canWithdrawFull,
      activeReferrals: user?.active_referrals_count || 0,
      maxWithdrawable: canWithdrawFull
        ? Math.max(0, depositBase + bonusBalance - locked)
        : Math.max(0, depositBase - locked),
    };
  }

  // ── Admin: approve ───────────────────────────────────────
  async adminApproveWithdrawal(
    adminId: string, withdrawalId: string, txHash: string
  ): Promise<any> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const [withdrawal] = await queryRunner.query(
        `SELECT w.*, ca.symbol
         FROM withdrawals w
         JOIN crypto_assets ca ON w.asset_id = ca.id
         WHERE w.id = $1 AND w.status IN ('pending', 'in_review')
         FOR UPDATE`,
        [withdrawalId]
      );
      if (!withdrawal) throw new BadRequestException('Withdrawal not found');

      await queryRunner.query(
        `UPDATE withdrawals
         SET status = 'approved', tx_hash = $1,
             processed_by = $2, processed_at = NOW(), updated_at = NOW()
         WHERE id = $3`,
        [txHash, adminId, withdrawalId]
      );

      // Deduct locked balance permanently
      // Also reduce deposit_base so future 2% is on correct amount
      await queryRunner.query(
        `UPDATE balances
         SET locked_balance    = locked_balance    - $1,
             total_withdrawn   = total_withdrawn   + $1,
             deposit_base      = GREATEST(0, deposit_base - $2),
             updated_at        = NOW()
         WHERE user_id = $3 AND asset_id = $4`,
        [
          withdrawal.amount,
          // Only reduce deposit_base by the deposit portion (not bonus)
          withdrawal.withdrawal_type === 'full'
            ? parseFloat(withdrawal.deposit_base_snapshot)
              - Math.max(0, parseFloat(withdrawal.deposit_base_snapshot) - withdrawal.amount)
            : withdrawal.amount,
          withdrawal.user_id,
          withdrawal.asset_id,
        ]
      );

      await queryRunner.query(
        `INSERT INTO transactions (user_id, asset_id, type, amount, reference_id, description)
         VALUES ($1, $2, 'withdrawal', $3, $4, 'Withdrawal approved')`,
        [withdrawal.user_id, withdrawal.asset_id, withdrawal.amount, withdrawalId]
      );

      await queryRunner.query(
        `INSERT INTO notifications (user_id, type, title, message)
         VALUES ($1, 'success', 'Withdrawal Approved', $2)`,
        [withdrawal.user_id,
         `Your withdrawal of ${withdrawal.amount} ${withdrawal.symbol} was approved. TX: ${txHash}`]
      );

      await queryRunner.query(
        `INSERT INTO admin_logs (admin_id, action, target_type, target_id, details)
         VALUES ($1, 'approve_withdrawal', 'withdrawal', $2, $3)`,
        [adminId, withdrawalId, JSON.stringify({ txHash, amount: withdrawal.amount })]
      );

      await queryRunner.commitTransaction();

      // Reset 40-day cycle after withdrawal
      await this.bonusesService.resetCycleAfterWithdrawal(withdrawal.user_id);

      return { message: 'Withdrawal approved', txHash };
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  }

  // ── Admin: reject ────────────────────────────────────────
  async adminRejectWithdrawal(
    adminId: string, withdrawalId: string, reason: string
  ): Promise<any> {
    const queryRunner = this.dataSource.createQueryRunner();
    await queryRunner.connect();
    await queryRunner.startTransaction();

    try {
      const [withdrawal] = await queryRunner.query(
        `SELECT w.*, ca.symbol
         FROM withdrawals w
         JOIN crypto_assets ca ON w.asset_id = ca.id
         WHERE w.id = $1 AND w.status IN ('pending', 'in_review')
         FOR UPDATE`,
        [withdrawalId]
      );
      if (!withdrawal) throw new BadRequestException('Withdrawal not found');

      await queryRunner.query(
        `UPDATE withdrawals
         SET status = 'rejected', rejection_reason = $1,
             processed_by = $2, processed_at = NOW(), updated_at = NOW()
         WHERE id = $3`,
        [reason, adminId, withdrawalId]
      );

      // Restore locked funds to available
      await queryRunner.query(
        `UPDATE balances
         SET available_balance = available_balance + $1,
             bonus_balance     = bonus_balance     + $2,
             locked_balance    = locked_balance    - $3,
             updated_at        = NOW()
         WHERE user_id = $4 AND asset_id = $5`,
        [
          withdrawal.withdrawal_type === 'full'
            ? parseFloat(withdrawal.deposit_base_snapshot) >= withdrawal.amount
              ? withdrawal.amount : parseFloat(withdrawal.deposit_base_snapshot)
            : withdrawal.amount,
          withdrawal.withdrawal_type === 'full'
            ? Math.max(0, withdrawal.amount - parseFloat(withdrawal.deposit_base_snapshot))
            : 0,
          withdrawal.amount,
          withdrawal.user_id,
          withdrawal.asset_id,
        ]
      );

      await queryRunner.query(
        `INSERT INTO notifications (user_id, type, title, message)
         VALUES ($1, 'error', 'Withdrawal Rejected', $2)`,
        [withdrawal.user_id,
         `Your withdrawal was rejected. Reason: ${reason}. Funds have been returned.`]
      );

      await queryRunner.query(
        `INSERT INTO admin_logs (admin_id, action, target_type, target_id, details)
         VALUES ($1, 'reject_withdrawal', 'withdrawal', $2, $3)`,
        [adminId, withdrawalId, JSON.stringify({ reason })]
      );

      await queryRunner.commitTransaction();
      return { message: 'Withdrawal rejected, funds returned' };
    } catch (err) {
      await queryRunner.rollbackTransaction();
      throw err;
    } finally {
      await queryRunner.release();
    }
  }
}
