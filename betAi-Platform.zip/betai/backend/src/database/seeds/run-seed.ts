import { DataSource } from 'typeorm';
import { config } from 'dotenv';
import { seedSuperAdmins } from './superadmin.seed';

config();

async function main() {
  const ds = new DataSource({
    type: 'postgres',
    url: process.env.DATABASE_URL,
  });
  await ds.initialize();
  await seedSuperAdmins(ds);
  await ds.destroy();
  process.exit(0);
}
main().catch(e => { console.error(e); process.exit(1); });
