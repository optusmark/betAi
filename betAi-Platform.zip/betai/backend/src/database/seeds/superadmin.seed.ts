import { DataSource } from 'typeorm';
import * as bcrypt from 'bcrypt';

/**
 * Super-admin seeder.
 * Reads credentials from environment variables (never hardcoded).
 * Passwords are hashed with bcrypt (cost factor 12) before storage.
 * Plaintext passwords NEVER touch the database or any logs.
 *
 * Run once at deployment:  npm run seed:superadmins
 */
export async function seedSuperAdmins(dataSource: DataSource): Promise<void> {
  const BCRYPT_ROUNDS = 12;

  const supers = [
    { email: process.env.SUPERADMIN_1_EMAIL, password: process.env.SUPERADMIN_1_PASSWORD },
    { email: process.env.SUPERADMIN_2_EMAIL, password: process.env.SUPERADMIN_2_PASSWORD },
  ];

  for (const s of supers) {
    if (!s.email || !s.password) {
      console.warn('[seed] Missing super-admin env vars — skipping one entry');
      continue;
    }

    // Check if already exists (idempotent — safe to run multiple times)
    const [existing] = await dataSource.query(
      `SELECT id FROM admin_accounts WHERE email = $1`, [s.email.toLowerCase()]
    );
    if (existing) {
      console.log(`[seed] Super-admin ${s.email} already exists — skipping`);
      continue;
    }

    const passwordHash = await bcrypt.hash(s.password, BCRYPT_ROUNDS);

    await dataSource.query(
      `INSERT INTO admin_accounts
         (email, password_hash, role, permissions, is_active, created_by)
       VALUES ($1, $2, 'super', '["all"]', TRUE, 'system_seed')`,
      [s.email.toLowerCase(), passwordHash]
    );
    console.log(`[seed] ✓ Super-admin created: ${s.email}`);
  }

  console.log('[seed] Super-admin seeding complete. Plaintext passwords were never stored.');
}
