-- ============================================================
-- MIGRATION 002 — Shared Wallet Deposit System
-- ============================================================

-- Drop old deposits table if exists (we replace with new model)
-- We keep the data by renaming, not dropping
ALTER TABLE IF EXISTS deposits RENAME TO deposits_legacy;

-- ============================================================
-- PLATFORM WALLET CONFIG
-- One shared address per asset/network
-- ============================================================
CREATE TABLE IF NOT EXISTS platform_wallets (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    asset_id    UUID NOT NULL REFERENCES crypto_assets(id) ON DELETE CASCADE,
    address     VARCHAR(255) NOT NULL,
    network     VARCHAR(50)  NOT NULL,
    label       VARCHAR(100),
    is_active   BOOLEAN DEFAULT TRUE,
    created_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(asset_id)  -- one wallet per asset
);

-- ============================================================
-- DEPOSIT REQUESTS (manual confirmation flow)
-- ============================================================
CREATE TYPE deposit_request_status AS ENUM (
    'pending_review',  -- submitted, waiting admin
    'approved',        -- admin approved, balance credited
    'rejected'         -- admin rejected
);

CREATE TABLE deposit_requests (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    request_number  VARCHAR(30) UNIQUE NOT NULL,  -- e.g. DEP-000001

    -- User
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,

    -- Asset
    asset_id        UUID NOT NULL REFERENCES crypto_assets(id),
    network         VARCHAR(50) NOT NULL,

    -- Deposit details (user-submitted)
    amount          DECIMAL(36,8) NOT NULL CHECK (amount > 0),

    -- Payment proof (user-uploaded file)
    proof_filename  VARCHAR(255) NOT NULL,   -- stored filename on disk
    proof_original  VARCHAR(255) NOT NULL,   -- original filename
    proof_mimetype  VARCHAR(100) NOT NULL,   -- image/jpeg, application/pdf, etc.
    proof_size      INTEGER NOT NULL,        -- bytes
    proof_url       VARCHAR(500),            -- served URL

    -- Status
    status          deposit_request_status DEFAULT 'pending_review',

    -- Admin decision
    reviewed_by     UUID REFERENCES users(id),
    reviewed_at     TIMESTAMP WITH TIME ZONE,
    rejection_reason TEXT,
    approved_at     TIMESTAMP WITH TIME ZONE,

    -- Immutability: once submitted user cannot edit
    submitted_at    TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_deposit_requests_user_id    ON deposit_requests(user_id);
CREATE INDEX idx_deposit_requests_status     ON deposit_requests(status);
CREATE INDEX idx_deposit_requests_submitted  ON deposit_requests(submitted_at DESC);
CREATE INDEX idx_deposit_requests_amount     ON deposit_requests(amount DESC);

-- Auto-generate request number
CREATE SEQUENCE deposit_request_seq START 1;

CREATE OR REPLACE FUNCTION set_deposit_request_number()
RETURNS TRIGGER AS $$
BEGIN
  NEW.request_number = 'DEP-' || LPAD(NEXTVAL('deposit_request_seq')::TEXT, 6, '0');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_deposit_request_number
  BEFORE INSERT ON deposit_requests
  FOR EACH ROW EXECUTE FUNCTION set_deposit_request_number();

-- ============================================================
-- AUDIT LOG (immutable — no UPDATE/DELETE allowed via app)
-- ============================================================
CREATE TABLE IF NOT EXISTS audit_log (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    admin_id    UUID NOT NULL REFERENCES users(id),
    admin_email VARCHAR(255),
    action      VARCHAR(100) NOT NULL,  -- 'approve_deposit', 'reject_deposit', etc.
    target_type VARCHAR(50)  NOT NULL,  -- 'deposit_request', 'withdrawal', etc.
    target_id   UUID         NOT NULL,
    user_id     UUID REFERENCES users(id),  -- affected user
    details     JSONB,
    ip_address  VARCHAR(50),
    created_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_audit_log_admin_id   ON audit_log(admin_id);
CREATE INDEX idx_audit_log_target_id  ON audit_log(target_id);
CREATE INDEX idx_audit_log_created_at ON audit_log(created_at DESC);
CREATE INDEX idx_audit_log_action     ON audit_log(action);

-- ============================================================
-- SEED — platform wallets (replace with real addresses)
-- ============================================================
INSERT INTO platform_wallets (asset_id, address, network, label)
SELECT id, 'YOUR_USDT_TRC20_ADDRESS', 'TRC20', 'USDT TRC20 Wallet'
FROM crypto_assets WHERE symbol='USDT' AND network='TRC20'
ON CONFLICT (asset_id) DO NOTHING;

INSERT INTO platform_wallets (asset_id, address, network, label)
SELECT id, 'YOUR_USDT_ERC20_ADDRESS', 'ERC20', 'USDT ERC20 Wallet'
FROM crypto_assets WHERE symbol='USDT' AND network='ERC20'
ON CONFLICT (asset_id) DO NOTHING;

INSERT INTO platform_wallets (asset_id, address, network, label)
SELECT id, 'YOUR_BTC_ADDRESS', 'BTC', 'Bitcoin Wallet'
FROM crypto_assets WHERE symbol='BTC' AND network='BTC'
ON CONFLICT (asset_id) DO NOTHING;

INSERT INTO platform_wallets (asset_id, address, network, label)
SELECT id, 'YOUR_ETH_ADDRESS', 'ERC20', 'Ethereum Wallet'
FROM crypto_assets WHERE symbol='ETH' AND network='ERC20'
ON CONFLICT (asset_id) DO NOTHING;

-- Auto-update updated_at
CREATE TRIGGER trg_deposit_requests_updated_at
  BEFORE UPDATE ON deposit_requests
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_platform_wallets_updated_at
  BEFORE UPDATE ON platform_wallets
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- ============================================================
-- WALLET AUDIT: Add index for wallet history queries
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_audit_log_wallet
  ON audit_log(target_id, action)
  WHERE target_type = 'platform_wallet';
