-- betAi Platform Database Schema v2 (Fixed)
-- PostgreSQL 15+

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- ENUM Types
-- ============================================================
CREATE TYPE user_status         AS ENUM ('active', 'suspended', 'banned');
CREATE TYPE activation_status   AS ENUM ('not_activated', 'activated');
CREATE TYPE deposit_status      AS ENUM ('pending', 'confirmed', 'failed');
CREATE TYPE withdrawal_status   AS ENUM ('pending', 'in_review', 'approved', 'rejected');
CREATE TYPE transaction_type    AS ENUM ('deposit', 'withdrawal', 'bonus');
CREATE TYPE bonus_period_status AS ENUM ('active', 'completed', 'failed');
CREATE TYPE ticket_status       AS ENUM ('open', 'in_progress', 'resolved', 'closed');
CREATE TYPE ticket_priority     AS ENUM ('low', 'medium', 'high', 'urgent');
CREATE TYPE admin_role          AS ENUM ('super_admin', 'admin', 'support');
CREATE TYPE notification_type   AS ENUM ('info', 'success', 'warning', 'error');

-- ============================================================
-- USERS
-- ============================================================
CREATE TABLE users (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email                   VARCHAR(255) UNIQUE,
    phone                   VARCHAR(50)  UNIQUE,
    password_hash           VARCHAR(255) NOT NULL,
    first_name              VARCHAR(100),
    last_name               VARCHAR(100),

    -- Referral (only link, no code shown to user)
    referral_code           VARCHAR(20)  UNIQUE NOT NULL,
    referrer_id             UUID REFERENCES users(id) ON DELETE SET NULL,

    -- Activation (replaces KYC)
    -- activated = has_deposit AND active_referrals_count >= 5
    activation_status       activation_status DEFAULT 'not_activated',
    active_referrals_count  INTEGER DEFAULT 0,
    -- Once 5 RPs reached this is set TRUE forever
    referral_condition_met  BOOLEAN DEFAULT FALSE,

    -- Auth
    status                  user_status DEFAULT 'active',
    email_verified          BOOLEAN DEFAULT FALSE,
    phone_verified          BOOLEAN DEFAULT FALSE,
    two_fa_enabled          BOOLEAN DEFAULT FALSE,
    two_fa_secret           VARCHAR(255),
    is_admin                BOOLEAN DEFAULT FALSE,
    admin_role              admin_role,
    last_login_at           TIMESTAMP WITH TIME ZONE,
    last_login_ip           VARCHAR(50),

    -- Soft delete
    deleted_at              TIMESTAMP WITH TIME ZONE,

    created_at              TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at              TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    CONSTRAINT email_or_phone CHECK (email IS NOT NULL OR phone IS NOT NULL)
);

CREATE INDEX idx_users_email         ON users(email)         WHERE deleted_at IS NULL;
CREATE INDEX idx_users_phone         ON users(phone)         WHERE deleted_at IS NULL;
CREATE INDEX idx_users_referral_code ON users(referral_code) WHERE deleted_at IS NULL;
CREATE INDEX idx_users_referrer_id   ON users(referrer_id);

-- ============================================================
-- REFRESH TOKENS  (for proper logout revocation)
-- ============================================================
CREATE TABLE refresh_tokens (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash  VARCHAR(255) NOT NULL UNIQUE,
    expires_at  TIMESTAMP WITH TIME ZONE NOT NULL,
    revoked_at  TIMESTAMP WITH TIME ZONE,
    ip_address  VARCHAR(50),
    user_agent  TEXT,
    created_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_refresh_tokens_user_id    ON refresh_tokens(user_id);
CREATE INDEX idx_refresh_tokens_token_hash ON refresh_tokens(token_hash);

-- ============================================================
-- PASSWORD RESET TOKENS
-- ============================================================
CREATE TABLE password_reset_tokens (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token       VARCHAR(255) NOT NULL UNIQUE,
    expires_at  TIMESTAMP WITH TIME ZONE NOT NULL,
    used_at     TIMESTAMP WITH TIME ZONE,
    created_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================================
-- EMAIL VERIFICATION TOKENS
-- ============================================================
CREATE TABLE email_verification_tokens (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token       VARCHAR(255) NOT NULL UNIQUE,
    expires_at  TIMESTAMP WITH TIME ZONE NOT NULL,
    used_at     TIMESTAMP WITH TIME ZONE,
    created_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================================
-- CRYPTO ASSETS
-- ============================================================
CREATE TABLE crypto_assets (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    symbol           VARCHAR(20)  NOT NULL,
    name             VARCHAR(100) NOT NULL,
    network          VARCHAR(50)  NOT NULL,
    contract_address VARCHAR(255),
    decimals         INTEGER DEFAULT 18,
    min_deposit      DECIMAL(36,8) DEFAULT 100,
    min_withdrawal   DECIMAL(36,8) DEFAULT 100,
    deposit_address  VARCHAR(255),
    is_active        BOOLEAN DEFAULT TRUE,
    logo_url         VARCHAR(500),
    created_at       TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at       TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(symbol, network)   -- USDT can exist on TRC20 and ERC20
);

-- ============================================================
-- BALANCES
-- Key fix: deposit_base is SEPARATE from available/bonus
-- 2% is always calculated from deposit_base only
-- ============================================================
CREATE TABLE balances (
    id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id           UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    asset_id          UUID NOT NULL REFERENCES crypto_assets(id),

    -- Deposit base: sum of all confirmed deposits ONLY
    -- This is the base for 2% daily bonus calculation
    -- Never decreases when bonus is credited
    deposit_base      DECIMAL(36,8) DEFAULT 0,

    -- Available = deposit_base + bonus_balance - locked
    -- This is what user can actually use
    available_balance DECIMAL(36,8) DEFAULT 0,

    -- Locked during pending withdrawal
    locked_balance    DECIMAL(36,8) DEFAULT 0,

    -- Bonus accumulated from daily 2% cron
    bonus_balance     DECIMAL(36,8) DEFAULT 0,

    -- Stats
    total_deposited   DECIMAL(36,8) DEFAULT 0,
    total_withdrawn   DECIMAL(36,8) DEFAULT 0,
    total_bonus_paid  DECIMAL(36,8) DEFAULT 0,

    created_at        TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at        TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, asset_id)
);

CREATE INDEX idx_balances_user_id ON balances(user_id);

-- ============================================================
-- DEPOSITS
-- ============================================================
CREATE TABLE deposits (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id          UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    asset_id         UUID NOT NULL REFERENCES crypto_assets(id),
    amount           DECIMAL(36,8) NOT NULL,
    tx_hash          VARCHAR(255) UNIQUE,   -- UNIQUE prevents double processing
    from_address     VARCHAR(255),
    to_address       VARCHAR(255),
    network          VARCHAR(50),
    status           deposit_status DEFAULT 'pending',
    confirmed_at     TIMESTAMP WITH TIME ZONE,
    is_first_deposit BOOLEAN DEFAULT FALSE,
    created_at       TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at       TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_deposits_user_id  ON deposits(user_id);
CREATE INDEX idx_deposits_status   ON deposits(status);
CREATE INDEX idx_deposits_tx_hash  ON deposits(tx_hash);

-- ============================================================
-- WITHDRAWALS
-- Key fix: stores withdrawal_type so admin knows what is allowed
-- ============================================================
CREATE TABLE withdrawals (
    id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id          UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    asset_id         UUID NOT NULL REFERENCES crypto_assets(id),
    amount           DECIMAL(36,8) NOT NULL,
    fee              DECIMAL(36,8) DEFAULT 0,
    net_amount       DECIMAL(36,8),
    to_address       VARCHAR(255) NOT NULL,
    network          VARCHAR(50),
    tx_hash          VARCHAR(255),
    status           withdrawal_status DEFAULT 'pending',
    rejection_reason TEXT,

    -- What type of withdrawal: full (deposit+bonus) or deposit_only
    withdrawal_type  VARCHAR(20) NOT NULL DEFAULT 'deposit_only',
    -- Snapshot at time of request
    deposit_base_snapshot  DECIMAL(36,8),
    bonus_snapshot         DECIMAL(36,8),
    -- Was referral condition met at time of request?
    referral_condition_snapshot BOOLEAN DEFAULT FALSE,

    processed_by     UUID REFERENCES users(id),
    processed_at     TIMESTAMP WITH TIME ZONE,
    created_at       TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at       TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_withdrawals_user_id ON withdrawals(user_id);
CREATE INDEX idx_withdrawals_status  ON withdrawals(status);

-- ============================================================
-- TRANSACTIONS (immutable ledger)
-- ============================================================
CREATE TABLE transactions (
    id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id        UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    asset_id       UUID NOT NULL REFERENCES crypto_assets(id),
    type           transaction_type NOT NULL,
    amount         DECIMAL(36,8) NOT NULL,
    balance_before DECIMAL(36,8),
    balance_after  DECIMAL(36,8),
    reference_id   UUID,
    description    TEXT,
    metadata       JSONB,
    created_at     TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_transactions_user_id    ON transactions(user_id);
CREATE INDEX idx_transactions_type       ON transactions(type);
CREATE INDEX idx_transactions_created_at ON transactions(created_at DESC);

-- ============================================================
-- REFERRALS
-- Key: is_qualified = registered via link AND made deposit
-- ============================================================
CREATE TABLE referrals (
    id                   UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    referrer_id          UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    referred_id          UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    registered_at        TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    first_deposit_at     TIMESTAMP WITH TIME ZONE,
    first_deposit_amount DECIMAL(36,8),
    -- Active = registered via link + made deposit
    is_qualified         BOOLEAN DEFAULT FALSE,
    created_at           TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(referrer_id, referred_id),
    UNIQUE(referred_id)  -- one referrer per user
);

CREATE INDEX idx_referrals_referrer_id ON referrals(referrer_id);
CREATE INDEX idx_referrals_referred_id ON referrals(referred_id);
CREATE INDEX idx_referrals_qualified   ON referrals(referrer_id, is_qualified);

-- ============================================================
-- BONUS PERIODS
-- Key fixes:
--   - daily_bonus_paid_date prevents double cron execution
--   - referral_condition_met mirrors user-level flag
--   - deposit_base_at_start snapshot for reference
-- ============================================================
CREATE TABLE bonus_periods (
    id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id               UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    period_number         INTEGER NOT NULL DEFAULT 1,
    start_date            TIMESTAMP WITH TIME ZONE NOT NULL,
    end_date              TIMESTAMP WITH TIME ZONE NOT NULL,
    status                bonus_period_status DEFAULT 'active',

    -- Referral gate
    referral_condition_met BOOLEAN DEFAULT FALSE,

    -- Daily bonus tracking
    -- Stores DATE of last bonus payment to prevent double-crediting
    last_daily_bonus_date  DATE,
    total_bonus_paid       DECIMAL(36,8) DEFAULT 0,

    -- Snapshot of deposit base when period started
    deposit_base_at_start  DECIMAL(36,8) DEFAULT 0,

    -- End-of-period summary
    bonus_percentage       DECIMAL(5,4) DEFAULT 0.02,
    paid_at                TIMESTAMP WITH TIME ZONE,

    created_at             TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at             TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    -- One active period per user at a time
    UNIQUE(user_id, period_number)
);

CREATE INDEX idx_bonus_periods_user_id  ON bonus_periods(user_id);
CREATE INDEX idx_bonus_periods_status   ON bonus_periods(status);
-- Composite index for cron query: active periods not yet processed today
CREATE INDEX idx_bonus_periods_cron     ON bonus_periods(status, last_daily_bonus_date)
    WHERE status = 'active';

-- ============================================================
-- BONUS HISTORY (daily records)
-- ============================================================
CREATE TABLE bonus_history (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    period_id       UUID REFERENCES bonus_periods(id),
    amount          DECIMAL(36,8) NOT NULL,
    deposit_base    DECIMAL(36,8) NOT NULL,   -- base used for calculation
    percentage      DECIMAL(5,4) DEFAULT 0.02,
    bonus_date      DATE NOT NULL,            -- which calendar day this bonus is for
    description     TEXT,
    created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    -- Prevent duplicate bonus for same day
    UNIQUE(user_id, bonus_date)
);

CREATE INDEX idx_bonus_history_user_id ON bonus_history(user_id);
CREATE INDEX idx_bonus_history_date    ON bonus_history(bonus_date);

-- ============================================================
-- SUPPORT TICKETS
-- ============================================================
CREATE TABLE support_tickets (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ticket_number VARCHAR(20) UNIQUE NOT NULL,
    user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    subject       VARCHAR(255) NOT NULL,
    status        ticket_status DEFAULT 'open',
    priority      ticket_priority DEFAULT 'medium',
    assigned_to   UUID REFERENCES users(id),
    closed_at     TIMESTAMP WITH TIME ZONE,
    created_at    TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at    TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_tickets_user_id ON support_tickets(user_id);
CREATE INDEX idx_tickets_status  ON support_tickets(status);

CREATE TABLE ticket_messages (
    id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ticket_id      UUID NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,
    sender_id      UUID NOT NULL REFERENCES users(id),
    message        TEXT NOT NULL,
    is_admin_reply BOOLEAN DEFAULT FALSE,
    attachments    JSONB,
    created_at     TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_ticket_messages_ticket_id ON ticket_messages(ticket_id);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================
CREATE TABLE notifications (
    id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id    UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    type       notification_type DEFAULT 'info',
    title      VARCHAR(255) NOT NULL,
    message    TEXT NOT NULL,
    is_read    BOOLEAN DEFAULT FALSE,
    metadata   JSONB,
    read_at    TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_unread  ON notifications(user_id, is_read) WHERE is_read = FALSE;

-- ============================================================
-- ADMIN LOGS (immutable audit trail)
-- ============================================================
CREATE TABLE admin_logs (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    admin_id    UUID NOT NULL REFERENCES users(id),
    action      VARCHAR(100) NOT NULL,
    target_type VARCHAR(50),
    target_id   UUID,
    details     JSONB,
    ip_address  VARCHAR(50),
    created_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_admin_logs_admin_id   ON admin_logs(admin_id);
CREATE INDEX idx_admin_logs_created_at ON admin_logs(created_at DESC);

-- ============================================================
-- USER SETTINGS
-- ============================================================
CREATE TABLE user_settings (
    id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id               UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE UNIQUE,
    notifications_email   BOOLEAN DEFAULT TRUE,
    notifications_push    BOOLEAN DEFAULT TRUE,
    language              VARCHAR(10) DEFAULT 'en',
    timezone              VARCHAR(50) DEFAULT 'UTC',
    created_at            TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at            TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- ============================================================
-- FUNCTIONS & TRIGGERS
-- ============================================================

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_users_updated_at         BEFORE UPDATE ON users         FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_balances_updated_at      BEFORE UPDATE ON balances      FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_deposits_updated_at      BEFORE UPDATE ON deposits      FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_withdrawals_updated_at   BEFORE UPDATE ON withdrawals   FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_bonus_periods_updated_at BEFORE UPDATE ON bonus_periods FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER trg_tickets_updated_at       BEFORE UPDATE ON support_tickets FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Auto ticket number
CREATE SEQUENCE ticket_seq START 1000;
CREATE OR REPLACE FUNCTION set_ticket_number()
RETURNS TRIGGER AS $$
BEGIN NEW.ticket_number = 'TKT-' || LPAD(NEXTVAL('ticket_seq')::TEXT, 6, '0'); RETURN NEW; END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER trg_ticket_number BEFORE INSERT ON support_tickets FOR EACH ROW EXECUTE FUNCTION set_ticket_number();

-- Auto-update user activation_status when active_referrals_count or has_deposit changes
-- We use a function called explicitly from application code (safer than trigger for this logic)

-- ============================================================
-- SEED DATA
-- ============================================================

-- Crypto assets (symbol+network unique)
INSERT INTO crypto_assets (symbol, name, network, min_deposit, min_withdrawal, deposit_address, decimals) VALUES
('USDT', 'Tether USD',  'TRC20', 100, 100, 'YOUR_USDT_TRC20_DEPOSIT_ADDRESS', 6),
('USDT', 'Tether USD',  'ERC20', 100, 100, 'YOUR_USDT_ERC20_DEPOSIT_ADDRESS', 6),
('USDC', 'USD Coin',    'ERC20', 100, 100, 'YOUR_USDC_ERC20_DEPOSIT_ADDRESS', 6),
('BTC',  'Bitcoin',     'BTC',   0.001, 0.001, 'YOUR_BTC_DEPOSIT_ADDRESS', 8),
('ETH',  'Ethereum',    'ERC20', 0.05, 0.05,   'YOUR_ETH_DEPOSIT_ADDRESS', 18);

-- Admin user  (password: Admin@123456 — CHANGE IN PRODUCTION)
INSERT INTO users (
    email, password_hash, first_name, last_name,
    referral_code, status, email_verified,
    is_admin, admin_role, activation_status
) VALUES (
    'admin@betai.com',
    '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4oEpBsQlHy',
    'Super', 'Admin',
    'betAiADMIN1',
    'active', TRUE,
    TRUE, 'super_admin', 'activated'
);
