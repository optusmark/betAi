-- MIGRATION 004 — Admin accounts, roles & permissions
CREATE TYPE admin_role AS ENUM ('super', 'admin');

CREATE TABLE admin_accounts (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email         VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role          admin_role NOT NULL DEFAULT 'admin',
  permissions   JSONB NOT NULL DEFAULT '[]',
  is_active     BOOLEAN NOT NULL DEFAULT TRUE,
  created_by    VARCHAR(255),
  failed_attempts INTEGER NOT NULL DEFAULT 0,
  locked_until    TIMESTAMP WITH TIME ZONE,
  last_login_at   TIMESTAMP WITH TIME ZONE,
  last_login_ip   VARCHAR(64),
  created_at    TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at    TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
CREATE INDEX idx_admin_email ON admin_accounts(email);

CREATE TABLE test_accounts (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email         VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  balance       DECIMAL(36,8) NOT NULL DEFAULT 0,
  note          VARCHAR(255),
  created_by    UUID REFERENCES admin_accounts(id),
  created_at    TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE about_content (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  is_enabled  BOOLEAN NOT NULL DEFAULT TRUE,
  blocks      JSONB NOT NULL DEFAULT '[]',
  updated_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
INSERT INTO about_content (is_enabled, blocks) VALUES (TRUE, '[]');
