-- ============================================================
-- MIGRATION 003 — Investment Packages + Sports Page
-- ============================================================

-- ── INVESTMENT PACKAGES CONFIG (admin-managed) ──────────────
CREATE TABLE investment_packages (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name        VARCHAR(50) NOT NULL UNIQUE,   -- 'silver','gold','platinum'
  label       VARCHAR(50) NOT NULL,          -- 'Silver','Gold','Platinum'
  price       DECIMAL(10,2) NOT NULL,        -- 500, 1000, 2000
  daily_pct   DECIMAL(5,2) NOT NULL DEFAULT 2.00,  -- daily % (e.g. 2.00)
  cycle_days  INTEGER NOT NULL DEFAULT 40,
  is_active   BOOLEAN NOT NULL DEFAULT TRUE,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

INSERT INTO investment_packages (name, label, price, daily_pct, cycle_days, sort_order) VALUES
  ('silver',   'Silver',   500.00,  2.00, 40, 1),
  ('gold',     'Gold',     1000.00, 2.00, 40, 2),
  ('platinum', 'Platinum', 2000.00, 2.00, 40, 3);

-- ── USER ACTIVE PACKAGE ──────────────────────────────────────
CREATE TYPE package_status AS ENUM (
  'active',     -- running, bonuses accruing
  'completed',  -- 40 days done
  'withdrawn'   -- funds withdrawn
);

CREATE TABLE user_packages (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  package_id      UUID NOT NULL REFERENCES investment_packages(id),
  package_name    VARCHAR(50) NOT NULL,  -- snapshot at activation
  package_price   DECIMAL(10,2) NOT NULL,-- snapshot of price at activation
  daily_pct       DECIMAL(5,2) NOT NULL, -- snapshot of % at activation

  -- Deposited amounts (real money only, no bonuses)
  total_deposited DECIMAL(36,8) NOT NULL DEFAULT 0,
  -- Bonuses earned during this cycle
  bonus_earned    DECIMAL(36,8) NOT NULL DEFAULT 0,
  -- Bonuses used for upgrade (tracked separately)
  bonus_used_for_upgrade DECIMAL(36,8) NOT NULL DEFAULT 0,

  status          package_status NOT NULL DEFAULT 'active',
  activated_at    TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  cycle_start_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  cycle_ends_at   TIMESTAMP WITH TIME ZONE, -- activated_at + 40 days
  completed_at    TIMESTAMP WITH TIME ZONE,
  last_bonus_date DATE,  -- prevents double daily bonus

  -- Upgrade tracking
  upgraded_from   UUID REFERENCES investment_packages(id),
  upgraded_at     TIMESTAMP WITH TIME ZONE,
  upgrade_count   INTEGER DEFAULT 0,

  created_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at      TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

  -- Only one active package per user at a time
  CONSTRAINT one_active_per_user UNIQUE (user_id, status) 
    DEFERRABLE INITIALLY DEFERRED
);

-- Remove the unique constraint approach and use partial index instead
ALTER TABLE user_packages DROP CONSTRAINT IF EXISTS one_active_per_user;
CREATE UNIQUE INDEX idx_one_active_package 
  ON user_packages(user_id) 
  WHERE status = 'active';

CREATE INDEX idx_user_packages_user     ON user_packages(user_id);
CREATE INDEX idx_user_packages_status   ON user_packages(status);
CREATE INDEX idx_user_packages_cycle    ON user_packages(cycle_ends_at);

-- ── MIN DEPOSIT CONFIG ───────────────────────────────────────
-- Update crypto_assets min_deposit to 100
UPDATE crypto_assets SET min_deposit = 100 WHERE symbol = 'USDT' AND network = 'TRC20';

-- Ensure only TRC20 is active
UPDATE crypto_assets SET is_active = FALSE 
WHERE NOT (symbol = 'USDT' AND network = 'TRC20');

-- ── SPORTS PAGE CONFIG (admin-managed) ──────────────────────
CREATE TABLE sports_config (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  is_enabled    BOOLEAN NOT NULL DEFAULT TRUE,
  max_events    INTEGER NOT NULL DEFAULT 5,
  sports        JSONB NOT NULL DEFAULT '["football","basketball","tennis","mma"]',
  pinned_events JSONB NOT NULL DEFAULT '[]',  -- manually pinned fixture IDs
  api_key       VARCHAR(255),
  cache_seconds INTEGER NOT NULL DEFAULT 60,
  updated_at    TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

INSERT INTO sports_config (is_enabled, max_events, api_key, cache_seconds)
VALUES (TRUE, 5, '568c7020aa780ff0a3df3b3614078d0f', 60);

-- ── SPORTS CACHE TABLE ───────────────────────────────────────
CREATE TABLE sports_cache (
  cache_key   VARCHAR(200) PRIMARY KEY,
  data        JSONB NOT NULL,
  expires_at  TIMESTAMP WITH TIME ZONE NOT NULL,
  created_at  TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_sports_cache_expires ON sports_cache(expires_at);

-- ── PACKAGE AUDIT LOG ────────────────────────────────────────
-- Reuse existing audit_log table, add new action types:
-- 'activate_package', 'upgrade_package', 'daily_bonus', 'package_completed'
-- 'update_package_config' (admin changes price/pct)

-- ── TRIGGERS ─────────────────────────────────────────────────
CREATE TRIGGER trg_user_packages_updated_at
  BEFORE UPDATE ON user_packages
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_investment_packages_updated_at  
  BEFORE UPDATE ON investment_packages
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
