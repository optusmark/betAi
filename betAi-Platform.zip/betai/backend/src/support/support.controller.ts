import { Controller, Get, Post, Body, Param, UseGuards, Request } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { SupportService } from './support.service';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('Support')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard)
@Controller('support')
export class SupportController {
  constructor(private readonly supportService: SupportService) {}

  @Post('tickets')
  async create(@Request() req, @Body() body: { subject: string; message: string }) {
    return this.supportService.createTicket(req.user.id, body);
  }

  @Get('tickets')
  async list(@Request() req) {
    return this.supportService.getUserTickets(req.user.id);
  }

  @Get('tickets/:id')
  async getMessages(@Request() req, @Param('id') id: string) {
    return this.supportService.getTicketMessages(req.user.id, id);
  }

  @Post('tickets/:id/reply')
  async reply(@Request() req, @Param('id') id: string, @Body('message') message: string) {
    return this.supportService.replyToTicket(req.user.id, id, message);
  }

  @Post('tickets/:id/close')
  async close(@Request() req, @Param('id') id: string) {
    return this.supportService.closeTicket(req.user.id, id);
  }
}
