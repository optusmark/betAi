import { Injectable } from '@nestjs/common';
import { DataSource } from 'typeorm';

@Injectable()
export class SupportService {
  constructor(private readonly dataSource: DataSource) {}

  async createTicket(userId: string, data: { subject: string; message: string }): Promise<any> {
    const [ticket] = await this.dataSource.query(
      `INSERT INTO support_tickets (user_id, subject) VALUES ($1, $2) RETURNING *`,
      [userId, data.subject]
    );

    await this.dataSource.query(
      `INSERT INTO ticket_messages (ticket_id, sender_id, message, is_admin_reply)
       VALUES ($1, $2, $3, FALSE)`,
      [ticket.id, userId, data.message]
    );

    return ticket;
  }

  async getUserTickets(userId: string): Promise<any[]> {
    return this.dataSource.query(
      `SELECT st.*,
         (SELECT message FROM ticket_messages WHERE ticket_id = st.id ORDER BY created_at DESC LIMIT 1) as last_message,
         (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id = st.id) as message_count
       FROM support_tickets st WHERE st.user_id = $1 ORDER BY st.updated_at DESC`,
      [userId]
    );
  }

  async getTicketMessages(userId: string, ticketId: string): Promise<any> {
    const [ticket] = await this.dataSource.query(
      `SELECT * FROM support_tickets WHERE id = $1 AND user_id = $2`,
      [ticketId, userId]
    );
    if (!ticket) return null;

    const messages = await this.dataSource.query(
      `SELECT tm.*, u.email, u.first_name, u.last_name
       FROM ticket_messages tm JOIN users u ON tm.sender_id = u.id
       WHERE tm.ticket_id = $1 ORDER BY tm.created_at ASC`,
      [ticketId]
    );

    return { ticket, messages };
  }

  async replyToTicket(userId: string, ticketId: string, message: string, isAdmin = false): Promise<any> {
    const [msg] = await this.dataSource.query(
      `INSERT INTO ticket_messages (ticket_id, sender_id, message, is_admin_reply)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [ticketId, userId, message, isAdmin]
    );

    await this.dataSource.query(
      `UPDATE support_tickets SET updated_at = NOW(), status = CASE WHEN $1 THEN 'in_progress' ELSE status END
       WHERE id = $2`,
      [isAdmin, ticketId]
    );

    return msg;
  }

  async closeTicket(userId: string, ticketId: string): Promise<any> {
    await this.dataSource.query(
      `UPDATE support_tickets SET status = 'closed', closed_at = NOW() WHERE id = $1 AND user_id = $2`,
      [ticketId, userId]
    );
    return { message: 'Ticket closed' };
  }
}
