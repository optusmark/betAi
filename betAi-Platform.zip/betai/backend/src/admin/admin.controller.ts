import {
  Controller, Get, Post, Patch, Body, Param, Query,
  UseGuards, Request
} from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { AdminGuard } from '../auth/guards/jwt-auth.guard';
import { AdminService } from './admin.service';

@ApiTags('Admin')
@ApiBearerAuth()
@UseGuards(AdminGuard)
@Controller('admin')
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  @Get('dashboard')
  async getDashboard() {
    return this.adminService.getDashboardStats();
  }

  @Get('users')
  async getUsers(@Query('page') page = 1, @Query('limit') limit = 20, @Query('search') search?: string) {
    return this.adminService.getUsers(+page, +limit, search);
  }

  @Get('users/:id')
  async getUser(@Param('id') id: string) {
    return this.adminService.getUserDetail(id);
  }

  @Patch('users/:id/status')
  async updateUserStatus(@Request() req, @Param('id') id: string, @Body('status') status: string) {
    return this.adminService.updateUserStatus(req.user.id, id, status);
  }

  @Patch('users/:id/balance')
  async adjustBalance(@Request() req, @Param('id') id: string, @Body() body: any) {
    return this.adminService.adjustUserBalance(req.user.id, id, body);
  }

  @Get('kyc')
  async getKycList(@Query('status') status?: string) {
    return this.adminService.getKycList(status);
  }

  @Post('kyc/:id/approve')
  async approveKyc(@Request() req, @Param('id') id: string) {
    return this.adminService.processKyc(req.user.id, id, 'approve');
  }

  @Post('kyc/:id/reject')
  async rejectKyc(@Request() req, @Param('id') id: string, @Body('reason') reason: string) {
    return this.adminService.processKyc(req.user.id, id, 'reject', reason);
  }

  @Get('deposits')
  async getDeposits(@Query('page') page = 1, @Query('limit') limit = 20) {
    return this.adminService.getDeposits(+page, +limit);
  }

  @Get('withdrawals')
  async getWithdrawals(@Query('status') status?: string) {
    return this.adminService.getWithdrawals(status);
  }

  @Post('withdrawals/:id/approve')
  async approveWithdrawal(@Request() req, @Param('id') id: string, @Body('txHash') txHash: string) {
    return this.adminService.processWithdrawal(req.user.id, id, 'approve', txHash);
  }

  @Post('withdrawals/:id/reject')
  async rejectWithdrawal(@Request() req, @Param('id') id: string, @Body('reason') reason: string) {
    return this.adminService.processWithdrawal(req.user.id, id, 'reject', undefined, reason);
  }

  @Get('referrals')
  async getReferrals() {
    return this.adminService.getReferrals();
  }

  @Get('bonuses')
  async getBonuses() {
    return this.adminService.getBonusHistory();
  }

  @Get('tickets')
  async getTickets(@Query('status') status?: string) {
    return this.adminService.getTickets(status);
  }

  @Get('transactions')
  async getTransactions(@Query('page') page = 1, @Query('limit') limit = 50) {
    return this.adminService.getTransactions(+page, +limit);
  }

  @Get('logs')
  async getLogs(@Query('page') page = 1, @Query('limit') limit = 50) {
    return this.adminService.getAdminLogs(+page, +limit);
  }

  @Get('assets')
  async getAssets() {
    return this.adminService.getCryptoAssets();
  }

  @Post('assets')
  async createAsset(@Request() req, @Body() body: any) {
    return this.adminService.createCryptoAsset(req.user.id, body);
  }

  @Patch('assets/:id')
  async updateAsset(@Request() req, @Param('id') id: string, @Body() body: any) {
    return this.adminService.updateCryptoAsset(req.user.id, id, body);
  }
}
