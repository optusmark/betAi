import { Controller, Get, Post, Patch, Body, Param, ParseUUIDPipe, Request, UseGuards } from '@nestjs/common';
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger';
import { PackagesService } from './packages.service';
import { JwtAuthGuard, AdminGuard } from '../auth/guards/jwt-auth.guard';

@ApiTags('Packages')
@ApiBearerAuth()
@Controller('packages')
export class PackagesController {
  constructor(private readonly svc: PackagesService) {}

  @Get() @UseGuards(JwtAuthGuard)
  getAll() { return this.svc.getAll(); }

  @Get('my') @UseGuards(JwtAuthGuard)
  getMy(@Request() req) { return this.svc.getUserActivePackage(req.user.id); }

  @Post('activate') @UseGuards(JwtAuthGuard)
  activate(@Request() req, @Body('packageId') packageId: string) {
    return this.svc.activatePackage(req.user.id, packageId);
  }

  @Post('upgrade') @UseGuards(JwtAuthGuard)
  upgrade(@Request() req, @Body('packageId') packageId: string) {
    return this.svc.upgradePackage(req.user.id, packageId);
  }

  // Admin
  @Get('admin/all') @UseGuards(AdminGuard)
  adminGetAll() { return this.svc.getAllAdmin(); }

  @Patch('admin/:id') @UseGuards(AdminGuard)
  adminUpdate(
    @Request() req,
    @Param('id', ParseUUIDPipe) id: string,
    @Body() body: { price?: number; dailyPct?: number; isActive?: boolean; label?: string; cycleDays?: number }
  ) { return this.svc.adminUpdatePackage(req.user.id, id, body); }
}
