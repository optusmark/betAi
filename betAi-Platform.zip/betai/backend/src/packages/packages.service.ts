import { Injectable, BadRequestException, NotFoundException, Logger } from '@nestjs/common';
import { DataSource } from 'typeorm';

@Injectable()
export class PackagesService {
  private readonly logger = new Logger(PackagesService.name);
  constructor(private readonly dataSource: DataSource) {}

  async getAll(): Promise<any[]> {
    return this.dataSource.query(`SELECT * FROM investment_packages WHERE is_active=TRUE ORDER BY sort_order`);
  }

  async getAllAdmin(): Promise<any[]> {
    return this.dataSource.query(`SELECT * FROM investment_packages ORDER BY sort_order`);
  }

  async getUserActivePackage(userId: string): Promise<any> {
    const [pkg] = await this.dataSource.query(
      `SELECT up.*, ip.label, ip.name AS slug,
              GREATEST(0, EXTRACT(DAY FROM NOW()-up.cycle_start_at)::INTEGER) AS days_elapsed,
              GREATEST(0, ip.cycle_days - EXTRACT(DAY FROM NOW()-up.cycle_start_at)::INTEGER) AS days_remaining,
              ip.cycle_days
       FROM user_packages up JOIN investment_packages ip ON up.package_id=ip.id
       WHERE up.user_id=$1 AND up.status='active'`, [userId]);
    return pkg||null;
  }

  async activatePackage(userId: string, packageId: string): Promise<any> {
    const qr = this.dataSource.createQueryRunner();
    await qr.connect(); await qr.startTransaction();
    try {
      const [ex] = await qr.query(
        `SELECT id FROM user_packages WHERE user_id=$1 AND status='active'`, [userId]);
      if (ex) throw new BadRequestException('Already have an active package');

      const [pkg] = await qr.query(
        `SELECT * FROM investment_packages WHERE id=$1 AND is_active=TRUE`, [packageId]);
      if (!pkg) throw new NotFoundException('Package not found');

      const [bal] = await qr.query(
        `SELECT COALESCE(available_balance,0) AS av FROM balances WHERE user_id=$1`, [userId]);
      const av = parseFloat(bal?.av||'0');
      if (av < parseFloat(pkg.price))
        throw new BadRequestException(`Need $${pkg.price}, have $${av.toFixed(2)}`);

      await qr.query(
        `UPDATE balances SET available_balance=available_balance-$1, updated_at=NOW() WHERE user_id=$2`,
        [pkg.price, userId]);

      const ends = new Date(); ends.setDate(ends.getDate()+parseInt(pkg.cycle_days));
      const [up] = await qr.query(
        `INSERT INTO user_packages(user_id,package_id,package_name,package_price,daily_pct,total_deposited,status,cycle_ends_at)
         VALUES($1,$2,$3,$4,$5,$4,'active',$6) RETURNING *`,
        [userId, packageId, pkg.label, pkg.price, pkg.daily_pct, ends]);

      await qr.query(
        `INSERT INTO audit_log(admin_id,action,target_type,target_id,user_id,details)
         VALUES($1,'activate_package','user_package',$2,$1,$3)`,
        [userId, up.id, JSON.stringify({package:pkg.label,price:pkg.price})]);

      await qr.commitTransaction();
      return { message:`${pkg.label} package activated!`, package:up };
    } catch(e){ await qr.rollbackTransaction(); throw e; }
    finally { await qr.release(); }
  }

  async upgradePackage(userId: string, newPackageId: string): Promise<any> {
    const qr = this.dataSource.createQueryRunner();
    await qr.connect(); await qr.startTransaction();
    try {
      const [cur] = await qr.query(
        `SELECT up.*, ip.price AS cur_price, ip.sort_order AS cur_order,
                GREATEST(0,EXTRACT(DAY FROM NOW()-up.cycle_start_at)::INTEGER) AS days_elapsed
         FROM user_packages up JOIN investment_packages ip ON up.package_id=ip.id
         WHERE up.user_id=$1 AND up.status='active' FOR UPDATE`, [userId]);
      if (!cur) throw new BadRequestException('No active package');
      if (parseInt(cur.days_elapsed)>10)
        throw new BadRequestException('Upgrade only allowed in first 10 days');

      const [newPkg] = await qr.query(
        `SELECT * FROM investment_packages WHERE id=$1 AND is_active=TRUE`, [newPackageId]);
      if (!newPkg) throw new NotFoundException('Package not found');
      if (parseFloat(newPkg.price)<=parseFloat(cur.cur_price))
        throw new BadRequestException('Can only upgrade to a higher tier');

      const [bal] = await qr.query(
        `SELECT COALESCE(available_balance,0) AS av, COALESCE(bonus_balance,0) AS bn
         FROM balances WHERE user_id=$1`, [userId]);
      const av=parseFloat(bal?.av||'0'), bn=parseFloat(bal?.bn||'0');
      const needed=parseFloat(newPkg.price)-parseFloat(cur.package_price);
      if (av+bn < needed)
        throw new BadRequestException(`Need $${needed.toFixed(2)} more. Have $${(av+bn).toFixed(2)}`);

      let bonusUsed=0, cashUsed=needed;
      if (av>=needed) {
        await qr.query(`UPDATE balances SET available_balance=available_balance-$1,updated_at=NOW() WHERE user_id=$2`,[needed,userId]);
      } else {
        cashUsed=av; bonusUsed=needed-av;
        await qr.query(`UPDATE balances SET available_balance=0,bonus_balance=bonus_balance-$1,updated_at=NOW() WHERE user_id=$2`,[bonusUsed,userId]);
      }

      await qr.query(
        `UPDATE user_packages SET package_id=$1,package_name=$2,package_price=$3,daily_pct=$4,
           upgraded_from=package_id,upgraded_at=NOW(),upgrade_count=upgrade_count+1,
           total_deposited=total_deposited+$5,bonus_used_for_upgrade=bonus_used_for_upgrade+$6,
           updated_at=NOW()
         WHERE user_id=$7 AND status='active'`,
        [newPackageId,newPkg.label,newPkg.price,newPkg.daily_pct,cashUsed,bonusUsed,userId]);

      await qr.commitTransaction();
      return { message:`Upgraded to ${newPkg.label}!`, bonusUsed };
    } catch(e){ await qr.rollbackTransaction(); throw e; }
    finally { await qr.release(); }
  }

  async processDailyBonuses(): Promise<void> {
    const today=new Date().toISOString().split('T')[0];
    const active=await this.dataSource.query(
      `SELECT * FROM user_packages WHERE status='active' AND cycle_ends_at>NOW()
       AND (last_bonus_date IS NULL OR last_bonus_date<$1) FOR UPDATE SKIP LOCKED`,[today]);
    for (const p of active) {
      const bonus=+(parseFloat(p.package_price)*parseFloat(p.daily_pct)/100).toFixed(2);
      await this.dataSource.query(
        `UPDATE user_packages SET bonus_earned=bonus_earned+$1,last_bonus_date=$2,updated_at=NOW() WHERE id=$3`,
        [bonus,today,p.id]);
      await this.dataSource.query(
        `INSERT INTO balances(user_id,asset_id,bonus_balance)
         SELECT $1,id,$2 FROM crypto_assets WHERE symbol='USDT' AND network='TRC20' LIMIT 1
         ON CONFLICT(user_id,asset_id) DO UPDATE
           SET bonus_balance=balances.bonus_balance+$2,updated_at=NOW()`,[p.user_id,bonus]);
      if (new Date()>=new Date(p.cycle_ends_at)) await this.completeCycle(p.id,p.user_id);
    }
  }

  async completeCycle(pkgId: string, userId: string): Promise<void> {
    await this.dataSource.query(
      `UPDATE user_packages SET status='completed',completed_at=NOW(),updated_at=NOW() WHERE id=$1`,[pkgId]);
    const [u]=await this.dataSource.query(
      `SELECT active_referrals_count,referral_condition_met FROM users WHERE id=$1`,[userId]);
    if (!u?.referral_condition_met || parseInt(u.active_referrals_count)<5) {
      await this.dataSource.query(
        `UPDATE balances SET bonus_balance=0,updated_at=NOW() WHERE user_id=$1`,[userId]);
    }
  }

  async adminUpdatePackage(adminId: string, pkgId: string, data: {
    price?: number; dailyPct?: number; isActive?: boolean; label?: string; cycleDays?: number;
  }): Promise<any> {
    const [pkg]=await this.dataSource.query(
      `UPDATE investment_packages SET
         price=COALESCE($1,price), daily_pct=COALESCE($2,daily_pct),
         is_active=COALESCE($3,is_active), label=COALESCE($4,label),
         cycle_days=COALESCE($5,cycle_days), updated_at=NOW()
       WHERE id=$6 RETURNING *`,
      [data.price||null,data.dailyPct||null,data.isActive??null,data.label||null,data.cycleDays||null,pkgId]);
    const [admin]=await this.dataSource.query(`SELECT email FROM users WHERE id=$1`,[adminId]);
    await this.dataSource.query(
      `INSERT INTO audit_log(admin_id,admin_email,action,target_type,target_id,details)
       VALUES($1,$2,'update_package_config','investment_package',$3,$4)`,
      [adminId,admin?.email,pkgId,JSON.stringify(data)]);
    return pkg;
  }
}
