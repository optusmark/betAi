import { Injectable } from '@nestjs/common';
import { DataSource } from 'typeorm';

@Injectable()
export class WalletService {
  constructor(private readonly dataSource: DataSource) {}

  async getWalletOverview(userId: string): Promise<any> {
    // Get all balances with asset info
    const balances = await this.dataSource.query(
      `SELECT b.*, ca.symbol, ca.name, ca.network, ca.logo_url
       FROM balances b
       JOIN crypto_assets ca ON b.asset_id = ca.id
       WHERE b.user_id = $1`,
      [userId]
    );

    // Get recent transactions
    const transactions = await this.dataSource.query(
      `SELECT t.*, ca.symbol
       FROM transactions t
       JOIN crypto_assets ca ON t.asset_id = ca.id
       WHERE t.user_id = $1
       ORDER BY t.created_at DESC LIMIT 20`,
      [userId]
    );

    // Get active bonus period
    const [bonusPeriod] = await this.dataSource.query(
      `SELECT bp.*,
         GREATEST(0, EXTRACT(DAYS FROM (bp.end_date - NOW()))) AS days_remaining,
         EXTRACT(DAYS FROM (NOW() - bp.start_date))             AS days_elapsed,
         u.active_referrals_count,
         u.referral_condition_met
       FROM bonus_periods bp
       JOIN users u ON bp.user_id = u.id
       WHERE bp.user_id = $1 AND bp.status = 'active'
       ORDER BY bp.period_number DESC
       LIMIT 1`,
      [userId]
    );

    // Total = deposit_base + bonus_balance across all assets (USDT equivalent)
    const totalDeposit = balances.reduce(
      (s: number, b: any) => s + parseFloat(b.deposit_base || '0'), 0
    );
    const totalBonus = balances.reduce(
      (s: number, b: any) => s + parseFloat(b.bonus_balance || '0'), 0
    );

    return {
      balances,
      totalDeposit,
      totalBonus,
      totalBalance: totalDeposit + totalBonus,
      transactions,
      bonusPeriod: bonusPeriod || null,
      dailyBonusPreview: parseFloat((totalDeposit * 0.02).toFixed(8)),
    };
  }

  async getAssets(): Promise<any[]> {
    return this.dataSource.query(
      `SELECT * FROM crypto_assets WHERE is_active = TRUE ORDER BY symbol, network`
    );
  }
}
