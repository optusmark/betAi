# betAi Platform — Full Project State
**Last updated:** Session 3 (Auth + Admin Roles + Terms)

## DEMO FILE
`/mnt/user-data/outputs/betAi-Final.html` — 241KB, fully self-contained, single file

## ═══════════════════════════════════════════════════════════
## AUTHENTICATION SYSTEM (NEW)
## ═══════════════════════════════════════════════════════════

### Landing / Login Screen
- Two tabs: **Sign In** | **Register**
- Sign In: email + password + "Login as Administrator" checkbox
- Register: email + password + confirm password
- Validation: email format regex, password min 8 chars, password match
- "Forgot password?" → dedicated view with Telegram support link
- Bottom switch prompt: "No account? → Register here"
- Enter key submits

### Telegram Support
- Constant: `TELEGRAM_SUPPORT = "https://t.me/betAi_Support"`
- All support + password recovery routes through Telegram

### Account Store (demo; = DB in prod)
- `S.accounts[]` — {email, password, termsAccepted, isAdmin, isTest, balance}
- Pre-seeded: demo@betai.com / Demo@123456 (termsAccepted:true)

### Terms of Service
- `FULL_TERMS` object — 18 sections, full legal text, EN + RU (verified translation)
- Sections: Acceptance, Service, Registration, Packages, Upgrades, Deposits, 
  Returns/Bonuses, Referrals, Withdrawals, Residual Balance, Risks, Prohibited 
  Conduct, Support, Privacy, Liability, Amendments, Disputes, Contact
- `showTermsModal()` — scrollable modal, lang switcher inside, Accept/Decline
- **Shown ONCE at registration only** (via `S.pendingRegister`)
- Accept → saves account with `termsAccepted:true` → logs in
- Decline → blocks access, returns to register with message
- Existing users: terms NOT re-shown (checked via stored account)
- **Admin login skips terms entirely** (mkUser(true) direct)

## ═══════════════════════════════════════════════════════════
## ADMIN ROLES & PERMISSIONS (NEW)
## ═══════════════════════════════════════════════════════════

### Roles
- **super** — full access to everything + manage other admins
- **admin** — only granted permissions

### Permission keys (ADMIN_PERMISSIONS)
deposits, withdrawals, wallets, packages, users, banner, sports, 
testaccts, support, admins

### Enforcement
- `adminCan(permKey)` — super returns true for all; admin checks array
- Nav filtered: `gNav()` hides items admin lacks permission for
- Page guards: each admin page calls `if(!adminCan(x))return pgNoPermission()`
- a-dash and a-audit always visible

### Admin Accounts Store
- `S.adminAccounts[]` — {id, email, role, permissions, createdBy, active, password}
- Current demo admin = super (admin@betai.com)
- **2 final super-admins to be generated at deployment** (structure ready)

### Manage Admins Page (super only)
- Create admin (auto-password), assign permissions via checkbox modal
- Toggle active/disabled, delete
- `renderEditPermsModal()` — per-permission checkboxes
- Super-admins shown as "Protected" (cannot be edited/deleted)

## ═══════════════════════════════════════════════════════════
## TEST ACCOUNTS (NEW — admin feature)
## ═══════════════════════════════════════════════════════════
- `S.testAccounts[]` — regular-user accounts for QA
- Admin page "Test Accounts" (perm: testaccts)
- Create: email + auto-generated password (visible, copyable)
- Manual balance +/- controls per account
- Delete account
- These accounts CAN log in (added to S.accounts), full user features, NO admin
- `genPassword()` — 10-char random

## ═══════════════════════════════════════════════════════════
## BUSINESS LOGIC (unchanged, confirmed)
## ═══════════════════════════════════════════════════════════

### Packages
| Package  | Price  | Daily % | Days |
|----------|--------|---------|------|
| Silver   | $500   | 2%      | 40   |
| Gold     | $1000  | 2%      | 40   |
| Platinum | $2000  | 2%      | 40   |
- Min deposit $100 (not tied to package price)
- Activation: automatic on selection (NO admin approval)
- Deposit + Withdraw: require admin approval
- Upgrade: first 10 days only, upward only, counter NOT reset
- Bonuses usable for upgrade (within cycle), NOT for withdrawal calc
- 40-day end without 5 referrals: bonuses BURN, deposit-only withdrawal
- New package = new deposit (residual can only be withdrawn)
- Admin can edit price/%/days/active per package (3 columns)

### Deposits — USDT TRC20 ONLY
- Manual admin approval, proof upload (JPG/PNG/PDF ≤10MB)
- Combined Deposit+Withdraw page (tabs)

### Withdrawals
- 5 active referrals → full (deposit+bonus)
- <5 → deposit only

### Referrals — link only, auto-tracked
- Active = registered via link + made deposit
- 5 needed for full withdrawal

### Sports Page (API-Football)
- Key: 568c7020aa780ff0a3df3b3614078d0f
- LIVE: red border + pulsing dot, 30s refresh
- Match detail: score, stat bars, events timeline
- Admin: enable/disable, max events

### Market Ticker (Binance WebSocket)
- wss://stream.binance.com — public, no key
- 10 coins, auto-reconnect, Socket.io broadcast /2s

### Banner
- Single banner on home, admin-managed (image URL, link, on/off)

## ═══════════════════════════════════════════════════════════
## DESIGN & RESPONSIVE
## ═══════════════════════════════════════════════════════════
- All SVG icons (no emoji), Feather/Lucide style
- Tokens: --bg #F2F4F8, --ac #0052FF, --ok #00A86B, --err #E53E3E
- Nav: icon-left + text (nb-label, text-align:left, flex:1) — FIXED alignment
- Breakpoints: mobile <744px (bottom nav), tablet 744-1079px (sidebar 220px), 
  desktop ≥1080px (sidebar 228px, enforced no-mobile-elements)
- iPad Mini (744px) → tablet layout
- Landscape: max-width 1000px covers all iPhone Plus/Pro Max
- Safe-area via @supports (iOS 12+ compatible)
- Input font-size 16px (no iOS auto-zoom)
- Covers iPhone 6 → 16 Pro Max + all Android

## ═══════════════════════════════════════════════════════════
## BACKEND (NestJS) — /home/claude/sp1/backend/src/
## ═══════════════════════════════════════════════════════════
- auth/ — JWT, register, login
- packages/ — Silver/Gold/Platinum, activate, upgrade, daily bonus cron
- sports/ — API-Football integration, caching
- market/ — Binance WebSocket service + Socket.io gateway
- deposits/ — manual flow, wallet-admin
- withdrawals/, referrals/, bonuses/, admin/, support/
- database/migrations/ — 001 init, 002 deposits, 003 packages+sports

## ═══════════════════════════════════════════════════════════
## TODO / PENDING
## ═══════════════════════════════════════════════════════════
- [ ] Generate 2 final super-admin accounts (at deployment — structure ready)
- [ ] Backend: implement admin roles/permissions tables to match demo
- [ ] Backend: test-accounts endpoints
- [ ] Real file upload for deposit proofs
- [ ] Next.js frontend with all new logic
- [ ] Withdrawal fees/limits (user to specify if needed)
- [ ] Connect Telegram support bot
